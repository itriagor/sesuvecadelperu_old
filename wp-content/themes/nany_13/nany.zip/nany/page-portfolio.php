<?php
/**
Template Name: Portfolio
**/
?>

<?php get_header(); ?>

		<?php if ( have_posts() ) while ( have_posts() ) : the_post(); ?>
			<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
				<div class="entry-content">
					<?php the_content(); ?>
					<div class="clearfix"></div>
				</div>
			</div>
		<?php endwhile; ?>

		<?php
			$portfolio_show_category = get_post_meta($post->ID,'portfolio_show_category', true);
			$portfolio_columns = get_post_meta($post->ID, 'portfolio_columns', true);
			$item_count = get_post_meta($post->ID, 'portfolio_item_limit', true);
			$hide_filter = get_post_meta($post->ID,'portfolio_cat_filter', true);
			$order = get_post_meta($post->ID,'portfolio_item_order', true);
			$orderby = get_post_meta($post->ID,'portfolio_item_orderby', true);
			$offset = get_post_meta($post->ID,'portfolio_item_offset', true);
		?>

		<?php if ($hide_filter != 'hide') { ?>
			<?php
				if ($portfolio_show_category){
					$pf_item_slugs = str_replace(', ', ',', $portfolio_show_category);
					$pf_item_slugs = rtrim($pf_item_slugs, ',');
					$pf_item_slugs =  explode(",", $pf_item_slugs);

					foreach ($pf_item_slugs as $pf_item_slug) {
						$pf_show_only[] ='.catfilter li a.'. $pf_item_slug;
					}
					$pf_show_only = implode(', ', $pf_show_only);
					echo '<style>.catfilter li a{display:none;} .catfilter li a.all, ' . $pf_show_only . '{display:inline !important;}</style>';
				}
			?>
			<ul class="catfilter">
				<li class="active"><a href="javascript:void(0)" class="all"><?php _e('All', 'nany'); ?></a></li>
				<?php $terms = get_terms('portfolio_category');
					$count = count($terms);
					$i=0;
					$term_list = '';
					if ($count > 0) {
						foreach ($terms as $term) {
							$i++;
							$term_list .= '<li><a href="javascript:void(0)" class="'. $term->slug .'" title="' . esc_attr($term->name) . '">' . $term->name . '</a></li>';
							if ($count != $i) {
								$term_list .= '';
							} else {
								$term_list .= '';
							}
						}
						echo $term_list;
					}
				?>
				<div class="clearfix"></div>
			</ul>
		<?php } ?>

		<!-- Portfolio Items -->
    <div id="port-items" class="portfolio-page">
      <div class="port-main-wrap">
        <div class="port-inner-wrap">

		<ul class="nany-portfolio cat-container <?php echo $portfolio_columns; ?>">

			<?php
			// Pagination Issue Fixed
			global $paged;
			if( get_query_var( 'paged' ) )
				$my_page = get_query_var( 'paged' );
			else {
				if( get_query_var( 'page' ) )
					$my_page = get_query_var( 'page' );
				else
					$my_page = 1;
				set_query_var( 'paged', $my_page );
				$paged = $my_page;
			}

			// default loop here, if applicable, followed by wp_reset_query();

			$args = array(
				// other query params here
				'paged' => esc_attr($my_page),
				'post_type' => 'portfolio',
				'posts_per_page' => (int)$item_count,
				'category_name' => esc_attr($portfolio_show_category),
				'offset' => (int)$offset,
				'orderby' => esc_attr($orderby),
				'order' => esc_attr($order)
			);

			$wpbp = new WP_Query( $args );

			if ($wpbp->have_posts()) : while ($wpbp->have_posts()) : $wpbp->the_post();

			$terms = wp_get_post_terms($post->ID, 'portfolio_category');

			if ( (function_exists('has_post_thumbnail')) && (has_post_thumbnail()) ) {
              $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
              $large_image = $large_image[0];

              if ($portfolio_columns === 'portfolio-3-column') {
                $portfolio_img = aq_resize( $large_image, '360', '260', true );
              } elseif ($portfolio_columns === 'portfolio-2-column') {
                $portfolio_img = aq_resize( $large_image, '560', '400', true );
              } else {
                $portfolio_img = aq_resize( $large_image, '255', '240', true );
              }
            } else {
              $large_image = IMAGES .'/dummy/560x400.jpg';

              if ($portfolio_columns === 'portfolio-3-column') {
                $portfolio_img = IMAGES .'/dummy/560x400.jpg';
              } elseif ($portfolio_columns === 'portfolio-2-column') {
                $portfolio_img = IMAGES .'/dummy/560x400.jpg';
              } else {
                $portfolio_img = IMAGES .'/dummy/255x240.jpg';
              }
            }

			?>


			<li id="item-<?php echo $post->ID; ?>" class="portfolio-square" <?php if (!$hide_filter) { ?>data-id="id-<?php echo $count; ?>"<?php } ?> data-type="<?php foreach ($terms as $term) { echo $term->slug . ' ';} ?>">

                <div class="port-hover">
                    <div class="hover-text">
                        <?php echo get_the_term_list( $post->ID, 'portfolio_category', '<span class="port-categroy">', ', ', '</span>' ); ?>
                        <div class="categroy-sep"></div>
                        <span class="port-likes"><?php echo zilla_likes(); ?> <?php echo __('Likes', 'nany'); ?></span>
                        <span class="port-views"><i class="fa fa-eye"></i> <small><?php echo bawpvc_views_sc( $content = null ); ?></small> <?php echo __('Views', 'nany'); ?></span>
                    </div>
                </div>
                <a href="<?php echo esc_url(get_permalink()); ?>"><img src="<?php echo esc_attr($portfolio_img); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" /></a>
                <div class="port-title">
                  <a href="<?php echo esc_url($large_image); ?>" class="port-nub woo-popup-link">
                    <i class="fa fa-plus"></i>
                    <img src="<?php echo esc_attr(ot_get_option('title_nub')); ?>" alt="">
                  </a>
                  <a href="<?php echo esc_url(get_permalink()); ?>"><?php echo get_the_title(); ?></a>
                </div>

            </li>

			<?php if ($hide_filter != 'hide') { $count++; } ?>
			<?php endwhile; endif; ?>
			<?php wp_reset_query(); ?>
			<div class="clearfix"></div>
		</ul>
		<div class="clearfix"></div>

		</div>
	</div>
</div>

		<!-- Paged navigation -->
		<div class="post-navigation container">
			<?php
				if ( function_exists('wp_pagenavi')) {
						wp_pagenavi(array( 'query' => $wpbp ) );
						wp_reset_postdata();	// avoid errors further down the page
				}
			?>
		</div>

	<div class="clearfix"></div>
<?php get_footer(); ?>