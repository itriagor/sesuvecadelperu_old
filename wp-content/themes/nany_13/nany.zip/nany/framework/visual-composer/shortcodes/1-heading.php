<?php

/* ==========================================================
    Visual Composer - Heading
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_heading')) {
  function nany_heading( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'heading_text'  => '',
      'heading_tag'  => '',
      'text_align'  => '',
      'font_size'   => '',
      'line_height'  => '',
      'color' => '',
      'text_transform' => '',
      'class'  => '',

      /* Icons Tab */
      'need_top_icon'  => '',
      'top_icon_full'  => '',
      'top_icon'  => '',
      'icon_style'  => '',
      'outer_size'  => '',
      'icon_font_size'  => '',
      'icon_color'  => '',
      'icon_border_color'  => '',
      'icon_height'  => '',
      'line_height'  => '',

      /* Margin */
      'margins'  => '',
      'heading_margin_top'  => '',
      'heading_margin_bottom'  => '',
      'heading_margin_right'  => '',
      'heading_margin_left'  => '',

      /* Padding */
      'paddings'  => '',
      'heading_padding_top'  => '',
      'heading_padding_bottom'  => '',
      'heading_padding_right'  => '',
      'heading_padding_left'  => '',

    ), $atts));

    if ( $text_align ) {
      $text_align = 'text-align:'. $text_align .';';
    }
    if ( $font_size ) {
      $font_size = 'font-size:'. $font_size .';';
    }
    if ( $line_height ) {
      $line_height = 'line-height:'. $line_height .';';
    }
    if ( $color ) {
      $color = 'color:'. $color .';';
    }
    if ( $text_transform ) {
      $text_transform = 'text-transform:'. $text_transform .';';
    }

    /* Margins */
    if($heading_margin_top) {
      $heading_margin_top = 'margin-top:'. $heading_margin_top .';';
    }
    if($heading_margin_bottom) {
      $heading_margin_bottom = 'margin-bottom:'. $heading_margin_bottom .';';
    }
    if($heading_margin_left) {
      $heading_margin_left = 'margin-left:'. $heading_margin_left .';';
    }
    if($heading_margin_right) {
      $heading_margin_right = 'margin-right:'. $heading_margin_right .';';
    }

    /* Paddings */
    if($heading_padding_top) {
      $heading_padding_top = 'padding-top:'. $heading_padding_top .';';
    }
    if($heading_padding_bottom) {
      $heading_padding_bottom = 'padding-bottom:'. $heading_padding_bottom .';';
    }
    if($heading_padding_left) {
      $heading_padding_left = 'padding-left:'. $heading_padding_left .';';
    }
    if($heading_padding_right) {
      $heading_padding_right = 'padding-right:'. $heading_padding_right .';';
    }

    if ($need_top_icon) {
      if ( $icon_style ) {
        $icon_style = $icon_style;
      }
      if ( $outer_size ) {
        $outer_size = 'height:'. $outer_size .'px;width:'. $outer_size .'px;';
      }
      if ( $icon_height ) {
        $icon_height = 'line-height:'. $icon_height .'px;';
      }
      if ( $icon_font_size ) {
        $icon_font_size = 'font-size:'. $icon_font_size .'px;';
      }
      if ( $icon_color ) {
        $icon_border_color = 'border-color:'. $icon_color .';';
        $icon_color = 'color:'. $icon_color .';';
      }
      if ( $top_icon ) {
        $top_icon_full = '<span class="heading-icon '. $icon_style .'" style="'. $outer_size . $icon_height . $icon_border_color .'"><i class="fa '. $top_icon .'" style="'. $icon_font_size . $icon_color .'"></i></span>';
      }
    }

    $output = '<div class="nany-title" style="'. $heading_margin_top . $heading_margin_bottom . $heading_margin_left . $heading_margin_right . $heading_padding_top . $heading_padding_bottom . $heading_padding_left . $heading_padding_right .'">'. $top_icon_full .'<'. $heading_tag .' class="'. $class .'" style="'. $text_align . $font_size . $line_height . $color . $text_transform .'">' . do_shortcode( $heading_text ) . '</'. $heading_tag .'></div>';

    return $output;

  }
}
add_shortcode( 'heading', 'nany_heading' );


/**
  Add to visual composer
**/
add_action( 'init', 'nany_heading_vc_map' );
if ( ! function_exists( 'nany_heading_vc_map' ) ) {
  function nany_heading_vc_map() {
    vc_map( array(
        "name" =>"Heading",
        "base" => "heading",
        "description" => "Heading styles",
        "icon" => "icon-wpb-ui-custom_heading",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(
            array(
              "type"=>'textarea',
              "heading"=>__('Text', 'nany'),
              "param_name"=> "heading_text",
              "value"=>"My Heading",
              "admin_label" => true,
              "description" => __( "Enter your heading title.", 'nany')
            ),

            array(
                "type" => "dropdown",
                "heading" => __( "Element Tag", 'nany' ),
                "param_name" => "heading_tag",
                "value" => array(
                            "H1"=>'h1',
                            "H2"=>'h2',
                            "H3"=>'h3',
                            "H4"=>'h4',
                            "H5"=>'h5',
                            "H6"=>'h6',
                            "p"=>'p',
                            "div"=>'div'
                          ),
                "description" => __( "Select heading tag.", 'nany')
            ),

            array(
                "type" => "dropdown",
                "heading" => __( "Transform", 'nany' ),
                "param_name" => "text_transform",
                "value" => array(
                            "Normal"=>'none',
                            "Uppercase"=>'uppercase',
                            "Capitalize"=>'capitalize',
                            "Lowercase"=>'lowercase'
                          ),
                "description" => __( "Select heading text transform.", 'nany')
            ),

            array(
                "type" => "dropdown",
                "heading" => __( "Text align", 'nany' ),
                "param_name" => "text_align",
                "value" => array(
                            "Left"=>'left',
                            "Right"=>'right',
                            "Center"=>'center',
                            "Justify"=>'justify'
                          ),
                "description" => __( "Select text alignment.", 'nany')
            ),

            array(
              "type"=>'textfield',
              "heading"=>__('Font Size', 'nany'),
              "param_name"=> "font_size",
              "value"=>"",
              "description" => __( "Enter font size in px. (Eg : 16px)", 'nany'),
              "group" => __( "Design & Size", 'nany')
            ),

            array(
              "type"=>'textfield',
              "heading"=>__('Line Height', 'nany'),
              "param_name"=> "line_height",
              "value"=>"",
              "description" => __( "Enter line height in px. (Eg : 16px)", 'nany'),
              "group" => __( "Design & Size", 'nany')
            ),

            array(
              "type"=>'colorpicker',
              "heading"=>__('Text color', 'nany'),
              "param_name"=> "color",
              "value"=>"",
              "description" => __( "Select color for your heading.", 'nany'),
              "group" => __( "Design & Size", 'nany')
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

            /* Icons Tab */
            array(
              "type"=>'checkbox',
              "heading"=>__('Need Top Icon?', 'nany'),
              "param_name"=> "need_top_icon",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need top icon on heading, check this.", 'nany'),
              "group" => __( "Icon", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Top Icon", 'nany' ),
                "param_name" => "top_icon",
                'value'=>'fa-heart',
                "description" => __( "Select icon from <a href='http://fortawesome.github.io/Font-Awesome/cheatsheet/' target='_blank'>FontAwesome</a> lib. (Eg : fa-heart)", 'nany'),
                'dependency'  => Array(
                                  'element' => "need_top_icon",
                                  'value'   => array( 'yes' ),
                                ),
                "group" => __( "Icon", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Icon Style", 'nany' ),
                "param_name" => "icon_style",
                "value" => array(
                            "Round"=>'ti-rounded',
                            "Square"=>'ti-square'
                          ),
                'dependency'  => Array(
                                  'element' => "need_top_icon",
                                  'value'   => array( 'yes' ),
                                ),
                "description" => __( "Select icon style", 'nany'),
                "group" => __( "Icon", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Icon color', 'nany'),
              "param_name"=> "icon_color",
              "value"=>"#497bb8",
              "description" => __( "Select icon color.", 'nany'),
              'dependency'  => Array(
                                  'element' => "need_top_icon",
                                  'value'   => array( 'yes' ),
                                ),
               "group" => __( "Icon", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Icon outer size", 'nany' ),
                "param_name" => "outer_size",
                'value'=>'',
                "description" => __( "Enter icon outer size values without pixels. (Eg : 60)", 'nany'),
                'dependency'  => Array(
                                  'element' => "need_top_icon",
                                  'value'   => array( 'yes' ),
                                ),
                "group" => __( "Icon", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Icon line height", 'nany' ),
                "param_name" => "icon_height",
                'value'=>'',
                "description" => __( "Enter icon line height, values without pixels. (Eg : 68)", 'nany'),
                'dependency'  => Array(
                                  'element' => "need_top_icon",
                                  'value'   => array( 'yes' ),
                                ),
                "group" => __( "Icon", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Icon font size", 'nany' ),
                "param_name" => "icon_font_size",
                'value'=>'',
                "description" => __( "Enter icon font size values without pixels. (Eg : 24)", 'nany'),
                'dependency'  => Array(
                                  'element' => "need_top_icon",
                                  'value'   => array( 'yes' ),
                                ),
                "group" => __( "Icon", 'nany')
            ),

            /* Margin */
            array(
              "type" => "textfield",
              "heading" => __( "Margin Top", 'nany' ),
              "param_name" => "heading_margin_top",
              'value'=> '',
              "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
              "group" => __( "Margin", 'nany')
            ),
            array(
              "type" => "textfield",
              "heading" => __( "Margin Bottom", 'nany' ),
              "param_name" => "heading_margin_bottom",
              'value'=> '',
              "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
              "group" => __( "Margin", 'nany')
            ),
            array(
              "type" => "textfield",
              "heading" => __( "Margin Right", 'nany' ),
              "param_name" => "heading_margin_right",
              'value'=> '',
              "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
              "group" => __( "Margin", 'nany')
            ),
            array(
              "type" => "textfield",
              "heading" => __( "Margin Left", 'nany' ),
              "param_name" => "heading_margin_left",
              'value'=> '',
              "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
              "group" => __( "Margin", 'nany')
            ),

            /* Padding */
            array(
              "type" => "textfield",
              "heading" => __( "Padding Top", 'nany' ),
              "param_name" => "heading_padding_top",
              'value'=> '',
              "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
              "group" => __( "Padding", 'nany')
            ),
            array(
              "type" => "textfield",
              "heading" => __( "Padding Bottom", 'nany' ),
              "param_name" => "heading_padding_bottom",
              'value'=> '',
              "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
              "group" => __( "Padding", 'nany')
            ),
            array(
              "type" => "textfield",
              "heading" => __( "Padding Right", 'nany' ),
              "param_name" => "heading_padding_right",
              'value'=> '',
              "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
              "group" => __( "Padding", 'nany')
            ),
            array(
              "type" => "textfield",
              "heading" => __( "Padding Left", 'nany' ),
              "param_name" => "heading_padding_left",
              'value'=> '',
              "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
              "group" => __( "Padding", 'nany')
            ),


          )
    ) );
  }
}


?>