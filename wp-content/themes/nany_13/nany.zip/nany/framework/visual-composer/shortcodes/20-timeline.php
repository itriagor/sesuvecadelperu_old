<?php

/* ==========================================================
    Visual Composer - Timeline
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_timeline')) {
  function nany_timeline( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'extra_class'  => ''
    ), $atts));

    // Turn output buffer on
    ob_start();

    $timeline_section = ot_get_option('timeline_section');
    ?>
    <div class="<?php echo $extra_class; ?> timeline-wrapper">
    <?php
    if ($timeline_section) {
      foreach($timeline_section as $timeline_tab) : ?>
          <?php
          $timeline_title = $timeline_tab['title'];
          $own_id = preg_replace('/[^a-z]/', "-", strtolower($timeline_title));
          // timeline tab start
          if($timeline_tab['title']) { ?>
            <div class="timeline <?php echo $own_id; ?>"><div class="timeline-year"><?php echo $timeline_tab['timeline_year']; ?></div><div class="timeline-top-line"></div><div class="timeline-content"><span class="timeline-year-icon"><i class="fa <?php echo $timeline_tab['timeline_icon']; ?>"></i></span><h4><?php echo $timeline_title; ?></h4><p><?php echo $timeline_tab['timeline_content']; ?></p></div></div>
        <?php } endforeach;
      } ?>
    <?php
    if(!$timeline_section) {
      echo '<p class="text-center">';
      echo __('Add Timeline section at : Appearace > Theme Options > Shortcodes', 'nany');
      echo '</p>';
    }
    ?>
    </div>
    <?php

    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'timeline', 'nany_timeline' );

/**
  Add to visual composer
**/
add_action( 'init', 'nany_timeline_vc_map' );
if ( ! function_exists( 'nany_timeline_vc_map' ) ) {
  function nany_timeline_vc_map() {
    vc_map( array(
        "name" =>"Timeline",
        "base" => "timeline",
        "description" => "Timeline Shortcode",
        "icon" => "vc-timeline",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "notification_info", // This is Nany's Own Custom Param.
                "heading" => __( "Shortcode", 'nany' ),
                "param_name" => "custom_notification_note",
                'value'=> 'Timeline from Theme Options',
                'admin_label'=> true,
                "description" => __( "This shortcode is called from : <strong>Appearance > Theme Options > Shortcode > Timeline Section</strong>. If you need to work this shortcode, please add them first on Theme Options.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

          )
    ) );
  }
}


?>