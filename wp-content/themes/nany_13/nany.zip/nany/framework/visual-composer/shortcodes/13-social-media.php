<?php

/* ==========================================================
    Visual Composer - social
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_social')) {
  function nany_social( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      /* Social Media */
      'link_window'  => '',
      'social_facebook'  => '',
      'social_twitter'  => '',
      'social_linkedin'  => '',
      'social_google'  => '',
      'social_dribbble'  => '',
      'social_youtube'  => '',
      'social_vimeo'  => '',
      'social_skype'  => '',
      'social_rss'  => '',
      'social_pinterest'  => '',
      'social_flickr'  => '',
      'social_foursquare'  => '',
      'social_android'  => '',
      'social_bitbucket'  => '',
      'social_css3'  => '',
      'social_dropbox'  => '',
      'social_github'  => '',
      'social_html5'  => '',
      'social_instagram'  => '',
      'social_stack_exchange'  => '',
      'social_stack_overflow'  => '',
      'social_trello'  => '',
      'social_tumblr'  => '',

      /* Custom Class */
      'extra_class'    => '',

      /* Custom Icons */
      'icon_one'  => '',
      'icon_one_link'  => '',
      'icon_one_bg'  => '',
      'icon_two'  => '',
      'icon_two_link'  => '',
      'icon_two_bg'  => '',
      'icon_three'  => '',
      'icon_three_link'  => '',
      'icon_three_bg'  => '',
      'icon_four'  => '',
      'icon_four_link'  => '',
      'icon_four_bg'  => '',
      'icon_five'  => '',
      'icon_five_link'  => '',
      'icon_five_bg'  => '',

    ), $atts));


    /* ==============================================
      Social Media
    =============================================== */
    if ($link_window === 'yes') {
      $link_window = 'target="_blank"';
    }
    if ($social_facebook) {
      $social_facebook = '<li><a href="'. esc_url($social_facebook) .'" class="icon-fa-facebook" '. $link_window .'><i class="fa fa-facebook"></i></a></li>';
    }
    if ($social_twitter) {
      $social_twitter = '<li><a href="'. esc_url($social_twitter) .'" class="icon-fa-twitter" '. $link_window .'><i class="fa fa-twitter"></i></a></li>';
    }
    if ($social_linkedin) {
      $social_linkedin = '<li><a href="'. esc_url($social_linkedin) .'" class="icon-fa-linkedin" '. $link_window .'><i class="fa fa-linkedin"></i></a></li>';
    }
    if ($social_google) {
      $social_google = '<li><a href="'. esc_url($social_google) .'" class="icon-fa-google-plus" '. $link_window .'><i class="fa fa-google-plus"></i></a></li>';
    }
    if ($social_dribbble) {
      $social_dribbble = '<li><a href="'. esc_url($social_dribbble) .'" class="icon-fa-dribbble" '. $link_window .'><i class="fa fa-dribbble"></i></a></li>';
    }
    if ($social_youtube) {
      $social_youtube = '<li><a href="'. esc_url($social_youtube) .'" class="icon-fa-youtube" '. $link_window .'><i class="fa fa-youtube"></i></a></li>';
    }
    if ($social_vimeo) {
      $social_vimeo = '<li><a href="'. esc_url($social_vimeo) .'" class="icon-fa-vimeo" '. $link_window .'><i class="fa fa-vimeo-square"></i></a></li>';
    }
    if ($social_skype) {
      $social_skype = '<li><a href="'. esc_url($social_skype) .'" class="icon-fa-skype" '. $link_window .'><i class="fa fa-skype"></i></a></li>';
    }
    if ($social_rss) {
      $social_rss = '<li><a href="'. esc_url($social_rss) .'" class="icon-fa-rss" '. $link_window .'><i class="fa fa-rss"></i></a></li>';
    }
    if ($social_pinterest) {
      $social_pinterest = '<li><a href="'. esc_url($social_pinterest) .'" class="icon-fa-pinterest" '. $link_window .'><i class="fa fa-pinterest"></i></a></li>';
    }
    if ($social_flickr) {
      $social_flickr = '<li><a href="'. esc_url($social_flickr) .'" class="icon-fa-flickr" '. $link_window .'><i class="fa fa-flickr"></i></a></li>';
    }
    if ($social_foursquare) {
      $social_foursquare = '<li><a href="'. esc_url($social_foursquare) .'" class="icon-fa-foursquare" '. $link_window .'><i class="fa fa-foursquare"></i></a></li>';
    }
    if ($social_android) {
      $social_android = '<li><a href="'. esc_url($social_android) .'" class="icon-fa-android" '. $link_window .'><i class="fa fa-android"></i></a></li>';
    }
    if ($social_bitbucket) {
      $social_bitbucket = '<li><a href="'. esc_url($social_bitbucket) .'" class="icon-fa-bitbucket" '. $link_window .'><i class="fa fa-bitbucket"></i></a></li>';
    }
    if ($social_css3) {
      $social_css3 = '<li><a href="'. esc_url($social_css3) .'" class="icon-fa-css3" '. $link_window .'><i class="fa fa-css3"></i></a></li>';
    }
    if ($social_dropbox) {
      $social_dropbox = '<li><a href="'. esc_url($social_dropbox) .'" class="icon-fa-dropbox" '. $link_window .'><i class="fa fa-dropbox"></i></a></li>';
    }
    if ($social_github) {
      $social_github = '<li><a href="'. esc_url($social_github) .'" class="icon-fa-github" '. $link_window .'><i class="fa fa-github"></i></a></li>';
    }
    if ($social_html5) {
      $social_html5 = '<li><a href="'. esc_url($social_html5) .'" class="icon-fa-html5" '. $link_window .'><i class="fa fa-html5"></i></a></li>';
    }
    if ($social_instagram) {
      $social_instagram = '<li><a href="'. esc_url($social_instagram) .'" class="icon-fa-instagram" '. $link_window .'><i class="fa fa-instagram"></i></a></li>';
    }
    if ($social_stack_exchange) {
      $social_stack_exchange = '<li><a href="'. esc_url($social_stack_exchange) .'" class="icon-fa-stack-exchange" '. $link_window .'><i class="fa fa-stack-exchange"></i></a></li>';
    }
    if ($social_stack_overflow) {
      $social_stack_overflow = '<li><a href="'. esc_url($social_stack_overflow) .'" class="icon-fa-stack-overflow" '. $link_window .'><i class="fa fa-stack-overflow"></i></a></li>';
    }
    if ($social_trello) {
      $social_trello = '<li><a href="'. esc_url($social_trello) .'" class="icon-fa-trello" '. $link_window .'><i class="fa fa-trello"></i></a></li>';
    }
    if ($social_tumblr) {
      $social_tumblr = '<li><a href="'. esc_url($social_tumblr) .'" class="icon-fa-tumblr" '. $link_window .'><i class="fa fa-tumblr"></i></a></li>';
    }

    /* Custom Icons */
    if ($icon_one) {
      $icon_one = '<li><a href="'. esc_url($icon_one_link) .'" style="background:'. $icon_one_bg .';" '. $link_window .'><i class="fa '. $icon_one .'"></i></a></li>';
    }
    if ($icon_two) {
      $icon_two = '<li><a href="'. esc_url($icon_two_link) .'" style="background:'. $icon_two_bg .';" '. $link_window .'><i class="fa '. $icon_two .'"></i></a></li>';
    }
    if ($icon_three) {
      $icon_three = '<li><a href="'. esc_url($icon_three_link) .'" style="background:'. $icon_three_bg .';" '. $link_window .'><i class="fa '. $icon_three .'"></i></a></li>';
    }
    if ($icon_four) {
      $icon_four = '<li><a href="'. esc_url($icon_four_link) .'" style="background:'. $icon_four_bg .';" '. $link_window .'><i class="fa '. $icon_four .'"></i></a></li>';
    }
    if ($icon_five) {
      $icon_five = '<li><a href="'. esc_url($icon_five_link) .'" style="background:'. $icon_five_bg .';" '. $link_window .'><i class="fa '. $icon_five .'"></i></a></li>';
    }

    $output = '<ul class="social-media icon-colors '. $extra_class .'">'. $social_facebook . $social_twitter . $social_linkedin . $social_google . $social_dribbble . $social_youtube . $social_vimeo . $social_skype . $social_rss . $social_pinterest . $social_flickr . $social_foursquare . $social_android . $social_bitbucket . $social_css3 . $social_dropbox . $social_github . $social_html5 . $social_instagram . $social_stack_exchange . $social_stack_overflow . $social_trello . $social_tumblr . $icon_one . $icon_two . $icon_three . $icon_four . $icon_five .'</ul>';

    return $output;

  }
}
add_shortcode( 'social', 'nany_social' );


/** Add to visual composer **/
add_action( 'init', 'nany_social_vc_map' );
if ( ! function_exists( 'nany_social_vc_map' ) ) {
  function nany_social_vc_map() {
    vc_map( array(
        "name" =>"Social Media Icons",
        "base" => "social",
        "description" => "Social Media Icons",
        "icon" => "vc-social",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            /* ==============================================
               Social Media Icons
            =============================================== */
            array(
              "type"=>'checkbox',
              "heading"=>__('Links open in new window?', 'nany'),
              "param_name"=> "link_window",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "admin_label"=> true,
              "description" => __( "If you need to open all links in new window check this.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Facebook", 'nany' ),
                "param_name" => "social_facebook",
                'value'=>'',
                "description" => __( "Enter your facebook profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Twitter", 'nany' ),
                "param_name" => "social_twitter",
                'value'=>'',
                "description" => __( "Enter your twitter profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Linkedin", 'nany' ),
                "param_name" => "social_linkedin",
                'value'=>'',
                "description" => __( "Enter your linkedin profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Google Plus", 'nany' ),
                "param_name" => "social_google",
                'value'=>'',
                "description" => __( "Enter your google profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Dribbble", 'nany' ),
                "param_name" => "social_dribbble",
                'value'=>'',
                "description" => __( "Enter your dribbble profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "YouTube", 'nany' ),
                "param_name" => "social_youtube",
                'value'=>'',
                "description" => __( "Enter your youtube profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Vimeo", 'nany' ),
                "param_name" => "social_vimeo",
                'value'=>'',
                "description" => __( "Enter your vimeo profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Skype", 'nany' ),
                "param_name" => "social_skype",
                'value'=>'',
                "description" => __( "Enter your skype profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Rss", 'nany' ),
                "param_name" => "social_rss",
                'value'=>'',
                "description" => __( "Enter your rss profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Pinterest", 'nany' ),
                "param_name" => "social_pinterest",
                'value'=>'',
                "description" => __( "Enter your pinterest profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Flickr", 'nany' ),
                "param_name" => "social_flickr",
                'value'=>'',
                "description" => __( "Enter your flickr profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Foursquare", 'nany' ),
                "param_name" => "social_foursquare",
                'value'=>'',
                "description" => __( "Enter your foursquare profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Android", 'nany' ),
                "param_name" => "social_android",
                'value'=>'',
                "description" => __( "Enter your android profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Bitbucket", 'nany' ),
                "param_name" => "social_bitbucket",
                'value'=>'',
                "description" => __( "Enter your bitbucket profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "CSS3", 'nany' ),
                "param_name" => "social_css3",
                'value'=>'',
                "description" => __( "Enter your css3 profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Dropbox", 'nany' ),
                "param_name" => "social_dropbox",
                'value'=>'',
                "description" => __( "Enter your dropbox profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Github", 'nany' ),
                "param_name" => "social_github",
                'value'=>'',
                "description" => __( "Enter your github profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "HTML5", 'nany' ),
                "param_name" => "social_html5",
                'value'=>'',
                "description" => __( "Enter your html5 profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Instagram", 'nany' ),
                "param_name" => "social_instagram",
                'value'=>'',
                "description" => __( "Enter your instagram profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Stackexchange", 'nany' ),
                "param_name" => "social_stack_exchange",
                'value'=>'',
                "description" => __( "Enter your stackexchange profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Stack Overflow", 'nany' ),
                "param_name" => "social_stack_overflow",
                'value'=>'',
                "description" => __( "Enter your stack overflow profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Trello", 'nany' ),
                "param_name" => "social_trello",
                'value'=>'',
                "description" => __( "Enter your trello profile url.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Tumblr", 'nany' ),
                "param_name" => "social_tumblr",
                'value'=>'',
                "description" => __( "Enter your tumblr profile url.", 'nany')
            ),

            /* Custom Icons */
            array(
                "type" => "textfield",
                "heading" => __( "Icon 1", 'nany' ),
                "param_name" => "icon_one",
                'value'=>'',
                "description" => __( "Select icon from <a href='http://fortawesome.github.io/Font-Awesome/icons/#brand' target='_blank'>FontAwesome</a> lib. (Eg : fa-facebook)", 'nany'),
                "group" => __( "Custom Icons", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Icon 1 Link", 'nany' ),
                "param_name" => "icon_one_link",
                'value'=>'',
                "description" => __( "Enter Icon one link here.", 'nany'),
                "group" => __( "Custom Icons", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Icon 1 Background Color', 'nany'),
              "param_name"=> "icon_one_bg",
              "value"=>"",
              "description" => __( "Pick Icon one bg color.", 'nany'),
              "group" => __( "Custom Icons", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Icon 2", 'nany' ),
                "param_name" => "icon_two",
                'value'=>'',
                "description" => __( "Select icon from <a href='http://fortawesome.github.io/Font-Awesome/icons/#brand' target='_blank'>FontAwesome</a> lib. (Eg : fa-facebook)", 'nany'),
                "group" => __( "Custom Icons", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Icon 2 Link", 'nany' ),
                "param_name" => "icon_two_link",
                'value'=>'',
                "description" => __( "Enter Icon two link here.", 'nany'),
                "group" => __( "Custom Icons", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Icon 2 Background Color', 'nany'),
              "param_name"=> "icon_two_bg",
              "value"=>"",
              "description" => __( "Pick Icon two bg color.", 'nany'),
              "group" => __( "Custom Icons", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Icon 3", 'nany' ),
                "param_name" => "icon_three",
                'value'=>'',
                "description" => __( "Select icon from <a href='http://fortawesome.github.io/Font-Awesome/icons/#brand' target='_blank'>FontAwesome</a> lib. (Eg : fa-facebook)", 'nany'),
                "group" => __( "Custom Icons", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Icon 3 Link", 'nany' ),
                "param_name" => "icon_three_link",
                'value'=>'',
                "description" => __( "Enter Icon three link here.", 'nany'),
                "group" => __( "Custom Icons", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Icon 3 Background Color', 'nany'),
              "param_name"=> "icon_three_bg",
              "value"=>"",
              "description" => __( "Pick Icon three bg color.", 'nany'),
              "group" => __( "Custom Icons", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Icon 4", 'nany' ),
                "param_name" => "icon_four",
                'value'=>'',
                "description" => __( "Select icon from <a href='http://fortawesome.github.io/Font-Awesome/icons/#brand' target='_blank'>FontAwesome</a> lib. (Eg : fa-facebook)", 'nany'),
                "group" => __( "Custom Icons", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Icon 4 Link", 'nany' ),
                "param_name" => "icon_four_link",
                'value'=>'',
                "description" => __( "Enter Icon four link here.", 'nany'),
                "group" => __( "Custom Icons", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Icon 4 Background Color', 'nany'),
              "param_name"=> "icon_four_bg",
              "value"=>"",
              "description" => __( "Pick Icon four bg color.", 'nany'),
              "group" => __( "Custom Icons", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Icon 5", 'nany' ),
                "param_name" => "icon_five",
                'value'=>'',
                "description" => __( "Select icon from <a href='http://fortawesome.github.io/Font-Awesome/icons/#brand' target='_blank'>FontAwesome</a> lib. (Eg : fa-facebook)", 'nany'),
                "group" => __( "Custom Icons", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Icon 5 Link", 'nany' ),
                "param_name" => "icon_five_link",
                'value'=>'',
                "description" => __( "Enter Icon five link here.", 'nany'),
                "group" => __( "Custom Icons", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Icon 5 Background Color', 'nany'),
              "param_name"=> "icon_five_bg",
              "value"=>"",
              "description" => __( "Pick Icon five bg color.", 'nany'),
              "group" => __( "Custom Icons", 'nany')
            ),

            /* Custom CSS */
            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

          )
    ) );
  }
}


?>