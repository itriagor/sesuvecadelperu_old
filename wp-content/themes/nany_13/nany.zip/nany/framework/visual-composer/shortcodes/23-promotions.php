<?php

/* ==========================================================
    Visual Composer - promotions
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_promotions')) {
  function nany_promotions( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      /* General */
      'promotion_style'  => '',
      'promotion_image'  => '',
      'heading'  => '',
      'price'  => '',
      'link'  => '',
      'link_window'  => '',
      'extra_class'  => '',

      /* Design */
      'heading_color'  => '',
      'heading_bg_color'  => '',
      'heading_size'  => '',
      'price_color'  => '',
      'price_bg_color'  => '',

      /* Custom attr */
      'link_before'  => '',
      'link_after'  => '',
    ), $atts));

    if ( $heading_color ) {
      $heading_color = 'color:'. $heading_color .';';
    }
    if ( $heading_bg_color ) {
      $heading_bg_color = 'background-color:'. $heading_bg_color .';';
    }
    if ( $heading_size ) {
      $heading_size = 'font-size:'. $heading_size .';';
    }
    if ( $price_color ) {
      $price_color = 'color:'. $price_color .';';
    }
    if ( $price_bg_color ) {
      $price_bg_color = 'background-color:'. $price_bg_color .';';
    }

    if ( $promotion_image ) {
      $image_url = wp_get_attachment_url( $promotion_image );
      $promotion_image = '<span class="promo-image" style="background-image:url('. $image_url .');"></span>';
    } else {
      if ($promotion_style === 'style-2') {
        $promotion_image = '<span class="promo-image" style="background-image:url('. IMAGES .'/dummy/300x200.jpg);"></span>';
      } else {
        $promotion_image = '<span class="promo-image" style="background-image:url('. IMAGES .'/dummy/300x120.jpg);"></span>';
      }
    }
    if ($link_window === 'yes') {
      $link_window = 'target="_blank"';
    }
    if ( $link ) {
      $link_before = '<a href="'. esc_url($link) .'" '. $link_window .'>';
      $link_after = '</a>';
    } else {
      $link_before = '';
      $link_after = '';
    }
    if ( $price ) {
      $price = '<span class="promo-price" style="'. $price_color . $price_bg_color .'">'. $price .'</span>';
    }
    if ( $heading ) {
      $heading = '<span class="promo-heading"><h3 style="'. $heading_bg_color . $heading_color . $heading_size .'">'. $heading .'</h3></span>';
    }

    if ($promotion_style === 'style-1') {
      $promotion_style = '<div class="promotions promo-style-1 '. $extra_class .'">'. $link_before . $promotion_image . $heading . $link_after .'</div>';
    }
    if ($promotion_style === 'style-2') {
      $promotion_style = '<div class="promotions promo-style-2 '. $extra_class .'">'. $link_before . $promotion_image . $price . $heading . $link_after .'</div>';
    }

    $output = $promotion_style;

    return $output;

  }
}
add_shortcode( 'promotions', 'nany_promotions' );


/**
  Add to visual composer
**/
add_action( 'init', 'nany_promotions_vc_map' );
if ( ! function_exists( 'nany_promotions_vc_map' ) ) {
  function nany_promotions_vc_map() {
    vc_map( array(
        "name" =>"Promotions",
        "base" => "promotions",
        "description" => "WooCommerce Promotions",
        "icon" => "vc-promotions",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "dropdown",
                "heading" => __( "Promotions Style", 'nany' ),
                "param_name" => "promotion_style",
                "value" => array(
                            "Style One"=>'style-1',
                            "Style Two"=>'style-2'
                          ),
                "description" => __( "Select Promotions Style", 'nany')
            ),
            array(
              "type"=>'attach_image',
              "heading"=>__('Image', 'nany'),
              "param_name"=> "promotion_image",
              "value"=>"",
              "description" => __( "Upload your promo image.", 'nany')
            ),
            array(
              "type"=>'textfield',
              "heading"=>__('Heading', 'nany'),
              "param_name"=> "heading",
              "value"=> "",
              "admin_label"=> true,
              "description" => __( "Enter your promotion heading here.", 'nany')
            ),
            array(
              "type"=>'textfield',
              "heading"=>__('Price', 'nany'),
              "param_name"=> "price",
              "value"=> "",
              'dependency'  => Array(
                                  'element' => "promotion_style",
                                  'value'   => array( 'style-2' ),
                                ),
              "description" => __( "Enter your promotion price here.", 'nany')
            ),
            array(
              "type"=>'href',
              "heading"=>__('Link', 'nany'),
              "param_name"=> "link",
              "value"=> "",
              "description" => __( "Enter your promotion link here.", 'nany')
            ),
            array(
              "type"=>'checkbox',
              "heading"=>__('Links open in new window?', 'nany'),
              "param_name"=> "link_window",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need to open link in new window check this.", 'nany'),
            ),

            /* Design */
            array(
              "type"=>'colorpicker',
              "heading"=>__('Heading Color', 'nany'),
              "param_name"=> "heading_color",
              "value"=>"",
              "description" => __( "Pick heading color.", 'nany'),
              "group" => __( "Design", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Heading BG Color', 'nany'),
              "param_name"=> "heading_bg_color",
              "value"=>"",
              "description" => __( "Pick heading bg color.", 'nany'),
              "group" => __( "Design", 'nany')
            ),
            array(
              "type"=>'textfield',
              "heading"=>__('Heading Size', 'nany'),
              "param_name"=> "heading_size",
              "value"=>"",
              "description" => __( "Enter your font size in px. [Eg: 22px]", 'nany'),
              "group" => __( "Design", 'nany')
            ),

            array(
              "type"=>'colorpicker',
              "heading"=>__('Price Color', 'nany'),
              "param_name"=> "price_color",
              "value"=>"",
              "description" => __( "Pick price color.", 'nany'),
              "group" => __( "Design", 'nany'),
              'dependency'  => Array(
                                  'element' => "promotion_style",
                                  'value'   => array( 'style-2' ),
                                ),
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Price BG Color', 'nany'),
              "param_name"=> "price_bg_color",
              "value"=>"",
              "description" => __( "Pick price bg color.", 'nany'),
              "group" => __( "Design", 'nany'),
              'dependency'  => Array(
                                  'element' => "promotion_style",
                                  'value'   => array( 'style-2' ),
                                ),
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

          )
    ) );
  }
}


?>