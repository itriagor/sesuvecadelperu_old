<?php

/* ==========================================================
    Visual Composer - Pricing
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_pricing')) {
  function nany_pricing( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'pricing_style'  => '',
      'pricing_heading'  => '',
      'money_type'  => '',
      'pricing_price'  => '',
      'pricing_period'  => '',
      'pricing_list'  => '',
      'badge_title'  => '',
      'badge_title_color'  => '',
      'outer_border_color'  => '',
      'background_color'  => '',
      'text_color_own'  => '',
      'text_color_custom'  => '',
      'font_text_color'  => '',
      'pricing_list_icon'  => '',
      'extra_class'  => '',

      /* Button */
      'button_text'  => 'Button Text',
      'button_link'   => '',
      'open_window'  => '',
      'button_style'  => '',
      'button_size'   => '',
      'bg_color'   => '',
      'text_color'   => '',
      'text_transform'   => '',
      'btn_top_space'   => '',
      'btn_bottom_space'   => '',
    ), $atts));

    if ($font_text_color) {
      $text_color_custom = 'style="color:'. $font_text_color .';"';
    } else {
      $text_color_custom = '';
    }
    if ( $pricing_heading ) {
      $pricing_heading = '<span class="plan-name" '. $text_color_custom .'>'. $pricing_heading .'</span>';
    }
    if ($money_type) {
      $money_type = '<span class="price-type" '. $text_color_custom .'>'. $money_type .'</span>';
    }
    if ($pricing_period) {
      $pricing_period = '<span class="price-period" '. $text_color_custom .'>'. $pricing_period .'</span>';
    }
    if ($outer_border_color) {
      $background_color = 'background-color:'. $background_color .';';
      $text_color_own = 'color:'. $font_text_color .';';
      $outer_border_color = 'style="border-color:'. $outer_border_color .';'. $background_color . $text_color_own .'"';
    }
    if ($badge_title_color) {
      $badge_title_color = 'style="background:'. $badge_title_color .';"';
    }
    if ($badge_title) {
      $badge_title = '<span class="pricing-badge" '. $badge_title_color .'><small>'. $badge_title .'</small></span>';
    }

    /* Button */
    if ( $open_window ) {
      $open_window = 'target="_blank"';
    }
    if ( $button_size ) {
      $button_size = $button_size;
    }
    if ( $button_style === 'btn-style-one' ) {
       $bg_color = 'background-color:'. $bg_color .';';
    }
    if ( $button_style === 'btn-style-three' ) {
       $bg_color = 'background-color:'. $bg_color .';';
    }
    if ( $button_style === 'btn-style-five' ) {
       $bg_color = 'background-color:'. $bg_color .';';
    }
    if ( $button_style === 'btn-style-two' ) {
       $bg_color = 'border-color:'. $bg_color .';';
    }
    if ( $button_style === 'btn-style-four' ) {
       $bg_color = 'border-color:'. $bg_color .';';
    }
    if ( $text_color ) {
      $text_color = 'color:'. $text_color .';';
    }
    if ( $text_transform ) {
      $text_transform = 'text-transform:'. $text_transform .';';
    }
    if ( $btn_top_space ) {
      $btn_top_space = 'margin-top:'. $btn_top_space .';';
    }
    if ( $btn_bottom_space ) {
      $btn_bottom_space = 'margin-bottom:'. $btn_bottom_space .';';
    }

    if ($pricing_style === 'style-1') {
      if ( $button_link ) {
        $button_code = '<li class="plan-action"><a href="'. esc_url($button_link) .'" '. $open_window .' class="'. $button_style .' '. $button_size .'" style="'. $bg_color . $text_color . $text_transform . $btn_top_space . $btn_bottom_space .'">'. $button_text .'</a></li>';
      } else {
        $button_code = '';
      }
      $pricing_style = '<div class="pricing-table '. $extra_class .'" '. $outer_border_color .'>'. $badge_title .'<div class="pricing-head price-one">'. $pricing_heading .'<span class="plan-price">'. $money_type .'<strong '. $text_color_custom .'>'. $pricing_price .'</strong>'. $pricing_period .'</span></div><ul class="plan" '. $text_color_custom .'><li>'. str_replace("\n","</li><li>",trim($pricing_list,"")) .'</li>'. $button_code .'</ul></div>';
    }
    if ($pricing_style === 'style-2') {
      if ( $button_link ) {
        $button_code = '<span class="plan-action"><a href="'. esc_url($button_link) .'" '. $open_window .' class="'. $button_style .' '. $button_size .'" style="'. $bg_color . $text_color . $text_transform . $btn_top_space . $btn_bottom_space .'">'. $button_text .'</a></span>';
      } else {
        $button_code = '';
      }
      $pricing_style = '<div class="pricing-table horizontal-pricing '. $extra_class .'" '. $outer_border_color .'>'. $badge_title .'<div class="pricing-head price-one">'. $pricing_heading .'<span class="plan-price">'. $money_type .'<strong '. $text_color_custom .'>'. $pricing_price .'</strong>'. $pricing_period .'</span></div><ul class="plan" '. $text_color_custom .'><li class="'. $pricing_list_icon .'">'. str_replace("\n","</li><li class=\"$pricing_list_icon\">",trim($pricing_list,"")) .'</li></ul>'. $button_code .'</div>';
    }

    return $pricing_style;

  }
}
add_shortcode( 'pricing', 'nany_pricing' );


/**
  Add to visual composer
**/
add_action( 'init', 'nany_pricing_vc_map' );
if ( ! function_exists( 'nany_pricing_vc_map' ) ) {
  function nany_pricing_vc_map() {
    vc_map( array(
        "name" =>"Pricing Table",
        "base" => "pricing",
        "description" => "Pricing Table Styles",
        "icon" => "vc-pricing",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "dropdown",
                "heading" => __( "Pricing Style", 'nany' ),
                "param_name" => "pricing_style",
                "value" => array(
                            "Verticle"=>'style-1',
                            "Horizontal"=>'style-2'
                          ),
                "description" => __( "Select Pricing Style", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Heading", 'nany' ),
                "param_name" => "pricing_heading",
                'value'=> 'Standard',
                'admin_label'=> true,
                "description" => __( "Enter your pricing heading.", 'nany')
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Money Type", 'nany' ),
                "param_name" => "money_type",
                'value'=> '$',
                "description" => __( "Enter your money type.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Price", 'nany' ),
                "param_name" => "pricing_price",
                'value'=> '19',
                "description" => __( "Enter your price.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Price Period", 'nany' ),
                "param_name" => "pricing_period",
                'value'=> '',
                "description" => __( "Enter your price period. [Ex : Month]", 'nany')
            ),

            array(
              "type"=>'textarea',
              "heading"=>__('Pricing list', 'nany'),
              "param_name"=> "pricing_list",
              "value"=>"Limited Storage\nAsk Support\nPost Questions\nApply Jobs Upto 10\n3 Days Payment",
              "description" => __( "New line as a new list item.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Pricing List Icon", 'nany' ),
                "param_name" => "pricing_list_icon",
                'value'=> '',
                "description" => __( "Select icon from <a href='http://fortawesome.github.io/Font-Awesome/cheatsheet/' target='_blank'>FontAwesome</a> lib. (Eg : fa-check-circle)", 'nany'),
                'dependency'  => Array(
                                  'element' => "pricing_style",
                                  'value'   => array( 'style-2' ),
                                ),
            ),

            array(
              "type"=>'colorpicker',
              "heading"=>__('Outer Border Color', 'nany'),
              "param_name"=> "outer_border_color",
              "value"=> "",
              "description" => __( "Pick your pricing box border color.", 'nany'),
              "group" => __( "Design", 'nany'),
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Background Color', 'nany'),
              "param_name"=> "background_color",
              "value"=> "",
              "description" => __( "Pick your pricing box background color.", 'nany'),
              "group" => __( "Design", 'nany'),
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Text Color', 'nany'),
              "param_name"=> "text_color",
              "value"=> "",
              "description" => __( "Pick your pricing box text color.", 'nany'),
              "group" => __( "Design", 'nany'),
            ),


            array(
              "type"=>'textfield',
              "heading"=>__('Badge Title', 'nany'),
              "param_name"=> "badge_title",
              "value"=> "",
              "description" => __( "Enter your badge title here.", 'nany'),
              "group" => __( "Badge", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Badge Title BG Color', 'nany'),
              "param_name"=> "badge_title_color",
              "value"=>"",
              "description" => __( "Pick your badge background color.", 'nany'),
              "group" => __( "Badge", 'nany')
            ),

            /* Button */
            array(
                "type" => "textfield",
                "heading" => __( "Button Text", 'nany' ),
                "param_name" => "button_text",
                'value'=>'My Button',
                "description" => __( "Enter button text", 'nany'),
                 "group" => __( "Button", 'nany')
            ),
            array(
                "type" => "href",
                "heading" => __( "Button Link", 'nany' ),
                "param_name" => "button_link",
                'value'=>'',
                "description" => __( "Enter button link", 'nany'),
                 "group" => __( "Button", 'nany')
            ),
            array(
              "type"=>'checkbox',
              "heading"=>__('Link open in new window?', 'nany'),
              "param_name"=> "open_window",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need to open link in new window, check this.", 'nany'),
               "group" => __( "Button", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Button Style", 'nany' ),
                "param_name" => "button_style",
                "value" => array(
                            "Style One"=>'btn-style-one',
                            "Style Two"=>'btn-style-two',
                            "Style Three"=>'btn-style-three',
                            "Style Four"=>'btn-style-four',
                            "Style Five"=>'btn-style-five'
                          ),
                "description" => __( "Select Button Style", 'nany'),
                 "group" => __( "Button", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Button Size", 'nany' ),
                "param_name" => "button_size",
                "value" => array(
                            "Small"=>'small-btn',
                            "Medium"=>'medium-btn',
                            "Large"=>'large-btn'
                          ),
                "description" => __( "Select Button Size", 'nany'),
                 "group" => __( "Button", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Background color', 'nany'),
              "param_name"=> "bg_color",
              "value"=>"#497bb8",
              "description" => __( "Select background color for button.", 'nany'),
               "group" => __( "Button", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Text color', 'nany'),
              "param_name"=> "text_color",
              "value"=>"#ffffff",
              "description" => __( "Select text color for button.", 'nany'),
               "group" => __( "Button", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Text Transform", 'nany' ),
                "param_name" => "text_transform",
                "value" => array(
                            "Normal"=>'none',
                            "Uppercase"=>'uppercase',
                            "Capitalize"=>'capitalize',
                            "Lowercase"=>'lowercase'
                          ),
                "description" => __( "Select button text transform.", 'nany'),
                 "group" => __( "Button", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Top Space", 'nany' ),
                "param_name" => "btn_top_space",
                'value'=>'',
                "description" => __( "Button Top Space", 'nany'),
                 "group" => __( "Button", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Bottom Space", 'nany' ),
                "param_name" => "btn_bottom_space",
                'value'=>'',
                "description" => __( "Button Bottom Space", 'nany'),
                 "group" => __( "Button", 'nany')
            ),

            /* Custom CSS */
            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

          )
    ) );
  }
}


?>