<?php

/* ==========================================================
    Visual Composer - Process
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_process')) {
  function nany_process( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'content_bg'  => '',
      'extra_class'  => ''
    ), $atts));

    // Turn output buffer on
    ob_start();

    $process_tabs = ot_get_option('process_tabs');
    ?>
    <div class="<?php echo $extra_class; ?>">
    <div class="processlist">
      <ul class="proc-tabs">
        <?php
        if ($process_tabs) {
          foreach($process_tabs as $process_tab) : ?>
              <?php
              $process_title = $process_tab['title'];
              $own_id = preg_replace('/[^a-z]/', "-", strtolower($process_title));
              // Process tab start
              if($process_tab['title']) { ?>
                <li><a title="<?php echo esc_attr($own_id); ?>"><div class="tab-icon <?php echo $own_id; ?>" style="border-color:<?php echo $content_bg; ?>;"><div class="tab-icon-in <?php echo $own_id; ?>-in"><i class="fa <?php echo $process_tab['process_icon']; ?>"></i><h5><?php echo $process_title; ?></h5></div></div></a></li>
            <?php } endforeach;
          } ?>
      </ul>
    </div>
    <div class="process-content">
    <?php
    if ($process_tabs) {
      foreach($process_tabs as $process_tab) :
        $process_title = $process_tab['title'];
        $own_id = preg_replace('/[^a-z]/', "-", strtolower($process_title));
    ?>


        <div class="tab-content" id="<?php echo $own_id; ?>">
          <h4 style="background:<?php echo $content_bg; ?>;"><?php echo $process_title; ?></h4>
          <p style="background:<?php echo $content_bg; ?>;"><?php echo $process_tab['process_content']; ?></p>
        </div>

    <?php
      endforeach;
    }

    if(!$process_tabs) {
      echo '<p class="text-center">';
      echo __('Add process tabs at : Appearace > Theme Options > Shortcodes', 'nany');
      echo '</p>';
    }
    ?>
    </div>
    </div>
    <?php

    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'process', 'nany_process' );

/**
  Add to visual composer
**/
add_action( 'init', 'nany_process_vc_map' );
if ( ! function_exists( 'nany_process_vc_map' ) ) {
  function nany_process_vc_map() {
    vc_map( array(
        "name" =>"Process",
        "base" => "process",
        "description" => "Process Shortcode",
        "icon" => "vc-process",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "notification_info", // This is Nany's Own Custom Param.
                "heading" => __( "Shortcode", 'nany' ),
                "param_name" => "custom_notification_note",
                'value'=> 'Process from Theme Options',
                'admin_label'=> true,
                "description" => __( "This shortcode is called from : <strong>Appearance > Theme Options > Shortcode > Process Section</strong>. If you need to work this shortcode, please add them first on Theme Options.", 'nany')
            ),
            array(
                "type" => "colorpicker",
                "heading" => __( "Content BG Color", 'nany' ),
                "param_name" => "content_bg",
                'value'=>'',
                "description" => __( "Pick your row bg color here.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

          )
    ) );
  }
}


?>