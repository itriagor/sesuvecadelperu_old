<?php

/* ==========================================================
    Visual Composer - map
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_map')) {
  function nany_map( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'own_id'  => '',
      'map_height'  => '',
      'extra_class'  => '',
      'enter_address'  => '',
      'upload_map_icon'  => '',
      'map_zoom'  => '',
      'map_scroll_wheel'  => '',
      'disable_draggable_map'  => '',
      'disable_show_hide'  => '',
      'disable_show_hide_class'  => '',
      'showmap_text'  => '',
      'show_text_color'  => '',
      'show_bg_color'  => '',
     ), $atts));

    if ( $own_id ) {
      $own_id = $own_id;
    } else {
      $own_id = 'map';
    }
    if ( $map_height ) {
      $map_height = 'style="height:'. $map_height .'"';
    } else {
      $map_height = 'style="height:450px"';
    }
    if ( $enter_address ) {
      $enter_address = $enter_address;
    }
    if (!$showmap_text) {
      $showmap_text = 'Show Map';
    }
    if ($show_text_color) {
      $show_text_color = 'color:'. $show_text_color .';';
    }
    if ($show_bg_color) {
      $show_bg_color = 'background:'. $show_bg_color .';';
    }

    if (!$disable_show_hide) {
      $disable_show_hide = '<a class="viewnow" style="'. $show_text_color . $show_bg_color .'">'. $showmap_text .' <i class="fa fa-chevron-down"></i></a>';
      $disable_show_hide_class = 'map-show ';
    } else {
      $disable_show_hide = '';
    }

    $output = ''. $disable_show_hide .'<div class="'. $disable_show_hide_class . $extra_class .'"><div id="'. $own_id .'" '. $map_height .'></div></div>';


    // Google Map
    if($enter_address) {
      // Gmap Script
      wp_enqueue_script('gmap-sencor', 'https://maps.googleapis.com/maps/api/js?sensor=false', array('jquery'), '', true);
      wp_enqueue_script('gmap-scripts', SCRIPTS . '/gmap3.min.js', array('jquery'), '', true);
    ?>
    <script type="text/javascript">
    (function ($) {
    jQuery(document).ready(function($) {

        "use strict";

        <?php $own_id = '"#'. $own_id .'"'; ?>

          $(<?php echo $own_id; ?>).gmap3({

            <?php
            $inside_enter_address = $enter_address;
            if($map_scroll_wheel) {
              $map_scroll_wheel = 'true';
            } else {
              $map_scroll_wheel = 'false';
            }
            if(!$disable_draggable_map) {
              $disable_draggable_map = 'true';
            } else {
              $disable_draggable_map = 'false';
            }
            if($upload_map_icon) {
              $image_url = wp_get_attachment_url( $upload_map_icon );
              $upload_map_icon = $image_url;
            } else {
              $upload_map_icon = '' . IMAGES . '/map/map-marker.png';
            }
            ?>

            marker:{
              address:"<?php echo $inside_enter_address; ?>",
              options:{ icon: <?php echo "'$upload_map_icon'"; ?>}
            },

            map:{
              options:{
                zoom: <?php echo $map_zoom; ?>,
                scrollwheel: <?php echo $map_scroll_wheel; ?>,
                draggable: <?php echo $disable_draggable_map; ?>
              }
            }

          });

      });
    }(jQuery));
    </script>

  <?php
  }

    return $output;

  }
}
add_shortcode( 'map', 'nany_map' );

/**
  Add to visual composer
**/
add_action( 'init', 'nany_map_vc_map' );
if ( ! function_exists( 'nany_map_vc_map' ) ) {
  function nany_map_vc_map() {
    vc_map( array(
        "name" =>"Gmap",
        "base" => "map",
        "description" => "Google Map",
        "icon" => "vc-map",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "textfield",
                "heading" => __( "Enter your own ID", 'nany' ),
                "param_name" => "own_id",
                'value'=>'',
                "description" => __( "If you need more than one map shortcode in same page use this.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Map Height", 'nany' ),
                "param_name" => "map_height",
                'value'=> '',
                "description" => __( "Set map height in pixels. [Ex : 450px].", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Enter your address", 'nany' ),
                "param_name" => "enter_address",
                'value'=>'',
                'admin_label'=>true,
                "description" => __( "Format : Street No & Name, City & State, Country", 'nany')
            ),
            array(
                "type" => "attach_image",
                "heading" => __( "Upload your own icon", 'nany' ),
                "param_name" => "upload_map_icon",
                'value'=> '' . IMAGES . '/map/map-marker.png',
                "description" => __( "Upload your own icon or leave it blank if you want default.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Zoom Level", 'nany' ),
                "param_name" => "map_zoom",
                'value'=>'15',
                "description" => __( "Zoom level only in numeric, default 15.", 'nany')
            ),
            array(
              "type"=>'checkbox',
              "heading"=>__('Enable Scroll?', 'nany'),
              "param_name"=> "map_scroll_wheel",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need scroll option, check this.", 'nany')
            ),
            array(
              "type"=>'checkbox',
              "heading"=>__('Disable Draggable?', 'nany'),
              "param_name"=> "disable_draggable_map",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need to disable draggable, check this.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

            /* Show Map Group */
            array(
              "type"=>'checkbox',
              "heading"=>__('Disable Show/Hide Slide?', 'nany'),
              "param_name"=> "disable_show_hide",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need to disable show and hide slide, check this.", 'nany'),
              "group" => __( "Hide & Show", 'nany'),
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Show Map Text", 'nany' ),
                "param_name" => "showmap_text",
                'value'=> '',
                "description" => __( "Show map text", 'nany'),
                "group" => __( "Hide & Show", 'nany'),
            ),
            array(
                "type" => "colorpicker",
                "heading" => __( "Show Text Color", 'nany' ),
                "param_name" => "show_text_color",
                'value'=>'',
                "description" => __( "Pick the color for Show Map Text color.", 'nany'),
                "group" => __( "Hide & Show", 'nany'),
            ),
            array(
                "type" => "colorpicker",
                "heading" => __( "Show Text BG Color", 'nany' ),
                "param_name" => "show_bg_color",
                'value'=>'',
                "description" => __( "Pick the color for Show Map Text background color.", 'nany'),
                "group" => __( "Hide & Show", 'nany'),
            ),

          )
    ) );
  }
}


?>