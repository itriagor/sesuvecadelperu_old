<?php

/* ==========================================================
    Visual Composer - Testimonial
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_testimonial')) {
  function nany_testimonial( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'testimonial_name'  => '',
      'testimonial_profession'  => '',
      'testimonial_company'  => '',
      'testimonial_image'  => '',
      'testimonial_content'  => '',
      'testimonial_alignment'   => '',
      'extra_class'  => '',

      /* Color */
      'testimonial_name_color'  => '',
      'testimonial_profession_color'  => '',
      'testimonial_content_color'  => '',

      /* Font Size */
      'testimonial_name_size'  => '',
      'testimonial_profession_size'  => '',
      'testimonial_content_size'  => '',

      /* Others */
      'testimonial_arrow' => ''
    ), $atts));


    if ( $testimonial_image ) {
      $image_url = wp_get_attachment_url( $testimonial_image );
      $testimonial_image = '<img src="'. esc_attr($image_url) .'" alt="'. esc_attr($testimonial_name) .'" />';
    } else {
      $testimonial_image = '<img src="'. IMAGES .'/dummy/334x334.jpg" alt="'. esc_attr($testimonial_name) .'" />';
    }
    if($testimonial_alignment === 'left') {
      $testimonial_arrow = 'left: 15px;';
    }
    if($testimonial_alignment === 'right') {
      $testimonial_arrow = 'right: 15px;left: auto;';
    }
    if($testimonial_alignment) {
      $testimonial_alignment = 'text-align: '. $testimonial_alignment .';';
    }
    if($testimonial_name_color) {
      $testimonial_name_color = 'color: '. $testimonial_name_color .';';
    }
    if($testimonial_profession_color) {
      $testimonial_profession_color = 'color: '. $testimonial_profession_color .';';
    }
    if($testimonial_content_color) {
      $testimonial_content_color = 'color: '. $testimonial_content_color .';';
    }
    if($testimonial_name_size) {
      $testimonial_name_size = 'font-size: '. $testimonial_name_size .';';
    }
    if($testimonial_profession_size) {
      $testimonial_profession_size = 'font-size: '. $testimonial_profession_size .';';
    }
    if($testimonial_content_size) {
      $testimonial_content_size = 'font-size: '. $testimonial_content_size .';';
    }

    if ($testimonial_company) {
      $testimonial_company = '<small class="testi-company">'. $testimonial_company .'</small>';
    }

    $output = '<div class="testimonial '. $extra_class .'" style="'. $testimonial_alignment .'"><div class="testi-content"><p style="'. $testimonial_content_color . $testimonial_content_size .'">'. $testimonial_content .'</p><div class="testi-arrow" style="'. $testimonial_arrow .'"></div></div><div class="client-img">'. $testimonial_image .'</div><div class="testi-author"><h4 style="'. $testimonial_name_color . $testimonial_name_size .'">'. $testimonial_name .'</h4><span style="'. $testimonial_profession_color . $testimonial_profession_size .'">'. $testimonial_profession . $testimonial_company .'</span></div></div>';

    return $output;

  }
}
add_shortcode( 'testimonial', 'nany_testimonial' );

/**
  Add to visual composer
**/
add_action( 'init', 'nany_testimonial_vc_map' );
if ( ! function_exists( 'nany_testimonial_vc_map' ) ) {
  function nany_testimonial_vc_map() {
    vc_map( array(
        "name" =>"Testimonial",
        "base" => "testimonial",
        "description" => "Testimonial Styles",
        "icon" => "vc-testimonial",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
              "type"=>'textfield',
              "heading"=>__('Name', 'nany'),
              "param_name"=> "testimonial_name",
              "value"=>"John Smith",
              "admin_label"=> true,
              "description" => __( "Enter your client name.", 'nany')
            ),
            array(
              "type"=>'textfield',
              "heading"=>__('Profession', 'nany'),
              "param_name"=> "testimonial_profession",
              "value"=>"CEO, nany Inc.",
              "description" => __( "Enter your client profession.", 'nany')
            ),
            array(
              "type"=>'textfield',
              "heading"=>__('Company', 'nany'),
              "param_name"=> "testimonial_company",
              "value"=>"",
              "description" => __( "Enter your client company, if you want.", 'nany')
            ),
            array(
                "type" => "attach_image",
                "heading" => __( "Client Image", 'nany' ),
                "param_name" => "testimonial_image",
                'value'=>'',
                "description" => __( "Upload your client image. Recommended image size 210x210.", 'nany'),
            ),
            array(
                "type" => "textarea",
                "heading" => __( "Content", 'nany' ),
                "param_name" => "testimonial_content",
                'value'=>'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempora impedit numquam, quo debitis vero eveniet ducimus neque ipsam. Possimus, tempora.',
                "description" => __( "Enter your client testimonial content here.", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Alignment", 'nany' ),
                "param_name" => "testimonial_alignment",
                "value" => array(
                            "Center"=>'center',
                            "Left"=>'left',
                            "Right"=>'right'
                          ),
                "description" => __( "Testimonial alignment.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

            /* Color */
            array(
              "type"=>'colorpicker',
              "heading"=>__('Name Color', 'nany'),
              "param_name"=> "testimonial_name_color",
              "value"=>"",
              "description" => __( "Pick color for client name.", 'nany'),
              "group" => __( "Color", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Profession Color', 'nany'),
              "param_name"=> "testimonial_profession_color",
              "value"=>"",
              "description" => __( "Pick color for client profession.", 'nany'),
              "group" => __( "Color", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Content Color', 'nany'),
              "param_name"=> "testimonial_content_color",
              "value"=>"",
              "description" => __( "Pick color for client content.", 'nany'),
              "group" => __( "Color", 'nany')
            ),

            /* Font Size */
            array(
              "type"=>'textfield',
              "heading"=>__('Name Font Size', 'nany'),
              "param_name"=> "testimonial_name_size",
              "value"=>"",
              "description" => __( "Enter values in pixels. [Eg : 14px]", 'nany'),
              "group" => __( "Font Size", 'nany')
            ),
            array(
              "type"=>'textfield',
              "heading"=>__('Profession Font Size', 'nany'),
              "param_name"=> "testimonial_profession_size",
              "value"=>"",
              "description" => __( "Enter values in pixels. [Eg : 14px]", 'nany'),
              "group" => __( "Font Size", 'nany')
            ),
            array(
              "type"=>'textfield',
              "heading"=>__('Content Font Size', 'nany'),
              "param_name"=> "testimonial_content_size",
              "value"=>"",
              "description" => __( "Enter values in pixels. [Eg : 14px]", 'nany'),
              "group" => __( "Font Size", 'nany')
            ),

          )
    ) );
  }
}


?>