<?php

/* ==========================================================
    Visual Composer - List
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_list')) {
  function nany_list( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'list_icon'  => '',
      'list_text'  => '',
      'list_color'  => '',
      'font_size'  => '',
      'list_space'  => '',
      'extra_class'  => ''
    ), $atts));

    if ( $list_color ) {
      $list_color = 'color:'. $list_color .';';
    }
    if ( $font_size ) {
      $font_size = 'font-size:'. $font_size .';';
    }
    if ( $list_space ) {
      $list_space = 'line-height:'. $list_space .';';
    }

    $list_text = '<ul class="list-two '. $extra_class .'"><li class="'. $list_icon .'" style="'. $list_color . $font_size . $list_space .'">'.str_replace("\n","</li><li class='$list_icon' style=' $list_color $font_size $list_space' >",trim($list_text,"")).'</li></ul>';

    $output = $list_text;

    return $output;

  }
}
add_shortcode( 'list', 'nany_list' );


/**
  Add to visual composer
**/
add_action( 'init', 'nany_list_vc_map' );
if ( ! function_exists( 'nany_list_vc_map' ) ) {
  function nany_list_vc_map() {
    vc_map( array(
        "name" =>"List",
        "base" => "list",
        "description" => "List Styles",
        "icon" => "vc-list",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
              "type"=>'textfield',
              "heading"=>__('List Icon', 'nany'),
              "param_name"=> "list_icon",
              "value"=>"fa-heart",
              "admin_label" => true,
              "description" => __( "Select icon from <a href='http://fortawesome.github.io/Font-Awesome/cheatsheet/' target='_blank'>FontAwesome</a> lib. (Eg : fa-heart)", 'nany')
            ),

            array(
              "type"=>'textarea',
              "heading"=>__('List Text', 'nany'),
              "param_name"=> "list_text",
              "value"=> "List Item One\nList Item Two\nList Item Three\nList Item Four\nList Item Five",
              "description" => __( "New line as a new list.", 'nany')
            ),

            array(
              "type"=>'colorpicker',
              "heading"=>__('List Color', 'nany'),
              "param_name"=> "list_color",
              "value"=>"",
              "description" => __( "Select text & icon color for your list.", 'nany'),
              "group" => __( "Design", 'nany')
            ),

            array(
              "type"=>'textfield',
              "heading"=>__('Font Size', 'nany'),
              "param_name"=> "font_size",
              "value"=>"",
              "description" => __( "Enter your font size in px. [Eg: 14px]", 'nany'),
              "group" => __( "Design", 'nany')
            ),

            array(
              "type"=>'textfield',
              "heading"=>__('Each list space', 'nany'),
              "param_name"=> "list_space",
              "value"=>"",
              "description" => __( "Enter your list space in px. [Eg: 30px]", 'nany'),
              "group" => __( "Design", 'nany')
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

          )
    ) );
  }
}


?>