<?php

/* ==========================================================
    Visual Composer - Testimonial_slider
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_testimonial_slider')) {
  function nany_testimonial_slider( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'testimonial_slider_limit'  => '3',
      'testimonial_slider_order'  => '',
      'testimonial_slider_order_by'  => '',
      'extra_class'  => '',

      /* Color */
      'testimonial_slider_content_color'  => '',
      'testimonial_slider_name_color'  => '',
      'testimonial_slider_profession_color'  => '',

      /* Font Size */
      'testimonial_slider_content_size'  => '',
      'testimonial_slider_name_size'  => '',
      'testimonial_slider_profession_size'  => '',
    ), $atts));

    // Turn output buffer on
    ob_start();

    if($testimonial_slider_order) {
      $testimonial_slider_order = $testimonial_slider_order;
    } else {
      $testimonial_slider_order = 'ASC';
    }
    if($testimonial_slider_order_by) {
      $testimonial_slider_order_by = $testimonial_slider_order_by;
    } else {
      $testimonial_slider_order_by = 'title';
    }
    if($testimonial_slider_content_color) {
      $testimonial_slider_content_color = 'color:'. $testimonial_slider_content_color .';';
    }
    if($testimonial_slider_name_color) {
      $testimonial_slider_name_color = 'color:'. $testimonial_slider_name_color .';';
    }
    if($testimonial_slider_profession_color) {
      $testimonial_slider_profession_color = 'color:'. $testimonial_slider_profession_color .';';
    }
    if($testimonial_slider_content_size) {
      $testimonial_slider_content_size = 'font-size:'. $testimonial_slider_content_size .';';
    }
    if($testimonial_slider_name_size) {
      $testimonial_slider_name_size = 'font-size:'. $testimonial_slider_name_size .';';
    }
    if($testimonial_slider_profession_size) {
      $testimonial_slider_profession_size = 'font-size:'. $testimonial_slider_profession_size .';';
    }

    // The Query
    global $post;
    $nany_testimonial_query = new WP_Query(
      array(
        'post_type'     => 'testimonial',
        'posts_per_page'  => (int)$testimonial_slider_limit,
        'order'       => esc_attr($testimonial_slider_order),
        'orderby'     => esc_attr($testimonial_slider_order_by)
      )
    );
    ?>
    <div id="testi-slider" class="owl-carousel owl-theme <?php echo $extra_class; ?>">
    <?php
    //Output posts
    if ($nany_testimonial_query->have_posts()) : while ($nany_testimonial_query->have_posts()) : $nany_testimonial_query->the_post();

      // Testimonial start ?>
      <div class="testimonial-author">
        <div class="testimonial-author-content">
          <p <?php echo 'style="'. $testimonial_slider_content_color . $testimonial_slider_content_size .'"'; ?>><?php echo $post->post_content; ?></p>
        </div>
        <div class="testimonial-metas">
          <div class="testimonial-author-img">
            <?php
            if(get_post_meta( $post->ID, 'testimonial_client_image', true )) { ?>
            <img src="<?php echo esc_attr(get_post_meta( $post->ID, 'testimonial_client_image', true )); ?>" alt="<?php esc_attr(the_title()); ?>">
            <?php } else {
            echo '<img src="'. IMAGES .'/dummy/334x334.jpg" />';
            } ?>
          </div>
          <span class="testi-auth-name" <?php echo 'style="'. $testimonial_slider_name_color . $testimonial_slider_name_size .'"'; ?>><?php the_title(); ?></span>
          <span class="testi-auth-company" <?php echo 'style="'. $testimonial_slider_profession_color . $testimonial_slider_profession_size .'"'; ?>><?php echo get_post_meta( $post->ID, 'testimonial_client_profession', true ); ?></span>
        </div>
      </div>
    <?php endwhile; endif; ?>
    </div>
    <?php

    // Reset the WP query postdata
    wp_reset_postdata();

    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'testimonial_slider', 'nany_testimonial_slider' );

/**
  Add to visual composer
**/
add_action( 'init', 'nany_testimonial_slider_vc_map' );
if ( ! function_exists( 'nany_testimonial_slider_vc_map' ) ) {
  function nany_testimonial_slider_vc_map() {
    vc_map( array(
        "name" =>"Testimonial Slider",
        "base" => "testimonial_slider",
        "description" => "Testimonial Slider Styles",
        "icon" => "vc-testimonial_slider",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "notification_info", // This is nany's Own Custom Param.
                "heading" => __( "", 'nany' ),
                "param_name" => "custom_notification_note",
                'value'=>'',
                "description" => __( "This shortcode is called from : <strong>Testimonials Post Type</strong>.<br /> If you need to work this shortcode, please add them first on Testimonials Under Pages.", 'nany'),
                "group" => __( "Query", 'nany')
            ),

            array(
              "type"=>'textfield',
              "heading"=>__('Limit', 'nany'),
              "param_name"=> "testimonial_slider_limit",
              "value"=>"3",
              "admin_label"=> true,
              "description" => __( "Enter your testimonials slider limit.", 'nany'),
              "group" => __( "Query", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Order", 'nany' ),
                "param_name" => "testimonial_slider_order",
                "value" => array(
                            "Ascending"=>'ASC',
                            "Descending"=>'DESC'
                          ),
                "description" => __( "Select Testimonial order.", 'nany'),
                "group" => __( "Query", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Order By", 'nany' ),
                "param_name" => "testimonial_slider_order_by",
                "value" => array(
                            "none"=>'none',
                            "ID"=>'ID',
                            "Author"=>'author',
                            "Title"=>'title',
                            "Name"=>'name',
                            "Type"=>'type',
                            "Date"=>'date',
                            "Modified"=>'modified',
                            "Rand"=>'rand'
                          ),
                "description" => __( "Select Testimonial order.", 'nany'),
                "group" => __( "Query", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany'),
                "group" => __( "Query", 'nany')
            ),

            /* Color */
            array(
              "type"=>'colorpicker',
              "heading"=>__('Content Color', 'nany'),
              "param_name"=> "testimonial_slider_content_color",
              "value"=>"",
              "description" => __( "Pick color for testimonial content.", 'nany'),
              "group" => __( "Color", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Name Color', 'nany'),
              "param_name"=> "testimonial_slider_name_color",
              "value"=>"",
              "description" => __( "Pick color for name.", 'nany'),
              "group" => __( "Color", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Profession Color', 'nany'),
              "param_name"=> "testimonial_slider_profession_color",
              "value"=>"",
              "description" => __( "Pick color for testimonial profession.", 'nany'),
              "group" => __( "Color", 'nany')
            ),

            /* Font Size */
            array(
              "type"=>'textfield',
              "heading"=>__('Content Font Size', 'nany'),
              "param_name"=> "testimonial_slider_content_size",
              "value"=>"",
              "description" => __( "Enter values in pixels. [Eg : 14px]", 'nany'),
              "group" => __( "Font Size", 'nany')
            ),
            array(
              "type"=>'textfield',
              "heading"=>__('Name Font Size', 'nany'),
              "param_name"=> "testimonial_slider_name_size",
              "value"=>"",
              "description" => __( "Enter values in pixels. [Eg : 14px]", 'nany'),
              "group" => __( "Font Size", 'nany')
            ),
            array(
              "type"=>'textfield',
              "heading"=>__('Profession Font Size', 'nany'),
              "param_name"=> "testimonial_slider_profession_size",
              "value"=>"",
              "description" => __( "Enter values in pixels. [Eg : 14px]", 'nany'),
              "group" => __( "Font Size", 'nany')
            ),


          )
    ) );
  }
}


?>