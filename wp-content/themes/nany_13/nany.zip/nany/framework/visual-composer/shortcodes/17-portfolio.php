<?php

/* ==========================================================
    Visual Composer - portfolio
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_portfolio')) {
  function nany_portfolio( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'portfolio_columns'  => '',
      'portfolio_limit'  => '8',
      'enable_cat_filter'  => '',
      'portfolio_order'  => '',
      'portfolio_order_by'  => '',
      'port_offset'  => '',
      'show_category'  => '',
      'enable_pagination'  => '',
      'extra_class'  => '',
    ), $atts));

    // Turn output buffer on
    ob_start();

    /* Category Filter */
    if ($enable_cat_filter) {

        if ($show_category){
          $pf_item_slugs = str_replace(', ', ',', $show_category);
          $pf_item_slugs = rtrim($pf_item_slugs, ',');
          $pf_item_slugs =  explode(",", $pf_item_slugs);

          foreach ($pf_item_slugs as $pf_item_slug) {
            $pf_show_only[] ='.catfilter li a.'. $pf_item_slug;
          }
          $pf_show_only = implode(', ', $pf_show_only);
          echo '<style>.catfilter li a{display:none;} .catfilter li a.all, ' . $pf_show_only . '{display:inline !important;}</style>';
        }
      ?>
      <ul class="catfilter">
        <li class="active"><a href="javascript:void(0)" class="all"><?php _e('All', 'nany'); ?></a></li>
        <?php $terms = get_terms('portfolio_category');
          $count = count($terms);
          $i=0;
          $term_list = '';
          if ($count > 0) {
            foreach ($terms as $term) {
              $i++;
              $term_list .= '<li><a href="javascript:void(0)" class="'. $term->slug .'" title="' . esc_attr($term->name) . '">' . $term->name . '</a></li>';
              if ($count != $i) {
                $term_list .= '';
              } else {
                $term_list .= '';
              }
            }
            echo $term_list;
          }
        ?>
      </ul>
      <div class="clearfix"></div>
    <?php } ?>

    <!-- Portfolio Items -->
    <div id="port-items">
      <div class="port-main-wrap">
        <div class="port-inner-wrap">

          <ul class="nany-portfolio cat-container vc-portfolio <?php echo $extra_class; ?> <?php echo $portfolio_columns; ?>">

            <?php
            global $post;
            // $paged = get_query_var('paged') ? get_query_var('paged') : 1;
            // $wpbp = new WP_Query(array('post_type' => 'portfolio', 'posts_per_page' => $portfolio_limit, 'portfolio_category' => $show_category, 'paged' => $paged, 'offset' => $port_offset, 'orderby' => $portfolio_order_by, 'order' => $portfolio_order));

            // Pagination Issue Fixed
            global $paged;
            if( get_query_var( 'paged' ) )
              $my_page = get_query_var( 'paged' );
            else {
              if( get_query_var( 'page' ) )
                $my_page = get_query_var( 'page' );
              else
                $my_page = 1;
              set_query_var( 'paged', $my_page );
              $paged = $my_page;
            }

            // default loop here, if applicable, followed by wp_reset_query();

            $args = array(
              // other query params here,
              'paged' => esc_attr($my_page),
              'post_type' => 'portfolio',
              'posts_per_page' => (int)$portfolio_limit,
              'portfolio_category' => esc_attr($show_category),
              'offset' => (int)$port_offset,
              'orderby' => esc_attr($portfolio_order_by),
              'order' => esc_attr($portfolio_order)
            );

            $wpbp = new WP_Query( $args );

            if ($wpbp->have_posts()) : while ($wpbp->have_posts()) : $wpbp->the_post();

            $terms = wp_get_post_terms($post->ID, 'portfolio_category');

            if ( (function_exists('has_post_thumbnail')) && (has_post_thumbnail()) ) {
              $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
              $large_image = $large_image[0];

              if ($portfolio_columns === 'portfolio-3-column') {
                $portfolio_img = aq_resize( $large_image, '360', '260', true );
              } elseif ($portfolio_columns === 'portfolio-2-column') {
                $portfolio_img = aq_resize( $large_image, '560', '400', true );
              } else {
                $portfolio_img = aq_resize( $large_image, '255', '240', true );
              }
            } else {
              $large_image = IMAGES .'/dummy/560x400.jpg';

              if ($portfolio_columns === 'portfolio-3-column') {
                $portfolio_img = IMAGES .'/dummy/560x400.jpg';
              } elseif ($portfolio_columns === 'portfolio-2-column') {
                $portfolio_img = IMAGES .'/dummy/560x400.jpg';
              } else {
                $portfolio_img = IMAGES .'/dummy/255x240.jpg';
              }
            }


            ?>

            <li id="item-<?php echo $post->ID; ?>" class="portfolio-square" <?php if ($enable_cat_filter) { ?>data-id="id-<?php echo $count; ?>"<?php } ?> data-type="<?php foreach ($terms as $term) { echo $term->slug . ' ';} ?>">

                <div class="port-hover">
                    <div class="hover-text">
                        <?php echo get_the_term_list( $post->ID, 'portfolio_category', '<span class="port-categroy">', ', ', '</span>' ); ?>
                        <div class="categroy-sep"></div>
                        <span class="port-likes"><?php echo zilla_likes(); ?> <?php echo __('Likes', 'nany'); ?></span>
                        <span class="port-views"><i class="fa fa-eye"></i> <small><?php echo bawpvc_views_sc( $content = null ); ?></small> <?php echo __('Views', 'nany'); ?></span>
                    </div>
                </div>
                <a href="<?php echo esc_url(get_permalink()); ?>"><img src="<?php echo esc_attr($portfolio_img); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" /></a>
                <div class="port-title">
                  <a href="<?php echo esc_url($large_image); ?>" class="port-nub woo-popup-link">
                    <i class="fa fa-plus"></i>
                    <img src="<?php echo esc_attr(ot_get_option('title_nub')); ?>" alt="">
                  </a>
                  <a href="<?php echo esc_url(get_permalink()); ?>"><?php echo get_the_title(); ?></a>
                </div>

            </li>

            <?php if ($enable_cat_filter) { $count++; } ?>
            <?php endwhile; endif; ?>
            <?php wp_reset_query(); ?>
          </ul>
          <div class="clearfix"></div>

          </div>
        </div>
      </div>

    <!-- Paged navigation -->
    <?php if ($enable_pagination) { ?>
    <div class="post-navigation portfolio-nav">
      <?php
        if ( function_exists('wp_pagenavi')) {
            wp_pagenavi(array( 'query' => $wpbp ) );
            wp_reset_postdata();  // avoid errors further down the page
        }
      ?>
    </div>
    <?php } ?>

  <div class="clearfix"></div>

    <?php

    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'portfolio', 'nany_portfolio' );

/**
  Add to visual composer
**/
add_action( 'init', 'nany_portfolio_vc_map' );
if ( ! function_exists( 'nany_portfolio_vc_map' ) ) {
  function nany_portfolio_vc_map() {
    vc_map( array(
        "name" =>"Portfolio",
        "base" => "portfolio",
        "description" => "Portfolio Item Styles",
        "icon" => "vc-portfolio",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "dropdown",
                "heading" => __( "Columns", 'nany' ),
                "param_name" => "portfolio_columns",
                "value" => array(
                            "4 Column"=>'portfolio-4-column',
                            "3 Column"=>'portfolio-3-column',
                            "2 Column"=>'portfolio-2-column'
                          ),
                "admin_label" => true,
                "description" => __( "Select portfolio order.", 'nany')
            ),
            array(
              "type"=>'textfield',
              "heading"=>__('Limit', 'nany'),
              "param_name"=> "portfolio_limit",
              "value"=>"8",
              "description" => __( "Enter your portfolios items limit per page.", 'nany')
            ),
            array(
              "type"=>'checkbox',
              "heading"=>__('Enable Category Filter', 'nany'),
              "param_name"=> "enable_cat_filter",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you want category filter then check this.", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Order", 'nany' ),
                "param_name" => "portfolio_order",
                "value" => array(
                            "Ascending"=>'ASC',
                            "Descending"=>'DESC'
                          ),
                "description" => __( "Select portfolio order.", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Order By", 'nany' ),
                "param_name" => "portfolio_order_by",
                "value" => array(
                            "none"=>'none',
                            "ID"=>'ID',
                            "Author"=>'author',
                            "Title"=>'title',
                            "Name"=>'name',
                            "Type"=>'type',
                            "Date"=>'date',
                            "Modified"=>'modified',
                            "Rand"=>'rand'
                          ),
                "description" => __( "Select portfolio orderby.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Offset", 'nany' ),
                "param_name" => "port_offset",
                'value'=>'',
                "description" => __( "Enter a number to offset portfolio items.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Show only certain categories?", 'nany' ),
                "param_name" => "show_category",
                'value'=>'',
                "description" => __( "Enter category SLUGS (comma separated) you want to display.", 'nany')
            ),
            array(
              "type"=>'checkbox',
              "heading"=>__('Enable Pagination', 'nany'),
              "param_name"=> "enable_pagination",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you want pagination please check this.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

          )
    ) );
  }
}


?>