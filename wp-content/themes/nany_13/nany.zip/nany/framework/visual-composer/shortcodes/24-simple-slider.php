<?php

/* ==========================================================
    Visual Composer - simple_slider
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_simple_slider')) {
  function nany_simple_slider( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'attach_screeshots'  => '',
      'attachment_img'  => '',
      'extra_class'  => ''
    ), $atts));

    // Turn output buffer on
    ob_start();

    // Get Attachments
    $attachments = explode(",",$attach_screeshots);
    $attachments = array_combine($attachments,$attachments);

    ?>
    <div id="simple-slider-1" class="owl-carousel owl-theme zoom-gallery <?php echo $extra_class; ?> normal-arrow">
    <?php
          if ($attachments) {
          foreach ( $attachments as $attachment ) :

            if ( $attachment ) {
              $attachment_img = wp_get_attachment_url( $attachment );
            }
            $attachment_alt = strip_tags( get_post_meta($attachment, '_wp_attachment_image_alt', true) );

            ?>
            <a href="<?php echo esc_url($attachment_img); ?>" class="image-popup-fit-width" title="<?php echo esc_attr($attachment_alt); ?>">
                <img src="<?php echo esc_attr($attachment_img); ?>" alt="<?php echo esc_attr($attachment_alt); ?>" />
            </a>
          <?php endforeach; } ?>
    </div>
    <?php

    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'simple_slider', 'nany_simple_slider' );

/**
  Add to visual composer
**/
add_action( 'init', 'nany_simple_slider_vc_map' );
if ( ! function_exists( 'nany_simple_slider_vc_map' ) ) {
  function nany_simple_slider_vc_map() {
    vc_map( array(
        "name" =>"Simple Slider",
        "base" => "simple_slider",
        "description" => "Images Simple Slider",
        "icon" => "vc-simple_slider",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "attach_images",
                "heading" => __( "Select Image to Slide", 'nany' ),
                "param_name" => "attach_screeshots",
                'value'=>'',
                'admin_label'=> true,
                "description" => __( "Attach multiple images here, this will convert to slider.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

          )
    ) );
  }
}


?>