<?php
/**
 * Add new params to the vc composer
 *
 * @package WordPress
 * @subpackage Total
 * @since Total 1.0
 */


// Leave file if the vc_add_param parameter doesn't exist
if ( !function_exists('vc_add_param') ) {
	return;
}

/* ==============================================
   Rows
=============================================== */
/* General */
vc_add_param( "vc_row", array(
    "type" => "textfield",
    "heading" => __( "Row ID", 'nany' ),
    "param_name" => "row_id",
    'value'=> '',
    "description" => __( "Enter your custom id here. You can use it on <strong>Custom Menu</strong> section, for one page smooth scroll.", 'nany'),
) );
vc_add_param( "vc_row", array(
    "type" => "checkbox",
    "heading" => __( "Center Row Content", 'nany' ),
    "param_name" => "center_row_content",
    'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
    "description" => __( "Check this if you want this row content are aligned in center.", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "checkbox",
    "heading" => __( "Remove Right & Left Spaces", 'nany' ),
    "param_name" => "col_right_left_space",
    'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
    "description" => __( "Check this if you want this remove right and left column spaces.", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "dropdown",
    "heading" => __( "Section Nubs", 'nany' ),
    "param_name" => "select_pre_nubs",
    "value" => array(
      "None"=>'',
      "Custom Image"=>'custom',
      "White"=>'white',
      "Dark"=>'dark',
      "Light Dark"=>'light-dark',
      "Grey"=>'grey',
      "Theme Blue"=>'blue',
      "Twitter Blue"=>'twitter-blue',
      "Dark Yellow"=>'dark-yellow',
      "Dark Sky Blue"=>'dark-sky-blue',
      "Light Red"=>'light-red'
    ),
    "description" => __( "For detailed information : Appearance > Theme Options > Header > Title area Nub", 'nany'),
) );
vc_add_param( "vc_row", array(
    "type" => "attach_image",
    "heading" => __( "Upload your own custom nub", 'nany' ),
    "param_name" => "row_nub_image",
    'value'=> '',
    'dependency'  => Array(
                      'element' => "select_pre_nubs",
                      'value'   => array( 'custom' ),
                    ),
    "description" => __( "Upload section nub image here.", 'nany'),
) );
/* Design */
vc_add_param( "vc_row", array(
    "type" => "dropdown",
    "heading" => __( "Visibility", 'nany' ),
    "param_name" => "custom_row_visibility",
    "value" => array(
      "All"=>'',
      "Hidden On Phones"=>'hidden-sm',
      "Hidden On Tablets"=>'hidden-md',
      "Hidden On Desktop"=>'hidden-lg',
      "Visible On Desktop Only"=>'visible-lg',
      "Visible On Phones Only"=>'visible-md',
      "Visible On Tablets Only"=>'visible-sm'
    ),
    "description" => __( "Select which device you want and don't want, leave it for default settings.", 'nany'),
    "group" => __( "Design", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "colorpicker",
    "heading" => __( "Text Color", 'nany' ),
    "param_name" => "row_text_color",
    'value'=> '',
    "description" => __( "Note : This only apply when inside elements are not have own color property.", 'nany'),
    "group" => __( "Design", 'nany')
) );
/* Background */
vc_add_param( "vc_row", array(
    "type" => "colorpicker",
    "heading" => __( "Background Color", 'nany' ),
    "param_name" => "row_bg_color",
    'value'=> '',
    "description" => __( "Pick background color for this row.", 'nany'),
    "group" => __( "Background", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "dropdown",
    "heading" => __( "Background Image Style", 'nany' ),
    "param_name" => "row_bg_image_style",
    "value" => array(
      "Fixed"=>'fixed',
      "Cover"=>'cover',
      "Repeat"=>'repeat'
    ),
    "description" => __( "Select background image style.", 'nany'),
    "group" => __( "Background", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "checkbox",
    "heading" => __( "Enable Parallax", 'nany' ),
    "param_name" => "row_bg_background_parallax",
    'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
    "description" => __( "If you want background image as a parallax effect, check this.", 'nany'),
    "group" => __( "Background", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "textfield",
    "heading" => __( "Parallax Ratio", 'nany' ),
    "param_name" => "row_parallax_ratio",
    'value'=> '0.5',
    'dependency'  => Array(
                      'element' => "row_bg_background_parallax",
                      'value'   => array( 'yes' ),
                    ),
    "description" => __( "Enter parallax ratio here.", 'nany'),
    "group" => __( "Background", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "checkbox",
    "heading" => __( "Need Background Overlay?", 'nany' ),
    "param_name" => "enable_background_overlay",
    'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
    "description" => __( "If you want background overlay, check this.", 'nany'),
    "group" => __( "Background", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "attach_image",
    "heading" => __( "Background Image", 'nany' ),
    "param_name" => "row_bg_image",
    'value'=> '',
    "description" => __( "Select image from media library.", 'nany'),
    "group" => __( "Background", 'nany')
) );
/* Video */
vc_add_param( "vc_row", array(
    "type" => "checkbox",
    "heading" => __( "Enable Video Background?", 'nany' ),
    "param_name" => "enable_video_background",
    'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
    "description" => __( "If you want video background, check this.", 'nany'),
    "group" => __( "Video", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "notification_error", // This is nany's Own Custom Param.
    "heading" => __( "", 'nany' ),
    "param_name" => "custom_notification_note",
    'value'=>'',
    "description" => __( "If you need video Background you should given a value of <strong>Row ID in General Tab</strong>.", 'nany'),
    "group" => __( "Video", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "textfield",
    "heading" => __( "YouTube Video URL", 'nany' ),
    "param_name" => "video_url",
    'value'=> '',
    'dependency'  => Array(
                      'element' => "enable_video_background",
                      'value'   => array( 'yes' ),
                    ),
    "description" => __( "Just paste your YouTube video URL here.", 'nany'),
    "group" => __( "Video", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "checkbox",
    "heading" => __( "Enable Advanced Option?", 'nany' ),
    "param_name" => "advanced_options",
    'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
    'dependency'  => Array(
                      'element' => "enable_video_background",
                      'value'   => array( 'yes' ),
                    ),
    "description" => __( "If you need advanced option check this, otherwise default value will take.", 'nany'),
    "group" => __( "Video", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "checkbox",
    "heading" => __( "Need Controls?", 'nany' ),
    "param_name" => "need_controls",
    'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
    'dependency'  => Array(
                      'element' => "advanced_options",
                      'value'   => array( 'yes' ),
                    ),
    "description" => __( "If you need controls of this video, check this.", 'nany'),
    "group" => __( "Video", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "checkbox",
    "heading" => __( "Disable Auto Play?", 'nany' ),
    "param_name" => "disable_auto_play",
    'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
    'dependency'  => Array(
                      'element' => "advanced_options",
                      'value'   => array( 'yes' ),
                    ),
    "description" => __( "If you need to play video as a Auto Play check this.", 'nany'),
    "group" => __( "Video", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "checkbox",
    "heading" => __( "Disable Video Loop?", 'nany' ),
    "param_name" => "disable_video_loop",
    'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
    'dependency'  => Array(
                      'element' => "advanced_options",
                      'value'   => array( 'yes' ),
                    ),
    "description" => __( "If you need to play video as a loop mode check this.", 'nany'),
    "group" => __( "Video", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "checkbox",
    "heading" => __( "Disable Audio Mute?", 'nany' ),
    "param_name" => "disable_audio_mute",
    'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
    'dependency'  => Array(
                      'element' => "advanced_options",
                      'value'   => array( 'yes' ),
                    ),
    "description" => __( "If you need to mute this video check this.", 'nany'),
    "group" => __( "Video", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "textfield",
    "heading" => __( "Video Start Time", 'nany' ),
    "param_name" => "start_time",
    'value'     => '',
    'dependency'  => Array(
                      'element' => "advanced_options",
                      'value'   => array( 'yes' ),
                    ),
    "description" => __( "You can change video start time here. In Seconds [Eg : 60]", 'nany'),
    "group" => __( "Video", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "textfield",
    "heading" => __( "Video Quality", 'nany' ),
    "param_name" => "video_quality",
    'value'     => '',
    'dependency'  => Array(
                      'element' => "advanced_options",
                      'value'   => array( 'yes' ),
                    ),
    "description" => __( "Enter video quality. Values are : hd720, large, medium, small", 'nany'),
    "group" => __( "Video", 'nany')
) );
/* Border */
vc_add_param( "vc_row", array(
    "type" => "dropdown",
    "heading" => __( "Border Style", 'nany' ),
    "param_name" => "border_style",
    "value" => array(
      "None"=>'none',
      "Solid"=>'solid',
      "Dotted"=>'dotted',
      "Dashed"=>'dashed'
    ),
    "description" => __( "Select border style.", 'nany'),
    "group" => __( "Border", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "colorpicker",
    "heading" => __( "Border Color", 'nany' ),
    "param_name" => "border_color",
    'value'=> '',
    "description" => __( "Pick border color for this row.", 'nany'),
    "group" => __( "Border", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "textfield",
    "heading" => __( "Border Width", 'nany' ),
    "param_name" => "border_width",
    'value'=> '',
    "description" => __( "Your border width. Example: 1px 1px 1px 1px", 'nany'),
    "group" => __( "Border", 'nany')
) );
/* Margin */
vc_add_param( "vc_row", array(
    "type" => "textfield",
    "heading" => __( "Margin Top", 'nany' ),
    "param_name" => "row_margin_top",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Margin", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "textfield",
    "heading" => __( "Margin Bottom", 'nany' ),
    "param_name" => "row_margin_bottom",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Margin", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "textfield",
    "heading" => __( "Margin Left", 'nany' ),
    "param_name" => "row_margin_left",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Margin", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "textfield",
    "heading" => __( "Margin Right", 'nany' ),
    "param_name" => "row_margin_right",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Margin", 'nany')
) );
/* Padding */
vc_add_param( "vc_row", array(
    "type" => "textfield",
    "heading" => __( "Padding Top", 'nany' ),
    "param_name" => "row_padding_top",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Padding", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "textfield",
    "heading" => __( "Padding Bottom", 'nany' ),
    "param_name" => "row_padding_bottom",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Padding", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "textfield",
    "heading" => __( "Padding Left", 'nany' ),
    "param_name" => "row_padding_left",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Padding", 'nany')
) );
vc_add_param( "vc_row", array(
    "type" => "textfield",
    "heading" => __( "Padding Right", 'nany' ),
    "param_name" => "row_padding_right",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Padding", 'nany')
) );


/* ==============================================
    VC Column
=============================================== */
/* Animation */
vc_add_param( "vc_column", array(
    "type" => "dropdown",
    "heading" => __( "Animation Style", 'nany' ),
    "param_name" => "column_animation",
    "value" => array(
      "none"=>'none',
      "fadeIn"=>'fadeIn wow',
      "fadeInDown"=>'fadeInDown wow',
      "fadeInDownBig"=>'fadeInDownBig wow',
      "fadeInLeft"=>'fadeInLeft wow',
      "fadeInLeftBig"=>'fadeInLeftBig wow',
      "fadeInRight"=>'fadeInRight wow',
      "fadeInRightBig"=>'fadeInRightBig wow',
      "fadeInUp"=>'fadeInUp wow',
      "fadeInUpBig"=>'fadeInUpBig wow',
      "fadeOut"=>'fadeOut wow',
      "fadeOutDown"=>'fadeOutDown wow',
      "fadeOutDownBig"=>'fadeOutDownBig wow',
      "fadeOutLeft"=>'fadeOutLeft wow',
      "fadeOutLeftBig"=>'fadeOutLeftBig wow',
      "fadeOutRight"=>'fadeOutRight wow',
      "fadeOutRightBig"=>'fadeOutRightBig wow',
      "fadeOutUp"=>'fadeOutUp wow',
      "fadeOutUpBig"=>'fadeOutUpBig wow',
      "flip"=>'flip wow',
      "flipInX"=>'flipInX wow',
      "flipInY"=>'flipInY wow',
      "flipOutX"=>'flipOutX wow',
      "flipOutY"=>'flipOutY wow',
      "bounce"=>'bounce wow',
      "flash"=>'flash wow',
      "pulse"=>'pulse wow',
      "rubberBand"=>'rubberBand wow',
      "shake"=>'shake wow',
      "swing"=>'swing wow',
      "tada"=>'tada wow',
      "wobble"=>'wobble wow',
      "bounceIn"=>'bounceIn wow',
      "bounceInDown"=>'bounceInDown wow',
      "bounceInLeft"=>'bounceInLeft wow',
      "bounceInRight"=>'bounceInRight wow',
      "bounceInUp"=>'bounceInUp wow',
      "bounceOut"=>'bounceOut wow',
      "bounceOutDown"=>'bounceOutDown wow',
      "bounceOutLeft"=>'bounceOutLeft wow',
      "bounceOutRight"=>'bounceOutRight wow',
      "bounceOutUp"=>'bounceOutUp wow',
      "lightSpeedIn"=>'lightSpeedIn wow',
      "lightSpeedOut"=>'lightSpeedOut wow',
      "rotateIn"=>'rotateIn wow',
      "rotateInDownLeft"=>'rotateInDownLeft wow',
      "rotateInDownRight"=>'rotateInDownRight wow',
      "rotateInUpLeft"=>'rotateInUpLeft wow',
      "rotateInUpRight"=>'rotateInUpRight wow',
      "rotateOut"=>'rotateOut wow',
      "rotateOutDownLeft"=>'rotateOutDownLeft wow',
      "rotateOutDownRight"=>'rotateOutDownRight wow',
      "rotateOutUpLeft"=>'rotateOutUpLeft wow',
      "rotateOutUpRight"=>'rotateOutUpRight wow',
      "hinge"=>'hinge wow',
      "rollIn"=>'rollIn wow',
      "rollOut"=>'rollOut wow',
      "zoomIn"=>'zoomIn wow',
      "zoomInDown"=>'zoomInDown wow',
      "zoomInLeft"=>'zoomInLeft wow',
      "zoomInRight"=>'zoomInRight wow',
      "zoomInUp"=>'zoomInUp wow',
      "zoomOut"=>'zoomOut wow',
      "zoomOutDown"=>'zoomOutDown wow',
      "zoomOutLeft"=>'zoomOutLeft wow',
      "zoomOutRight"=>'zoomOutRight wow',
      "zoomOutUp"=>'zoomOutU wowp'
    ),
    "description" => __( "Select animation type for this column. Live Action : <a href='http://daneden.github.io/animate.css/' target='_blank'>Animate.css</a>", 'nany'),
    "group" => __( "Animation", 'nany')
) );
/* Border */
vc_add_param( "vc_column", array(
    "type" => "dropdown",
    "heading" => __( "Border Style", 'nany' ),
    "param_name" => "column_border_style",
    "value" => array(
      "None"=>'none',
      "Solid"=>'solid',
      "Dotted"=>'dotted',
      "Dashed"=>'dashed'
    ),
    "description" => __( "Select border style.", 'nany'),
    "group" => __( "Border", 'nany')
) );
vc_add_param( "vc_column", array(
    "type" => "colorpicker",
    "heading" => __( "Border Color", 'nany' ),
    "param_name" => "column_border_color",
    'value'=> '',
    "description" => __( "Pick border color for this column.", 'nany'),
    "group" => __( "Border", 'nany')
) );
vc_add_param( "vc_column", array(
    "type" => "textfield",
    "heading" => __( "Border Width", 'nany' ),
    "param_name" => "column_border_width",
    'value'=> '',
    "description" => __( "Your border width. Example: 1px 1px 1px 1px", 'nany'),
    "group" => __( "Border", 'nany')
) );
/* Margin */
vc_add_param( "vc_column", array(
    "type" => "textfield",
    "heading" => __( "Margin Top", 'nany' ),
    "param_name" => "column_margin_top",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Margin", 'nany')
) );
vc_add_param( "vc_column", array(
    "type" => "textfield",
    "heading" => __( "Margin Bottom", 'nany' ),
    "param_name" => "column_margin_bottom",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Margin", 'nany')
) );
vc_add_param( "vc_column", array(
    "type" => "textfield",
    "heading" => __( "Margin Left", 'nany' ),
    "param_name" => "column_margin_left",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Margin", 'nany')
) );
vc_add_param( "vc_column", array(
    "type" => "textfield",
    "heading" => __( "Margin Right", 'nany' ),
    "param_name" => "column_margin_right",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Margin", 'nany')
) );
/* Padding */
vc_add_param( "vc_column", array(
    "type" => "textfield",
    "heading" => __( "Padding Top", 'nany' ),
    "param_name" => "column_padding_top",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Padding", 'nany')
) );
vc_add_param( "vc_column", array(
    "type" => "textfield",
    "heading" => __( "Padding Bottom", 'nany' ),
    "param_name" => "column_padding_bottom",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Padding", 'nany')
) );
vc_add_param( "vc_column", array(
    "type" => "textfield",
    "heading" => __( "Padding Left", 'nany' ),
    "param_name" => "column_padding_left",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Padding", 'nany')
) );
vc_add_param( "vc_column", array(
    "type" => "textfield",
    "heading" => __( "Padding Right", 'nany' ),
    "param_name" => "column_padding_right",
    'value'=> '',
    "description" => __( "Values in pixels. [Eg: 20px]", 'nany'),
    "group" => __( "Padding", 'nany')
) );