<?php

/* ==========================================================
    Visual Composer - blog
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_blog')) {
  function nany_blog( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'blog_style'  => '',
      'blog_limit'  => '8',
      'blog_order'  => '',
      'blog_order_by'  => '',
      'port_offset'  => '',
      'show_category'  => '',
      'enable_pagination'  => '',
      'extra_class'  => '',
    ), $atts));

    // Turn output buffer on
    ob_start();
    ?>

    <!-- Blog Posts -->
    <div class="col-lg-12 vc-blog <?php echo $extra_class; ?>">

      <?php
        global $post;
        // $paged = get_query_var('paged') ? get_query_var('paged') : 1;
        // $wpbp = new WP_Query(array('post_type' => 'post', 'posts_per_page' => $blog_limit, 'category_name' => $show_category, 'paged' => $paged, 'offset' => $port_offset, 'orderby' => $blog_order_by, 'order' => $blog_order));
        //
        // Pagination Issue Fixed
        global $paged;
        if( get_query_var( 'paged' ) )
          $my_page = get_query_var( 'paged' );
        else {
          if( get_query_var( 'page' ) )
            $my_page = get_query_var( 'page' );
          else
            $my_page = 1;
          set_query_var( 'paged', $my_page );
          $paged = $my_page;
        }

        // default loop here, if applicable, followed by wp_reset_query();
        $args = array(
          // other query params here,
          'paged' => esc_attr($my_page),
          'post_type' => 'post',
          'posts_per_page' => (int)$blog_limit,
          'category_name' => esc_attr($show_category),
          'offset' => (int)$port_offset,
          'orderby' => esc_attr($blog_order_by),
          'order' => esc_attr($blog_order)
        );

        $wpbp = new WP_Query( $args );

        $blog_readmore_btn = ot_get_option('blog_readmore_btn');
        if($blog_readmore_btn) {
          $blog_readmore_btn = $blog_readmore_btn;
        } else {
          $blog_readmore_btn = __( 'Read More', 'nany' );
        }
      ?>

      <?php
      /* Style One */
      if ($blog_style === 'style-1') {
        if ($wpbp->have_posts()) : while ($wpbp->have_posts()) : $wpbp->the_post(); ?>
          <div class="blog-style-1">
            <?php
            if ( has_post_thumbnail() && ! post_password_required() ) :
              $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumbnail_size' );
              $url = $thumb['0'];
            ?>
            <span class="blog-style-image" style="background-image:url(<?php echo $url; ?>);"></span>
            <?php
            else : ?>
            <span class="blog-style-image"></span>
            <?php
            endif;
            ?>
            <div class="blog-style-content">
              <div class="post-meta-before"><?php nany_post_meta_before(); ?></div>
              <a href="<?php esc_url(the_permalink()); ?>"><h2 class="post-title"><?php the_title(); ?></h2></a>
              <div class="post-meta-after"><?php nany_post_meta_after(); ?></div>
              <div class="post-excerpt"><?php the_excerpt(); ?></div>
              <a href="<?php esc_url(the_permalink()); ?>" class="read-more uppercase"><?php echo $blog_readmore_btn; ?></a>
            </div>
          </div>
      <?php
        endwhile;
        else :
          get_template_part( 'content', 'none' );
        endif;
      }

      /* Normal Blog */
      if ($blog_style === 'style-2') {
        if ($wpbp->have_posts()) : while ($wpbp->have_posts()) : $wpbp->the_post();
          get_template_part( 'content', get_post_format() );
        endwhile;
        else :
          get_template_part( 'content', 'none' );
        endif;
      }
      ?>

      <?php wp_reset_query(); ?>
    </div>

    <!-- Paged navigation -->
    <?php if ($enable_pagination) { ?>
      <div class="post-navigation float-left">
        <?php
          if ( function_exists('wp_pagenavi')) {
              wp_pagenavi(array( 'query' => $wpbp ) );
              wp_reset_postdata();  // avoid errors further down the page
          }
        ?>
      </div>
    <?php }

    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'blog', 'nany_blog' );

/**
  Add to visual composer
**/
add_action( 'init', 'nany_blog_vc_map' );
if ( ! function_exists( 'nany_blog_vc_map' ) ) {
  function nany_blog_vc_map() {
    vc_map( array(
        "name" =>"Blog",
        "base" => "blog",
        "description" => "Blog Post Styles",
        "icon" => "vc-blog",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "dropdown",
                "heading" => __( "Style", 'nany' ),
                "param_name" => "blog_style",
                "value" => array(
                            "Style One"=>'style-1',
                            "Style Two"=>'style-2'
                          ),
                "description" => __( "Select blog style.", 'nany')
            ),
            array(
              "type"=>'textfield',
              "heading"=>__('Limit', 'nany'),
              "param_name"=> "blog_limit",
              "value"=>"8",
              "admin_label"=>true,
              "description" => __( "Enter your blogs Posts limit per page.", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Order", 'nany' ),
                "param_name" => "blog_order",
                "value" => array(
                            "Ascending"=>'ASC',
                            "Descending"=>'DESC'
                          ),
                "description" => __( "Select blog order.", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Order By", 'nany' ),
                "param_name" => "blog_order_by",
                "value" => array(
                            "none"=>'none',
                            "ID"=>'ID',
                            "Author"=>'author',
                            "Title"=>'title',
                            "Name"=>'name',
                            "Type"=>'type',
                            "Date"=>'date',
                            "Modified"=>'modified',
                            "Rand"=>'rand'
                          ),
                "description" => __( "Select blog orderby.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Offset", 'nany' ),
                "param_name" => "port_offset",
                'value'=>'',
                "description" => __( "Enter a number to offset blog Posts.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Show only certain categories?", 'nany' ),
                "param_name" => "show_category",
                'value'=>'',
                "description" => __( "Enter category SLUGS (comma separated) you want to display.", 'nany')
            ),
            array(
              "type"=>'checkbox',
              "heading"=>__('Enable Pagination', 'nany'),
              "param_name"=> "enable_pagination",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you want pagination please check this.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

          )
    ) );
  }
}


?>