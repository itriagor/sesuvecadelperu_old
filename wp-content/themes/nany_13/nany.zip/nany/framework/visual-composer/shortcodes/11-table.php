<?php

/* ==========================================================
    Visual Composer - Table
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_table')) {
  function nany_table( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'table_style'  => '',
      'table_head_text'  => '',
      'row_text'  => '',
      'head_text_color'  => '',
      'head_bg_color'  => '',
      'content_color'  => '',
      'text_bg_color'  => '',
      'table_border_color'  => '',
      'extra_class'  => ''
    ), $atts));

    if($table_style) {
      $table_style = 'table-style-'.$table_style.'';
    } else {
      $table_style = '';
    }

    if ( $head_text_color ) {
      $head_text_color = 'color:'. $head_text_color .';';
    }
    if ( $head_bg_color ) {
      $head_bg_color = 'background-color:'. $head_bg_color .';';
    }
    if ( $content_color ) {
      $content_color = 'color:'. $content_color .';';
    }
    if ( $text_bg_color ) {
      $text_bg_color = 'background-color:'. $text_bg_color .';';
    }
    if ( $table_border_color ) {
      $table_border_color = 'style="border-color:'. $table_border_color .';"';
    }

    $table_head_text = '<div class="'. $table_style .' '. $extra_class .'" '. $table_border_color .'><table><thead><tr><th style="'. $head_text_color . $head_bg_color .'">'. str_replace("\n","</th><th style=\"$head_text_color$head_bg_color\">",trim($table_head_text,"")) .'</th></tr></thead><tbody><tr><td style="'. $content_color . $text_bg_color .'">'. str_replace(array("\n", "|"), array("</td></tr><tr><td style=\"$content_color$text_bg_color\">", "</td><td style=\"$content_color$text_bg_color\">"), trim($row_text,"")) .'</td></tr></tbody></table></div>';

    $output = $table_head_text;

    return $output;

  }
}
add_shortcode( 'table', 'nany_table' );


/**
  Add to visual composer
**/
add_action( 'init', 'nany_table_vc_map' );
if ( ! function_exists( 'nany_table_vc_map' ) ) {
  function nany_table_vc_map() {
    vc_map( array(
        "name" =>"Table",
        "base" => "table",
        "description" => "Table Styles",
        "icon" => "vc-table",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "dropdown",
                "heading" => __( "Table Style", 'nany' ),
                "param_name" => "table_style",
                "value" => array(
                            "Style One"=>'one',
                            "Style Two"=>'two',
                            "Style Three"=>'three',
                            "Style Four"=>'four'
                          ),
                "admin_label" => true,
                "description" => __( "Select Table Style", 'nany')
            ),

            array(
              "type"=>'textarea',
              "heading"=>__('Table Head Text', 'nany'),
              "param_name"=> "table_head_text",
              "value"=>"Relation\nName\nGender\nActive",
              "description" => __( "New line as a new column.", 'nany')
            ),

            array(
              "type"=>'textarea',
              "heading"=>__('Row Text', 'nany'),
              "param_name"=> "row_text",
              "value"=>"Single | John Smith | Male | 12 hours ago\nMarried | Barbara | Female | 05 mins ago\nIn Relationship | Maximus | Male | 2 days ago",
              "description" => __( "New line as a new row, each row texts are separated by '|' for above represent columns.", 'nany')
            ),

            array(
              "type"=>'colorpicker',
              "heading"=>__('Head Text Color', 'nany'),
              "param_name"=> "head_text_color",
              "value"=>"",
              "description" => __( "Select head text color for your table.", 'nany'),
              "group" => __( "Design", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Head Background Color', 'nany'),
              "param_name"=> "head_bg_color",
              "value"=>"",
              "description" => __( "Select head bg color for your table.", 'nany'),
              "group" => __( "Design", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Content Color', 'nany'),
              "param_name"=> "content_color",
              "value"=>"",
              "description" => __( "Select content color for your table.", 'nany'),
              "group" => __( "Design", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Text Background Color', 'nany'),
              "param_name"=> "text_bg_color",
              "value"=>"",
              "description" => __( "Select text bg color for your table.", 'nany'),
              "group" => __( "Design", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Table Border Color', 'nany'),
              "param_name"=> "table_border_color",
              "value"=>"",
              "description" => __( "Select border color for your table.", 'nany'),
              "group" => __( "Design", 'nany')
            ),

            /* Custom CSS */
            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

          )
    ) );
  }
}


?>