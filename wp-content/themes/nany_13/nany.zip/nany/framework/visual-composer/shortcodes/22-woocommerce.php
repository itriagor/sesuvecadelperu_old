<?php

/* ==========================================================
    Visual Composer - nany_products
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_products')) {
  function nany_products( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'nany_products_columns'  => '',
      'nany_products_style'  => '',
      'nany_products_limit'  => '8',
      'nany_products_order'  => '',
      'nany_products_order_by'  => '',
      'port_offset'  => '',
      'show_category'  => '',
      'enable_pagination'  => '',
      'extra_class'  => '',
    ), $atts));

    // Turn output buffer on
    ob_start();
    ?>

    <!-- Products -->
    <div class="col-lg-12 vc-products woocommerce woocommerce-page <?php echo $extra_class; ?>">
      <div class="<?php echo $nany_products_columns; ?>">
        <ul class="products">

      <?php
        global $post;
        // $paged = get_query_var('paged') ? get_query_var('paged') : 1;
        // $wpbp = new WP_Query(array('post_type' => 'post', 'posts_per_page' => $nany_products_limit, 'category_name' => $show_category, 'paged' => $paged, 'offset' => $port_offset, 'orderby' => $nany_products_order_by, 'order' => $nany_products_order));
        //
        // Pagination Issue Fixed
        global $paged;
        if( get_query_var( 'paged' ) )
          $my_page = get_query_var( 'paged' );
        else {
          if( get_query_var( 'page' ) )
            $my_page = get_query_var( 'page' );
          else
            $my_page = 1;
          set_query_var( 'paged', $my_page );
          $paged = $my_page;
        }

        // default loop here, if applicable, followed by wp_reset_query();
        if($show_category) {

          $show_category = explode(",", $show_category);
          $show_category = array_map('trim', $show_category);

          $args = array(
            'post_type'       => 'product',
            'post_status'       => 'publish',
            'ignore_sticky_posts' => 1,
            'orderby'         => esc_attr($nany_products_order_by),
            'order'         => esc_attr($nany_products_order),
            'posts_per_page'    => (int)$nany_products_limit,
            'paged'         => esc_attr($my_page),
            'offset' => (int)$port_offset,
            'tax_query'       => array(
              array(
                'taxonomy'    => 'product_cat',
                'terms'     => esc_attr($show_category),
                'field'     => 'slug',
                'operator'    => 'IN'
              )
            )
          );
        } else {
          $args = array(
            'post_type'       => 'product',
            'post_status'       => 'publish',
            'ignore_sticky_posts' => 1,
            'offset'          => (int)$port_offset,
            'orderby'         => esc_attr($nany_products_order_by),
            'order'         => esc_attr($nany_products_order),
            'posts_per_page'    => (int)$nany_products_limit,
            'paged'         => esc_attr($my_page),
          );
        }

        $wpbp = new WP_Query( $args );

      /* Normal nany_products */
      if ($wpbp->have_posts()) : while ($wpbp->have_posts()) : $wpbp->the_post();
        get_template_part( 'woocommerce/content', 'product' );
      endwhile;
      else :
        get_template_part( 'content', 'none' );
      endif;
      ?>

      <?php wp_reset_query(); ?>
        </ul>
      </div>
    </div>

    <!-- Paged navigation -->
    <?php if ($enable_pagination) { ?>
      <div class="post-navigation float-left">
        <?php
          if ( function_exists('wp_pagenavi')) {
              wp_pagenavi(array( 'query' => $wpbp ) );
              wp_reset_postdata();  // avoid errors further down the page
          }
        ?>
      </div>
    <?php }

    // Return outbut buffer
    return ob_get_clean();

  }
}
add_shortcode( 'nany_products', 'nany_products' );

/**
  Add to visual composer
**/
add_action( 'init', 'nany_products_vc_map' );
if ( ! function_exists( 'nany_products_vc_map' ) ) {
  function nany_products_vc_map() {
    vc_map( array(
        "name" =>"Products",
        "base" => "nany_products",
        "description" => "WooCommerce Products",
        "icon" => "vc-nany-products",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "dropdown",
                "heading" => __( "Column", 'nany' ),
                "param_name" => "nany_products_columns",
                "value" => array(
                            "Column 4"=>'product-col-4',
                            "Column 3"=>'product-col-3'
                          ),
                "description" => __( "Select products column.", 'nany')
            ),
            array(
              "type"=>'textfield',
              "heading"=>__('Limit', 'nany'),
              "param_name"=> "nany_products_limit",
              "value"=>"8",
              "admin_label"=>true,
              "description" => __( "Enter your productss limit per page.", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Order", 'nany' ),
                "param_name" => "nany_products_order",
                "value" => array(
                            "Ascending"=>'ASC',
                            "Descending"=>'DESC'
                          ),
                "description" => __( "Select products order.", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Order By", 'nany' ),
                "param_name" => "nany_products_order_by",
                "value" => array(
                            "none"=>'none',
                            "ID"=>'ID',
                            "Author"=>'author',
                            "Title"=>'title',
                            "Name"=>'name',
                            "Type"=>'type',
                            "Date"=>'date',
                            "Modified"=>'modified',
                            "Rand"=>'rand'
                          ),
                "description" => __( "Select products orderby.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Offset", 'nany' ),
                "param_name" => "port_offset",
                'value'=>'',
                "description" => __( "Enter a number to offset products.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Show only certain categories?", 'nany' ),
                "param_name" => "show_category",
                'value'=>'',
                "description" => __( "Enter category SLUGS (comma separated) you want to display.", 'nany')
            ),
            array(
              "type"=>'checkbox',
              "heading"=>__('Enable Pagination', 'nany'),
              "param_name"=> "enable_pagination",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you want pagination please check this.", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

          )
    ) );
  }
}


?>