<?php

/* ==========================================================
    Visual Composer - Separator
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_separator')) {
  function nany_separator( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'separator_style'  => '',
      'separator_width'  => '',
      'separator_height'  => '',
      'separator_position'   => '',
      'separator_color'  => '',
      'center_point'  => '',
      'center_point_color'   => '',
      'top_space'   => '',
      'bottom_space'   => '',
      'extra_class'  => ''
    ), $atts));

    if ( $separator_style ) {
      $separator_style = $separator_style;
    }
    if ( $separator_height && $separator_style === 'separator-1' ) {
      $separator_height = 'height:'. $separator_height .';';
    }
    if ( $center_point_color ) {
      $center_point_color = 'style="background:'. $center_point_color .';"';
    }
    if ( $center_point ) {
      $center_point = '<span class="center-point" '. $center_point_color .'></span>';
    }
    if ( $center_point && $separator_style === 'separator-1' ) {
      $center_point = '';
    }
    if ( $separator_width ) {
      $separator_width = 'width:'. $separator_width .';';
    }
    if ( $separator_color ) {
      $separator_color = 'background:'. $separator_color .';';
    }
    if ( $separator_style === 'separator-1' ) {
      $separator_color = '';
    }
    if ( $top_space ) {
      $top_space = 'margin-top:'. $top_space .';';
    }
    if ( $bottom_space ) {
      $bottom_space = 'margin-bottom:'. $bottom_space .';';
    }

    if ( $separator_position ) {
      $separator_position = 'float:'. $separator_position .';';
    }

    $output = '<div class="'. $separator_style .' '. $extra_class .'" style="'. $separator_width . $separator_height . $separator_color . $top_space . $bottom_space . $separator_position .'">'. $center_point .'</div>';

    return $output;

  }
}
add_shortcode( 'separator', 'nany_separator' );


/**
  Add to visual composer
**/
add_action( 'init', 'nany_separator_vc_map' );
if ( ! function_exists( 'nany_separator_vc_map' ) ) {
  function nany_separator_vc_map() {
    vc_map( array(
        "name" =>"Separator",
        "base" => "separator",
        "description" => "Separate your content",
        "icon" => "vc-separator",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "dropdown",
                "heading" => __( "Separator Style", 'nany' ),
                "param_name" => "separator_style",
                "value" => array(
                            "Style One"=>'separator',
                            "Style Two" =>'separator-1'
                          ),
                "admin_label" => true,
                "description" => __( "Separator Style", 'nany')
            ),

            array(
                "type" => "dropdown",
                "heading" => __( "Separator Width", 'nany' ),
                "param_name" => "separator_width",
                "value" => array(
                            "100%"=>'100%',
                            "90%" =>'90%',
                            "80%" =>'80%',
                            "70%" =>'70%',
                            "60%" =>'60%',
                            "50%" =>'50%',
                            "40%" =>'40%',
                            "30%" =>'30%',
                            "20%" =>'20%',
                            "10%" =>'10%'
                          ),
                "description" => __( "Select separator width.", 'nany')
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Separator Height", 'nany' ),
                "param_name" => "separator_height",
                'value'=>'',
                "description" => __( "Separator height in px. Note: Upto 25px. (Eg : 20px).", 'nany'),
                'dependency'  => Array(
                  'element' => "separator_style",
                  'value'   => "separator-1"
                )
            ),

            array(
                "type" => "dropdown",
                "heading" => __( "Separator Position", 'nany' ),
                "param_name" => "separator_position",
                "value" => array(
                            "Center"=>'none',
                            "Left" =>'left',
                            "Right" =>'right'
                          ),
                "description" => __( "Separator Position", 'nany')
            ),

            array(
              "type"=>'colorpicker',
              "heading"=>__('Separator color', 'nany'),
              "param_name"=> "separator_color",
              "value"=>"#DCDCDC",
              "description" => __( "Select color for your separator.", 'nany'),
              'dependency'  => Array(
                'element' => "separator_style",
                'value'   => "separator"
              )
            ),

            array(
              "type"=>'checkbox',
              "heading"=>__('Need center point?', 'nany'),
              "param_name"=> "center_point",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need center point check this.", 'nany'),
              'dependency'  => Array(
                'element' => "separator_style",
                'value'   => "separator"
              )
            ),

            array(
              "type"=>'colorpicker',
              "heading"=>__('Center Point Color', 'nany'),
              "param_name"=> "center_point_color",
              "value"=>"#DA322C",
              "description" => __( "Select color for your center point.", 'nany'),
              'dependency'  => Array(
                'element' => "center_point",
                'value'   => "yes"
              )
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Top Space", 'nany' ),
                "param_name" => "top_space",
                'value'=>'',
                "description" => __( "Separator Top Space in px. (Eg : 20px)", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Bottom Space", 'nany' ),
                "param_name" => "bottom_space",
                'value'=>'',
                "description" => __( "Separator Bottom Space in px. (Eg : 20px)", 'nany')
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

          )
    ) );
  }
}


?>