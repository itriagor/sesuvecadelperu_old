<?php

/* ==========================================================
    Visual Composer - client
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_client')) {
  function nany_client( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'client_style'  => '',
      'client_logo'  => '',
      'client_logo_alt'  => '',
      'client_logo_link'  => '',
      'open_window'  => '',
      'bg_color'  => '',
      'black_white'  => '',
      'extra_class'  => '',

      /* Spacing */
      'outer_top_bottom_space'  => '',
      'outer_right_left_space'  => '',
      'inner_top_bottom_space'  => '',
      'inner_right_left_space'  => '',

      /* Extra */
      'href_before'  => '',
      'href_after'  => '',
    ), $atts));

    if ( $open_window ) {
      $open_window = 'target="_blank"';
    }
    if ( $bg_color ) {
      $bg_color = 'background-color:'. $bg_color .';';
    }
    if ( $black_white === 'yes' ) {
      $black_white = 'class="grayscale grayscale-fade"';
      wp_enqueue_script('grey-effect', SCRIPTS . '/jquery.gray.min.js', array('jquery'), '', true);
      wp_enqueue_style('gray', STYLES . '/gray.min.css', false, '', 'all');
    }

    /* Spacing */
    if ($outer_top_bottom_space) {
      $outer_top_bottom_space = 'margin-top:'. $outer_top_bottom_space .';margin-bottom:'. $outer_top_bottom_space .';';
    }
    if ($outer_right_left_space) {
      $outer_right_left_space = 'margin-right:'. $outer_right_left_space .';margin-left:'. $outer_right_left_space .';';
    }
    if ($inner_top_bottom_space) {
      $inner_top_bottom_space = 'padding-top:'. $inner_top_bottom_space .';padding-bottom:'. $inner_top_bottom_space .';';
    }
    if ($inner_right_left_space) {
      $inner_right_left_space = 'padding-right:'. $inner_right_left_space .';padding-left:'. $inner_right_left_space .';';
    }

    if ($client_logo_link) {
      $href_before = '<a '. $black_white .' href="'. esc_url($client_logo_link) .'" '. $open_window .' style="'. $bg_color . $inner_right_left_space . $inner_top_bottom_space . $outer_right_left_space . $outer_top_bottom_space .'">';
      $href_after = '</a>';
    }

    if ( $client_logo ) {
      $image_url = wp_get_attachment_url( $client_logo );
      $client_logo = '<img src="'. esc_attr($image_url) .'" alt="'. esc_attr($client_logo_alt) .'" />';
    } else {
      $client_logo = '<img src="'. IMAGES .'/dummy/170x90.png" alt="Logo not Uploaded" '. $black_white .' />';
    }

    if ($client_style === 'style-2') {
      $output = '<div class="clientlist client-style-2 '. $extra_class .'">'. $href_before . $client_logo . $href_after .'</div>';
    } else {
      $output = '<div class="clientlist '. $extra_class .'">'. $href_before . $client_logo . $href_after .'</div>';
    }

    return $output;
  }
}
add_shortcode( 'client', 'nany_client' );

/**
  Add to visual composer
**/
add_action( 'init', 'nany_client_vc_map' );
if ( ! function_exists( 'nany_client_vc_map' ) ) {
  function nany_client_vc_map() {
    vc_map( array(
        "name" =>"Client",
        "base" => "client",
        "description" => "Client Logo",
        "icon" => "vc-client_slider",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "dropdown",
                "heading" => __( "Client Style", 'nany' ),
                "param_name" => "client_style",
                "value" => array(
                            "Style One"=>'style-1',
                            "Style Two"=>'style-2'
                          ),
                "description" => __( "Select Client Style", 'nany')
            ),
            array(
                "type" => "attach_image",
                "heading" => __( "Upload logo", 'nany' ),
                "param_name" => "client_logo",
                'value'=>'',
                "description" => __( "Upload your client logo", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Alt text", 'nany' ),
                "param_name" => "client_logo_alt",
                'value'=>'',
                "admin_label" => true,
                "description" => __( "Enter client logo description", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Logo Link", 'nany' ),
                "param_name" => "client_logo_link",
                'value'=>'#',
                "description" => __( "Enter client logo link", 'nany')
            ),
            array(
              "type"=>'checkbox',
              "heading"=>__('Link open in new window?', 'nany'),
              "param_name"=> "open_window",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need to open link in new window, check this.", 'nany'),
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Background color', 'nany'),
              "param_name"=> "bg_color",
              "value"=> "",
              "description" => __( "Select background color for client logo.", 'nany'),
            ),
            array(
              "type"=>'checkbox',
              "heading"=>__('Black & White Effect', 'nany'),
              "param_name"=> "black_white",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need black & white effect, check this.", 'nany'),
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

            /* Spacing */
            array(
                "type" => "textfield",
                "heading" => __( "Outer Top & Bottom Space", 'nany' ),
                "param_name" => "outer_top_bottom_space",
                'value'=>'',
                "description" => __( "Service Top & Bottom Space", 'nany'),
                "group" => __( "Spacing", 'nany'),
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Outer Rigth & Left Space", 'nany' ),
                "param_name" => "outer_right_left_space",
                'value'=>'',
                "description" => __( "Service Right & Left Space", 'nany'),
                "group" => __( "Spacing", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Inner Top & Bottom Space", 'nany' ),
                "param_name" => "inner_top_bottom_space",
                'value'=>'',
                "description" => __( "Service Top & Bottom Space", 'nany'),
                "group" => __( "Spacing", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Inner Rigth & Left Space", 'nany' ),
                "param_name" => "inner_right_left_space",
                'value'=>'',
                "description" => __( "Service Right & Left Space", 'nany'),
                "group" => __( "Spacing", 'nany')
            ),

          )
    ) );
  }
}


?>