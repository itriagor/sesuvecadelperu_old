<?php
/**
 * init.php
 *
 * Load the widget files.
 */

/* All Custom Widgets */
require_once( FRAMEWORK . '/widgets/widget-flickr.php' );
require_once( FRAMEWORK . '/widgets/widget-dribbble.php' );
require_once( FRAMEWORK . '/widgets/widget-recent-posts.php' );
require_once( FRAMEWORK . '/widgets/widget-small-ads.php' );
require_once( FRAMEWORK . '/widgets/widget-large-ads.php' );
require_once( FRAMEWORK . '/widgets/widget-get-touch.php' );

/* Twitter Scroll Plugin  */
require_once( FRAMEWORK . '/plugins/tweetscroll/widget-tweetscroll.php' );

/* Breadcrumb */
require_once( FRAMEWORK . '/plugins/breadcrumb-trail.php' );

/* Zilla Likes */
require_once( FRAMEWORK . '/plugins/zilla-likes/zilla-likes.php' );

/* Install Plugins */
require_once( FRAMEWORK . '/plugins/notify/activation.php' );

/* Image Resizer Script */
require_once( FRAMEWORK . '/plugins/aq_resizer.php' );

/* Page Navigation Plugin */
include_once(FRAMEWORK . '/plugins/wp-pagenavi/wp-pagenavi.php');

/* All Styles and Scripts Register Here. */
require_once( FRAMEWORK . '/add-scripts.php' );

/* Custom Simple Shortcodes */
require_once( FRAMEWORK . '/custom-shortcodes.php' );

/* Nav Walker Menu */
require_once( FRAMEWORK . '/wp_bootstrap_navwalker.php' );

/* Visual Composer Shortcodes Embed */
require_once( FRAMEWORK . '/visual-composer/shortcodes/init.php' );

/* Custom Post Types */
require_once( FRAMEWORK . '/post-types/testimonials.php' );
require_once( FRAMEWORK . '/post-types/portfolio.php' );

?>