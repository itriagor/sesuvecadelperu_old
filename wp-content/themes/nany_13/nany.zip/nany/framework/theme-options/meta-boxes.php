<?php
/**
 * Initialize the meta boxes.
 */
add_action( 'admin_init', 'nany_custom_meta_boxes' );

function nany_custom_meta_boxes() {

/* ==============================================
    Header Metabox
=============================================== */
$page_custom_menu = array(
    'id'          => 'page_custom_menu',
    'title'       => __('Select Menu for This Page', 'nany'),
    'desc'        => '',
    'pages'       => array( 'page' ),
    'context'     => 'side',
    'priority'    => '',
    'fields'      => array(
      array(
        'id'          => 'choose_menu',
        'label'       => __('Choose Menu', 'nany'),
        'desc'        => '',
        'std'         => 'main-menu',
        'type'        => 'select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'main-menu',
            'label'       => __('Main Menu', 'nany'),
            'src'         => ''
          ),
          array(
            'value'       => 'one-page',
            'label'       => __('One Page Menu', 'nany'),
            'src'         => ''
          ),

        ),
      ),
  )
);

ot_register_meta_box( $page_custom_menu );

/* ==============================================
    Header Types
=============================================== */
$nany_header_types = array(
    'id'          => 'nany_header_types',
    'title'       => __('Header Types', 'nany'),
    'desc'        => '',
    'pages'       => array( 'page' ),
    'context'     => 'side',
    'priority'    => 'high',
    'fields'      => array(

      array(
        'id'          => 'page_header_type',
        'label'       => __( 'Header Type', 'nany' ),
        'desc'        => '',
        'std'         => 'header_title',
        'type'        => 'select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'header_title',
            'label'       => __( 'Title', 'nany' ),
            'src'         => ''
          ),
          array(
            'value'       => 'header_slider',
            'label'       => __( 'Slider', 'nany' ),
            'src'         => ''
          ),
          array(
            'value'       => 'no_title',
            'label'       => __( 'No Title', 'nany' ),
            'src'         => ''
          )
        ),
      ),

      array(
        'id'          => 'header_title_notification',
        'label'       => __( 'Text', 'nany' ),
        'desc'        => __( 'Check <strong><a href="#custom_title_for_all">Page Options</a>.</strong> Under Main<br /> Content Area.', 'nany' ),
        'std'         => '',
        'type'        => 'textblock',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),

    )
);
ot_register_meta_box( $nany_header_types );

/******************************
    Custom Sidebar
 ******************************/
$sidebar_select_meta_box = array(
    'id'          => 'sidebar_select_meta_box',
    'title'       => __( 'Select Sidebar', 'nany' ),
    'desc'        => '',
    'pages'       => array( 'page', 'product' ),
    'context'     => 'side',
    'priority'    => 'low',
    'fields'      => array(
      array(
        'id'          => 'sidebar_select',
        'label'       => __( 'Select Sidebar for this page', 'nany' ),
        'desc'        => '',
        'std'         => '',
        'type'        => 'sidebar-select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'sidebar_opt_info',
        'label'       => __( 'Sidebar', 'nany' ),
        'desc'        => __( 'Only apply for Page Templates: <strong>Default Template, Left Sidebar</strong>', 'nany' ),
        'std'         => '',
        'type'        => 'textblock',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      )
    )
  );

ot_register_meta_box( $sidebar_select_meta_box );

/* Custom Title of that page */
$custom_title_for_all = array(
    'id'          => 'custom_title_for_all',
    'title'       => __('Page Options', 'nany'),
    'desc'        => '',
    'pages'       => array( 'post', 'page', 'portfolio' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(

      array(
        'id'          => 'page_custom_title',
        'label'       => __( 'Custom Title', 'nany' ),
        'desc'        => __( 'Use this box for custom headings, if you want.', 'nany' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'page_rev_slider',
        'label'       => __( 'Revolution Slider', 'nany' ),
        'desc'        => __( 'Enter your slider slug here. Ex : <strong>nany</strong>', 'nany' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'operator'    => 'or',
        'condition'   => 'page_header_type:is(header_slider)',
      ),
      array(
        'id'          => 'enble_scroll_on_menu',
        'label'       => __( 'Enable Menu on Scroll', 'nany' ),
        'desc'        => __( 'If you need menus on when you scroll, check this.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'operator'    => 'or',
        'condition'   => '',
        'choices'     => array(
          array(
            'value'       => 'enble_scroll_on_menu',
            'label'       => __( 'Enable Please.', 'nany' ),
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'hide_footer_widgets',
        'label'       => __( 'Hide Footer', 'nany' ),
        'desc'        => __( 'If you need to hide footer, check this.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'operator'    => 'or',
        'condition'   => '',
        'choices'     => array(
          array(
            'value'       => 'hide_footer_widgets',
            'label'       => __( 'Disable Footer.', 'nany' ),
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'page_background_type',
        'label'       => __( 'Background Type', 'nany' ),
        'desc'        => '',
        'std'         => 'bg_none',
        'type'        => 'select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'operator'    => 'or',
        'condition'   => 'page_header_type:is(header_title),page_header_type:is(no_title)',
        'choices'     => array(
          array(
            'value'       => 'bg_none',
            'label'       => __( 'None', 'nany' ),
            'src'         => ''
          ),
          array(
            'value'       => 'bg_image',
            'label'       => __( 'Image', 'nany' ),
            'src'         => ''
          ),
          array(
            'value'       => 'bg_color',
            'label'       => __( 'Solid Color', 'nany' ),
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'title_bg_image',
        'label'       => __( 'Title BG Image', 'nany' ),
        'desc'        => __( 'Upload title background image if you want.', 'nany' ),
        'std'         => '',
        'type'        => 'upload',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'operator'    => 'or',
        'condition'   => 'page_background_type:is(bg_image)',
      ),
      array(
        'id'          => 'title_bg_color',
        'label'       => __( 'Title BG Color', 'nany' ),
        'desc'        => __( 'Pick solid color for title area, if you want.', 'nany' ),
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'operator'    => 'or',
        'condition'   => 'page_background_type:is(bg_color)',
      ),

    )
  );
ot_register_meta_box( $custom_title_for_all );

/* ==============================================
    Testimonial Metabox
=============================================== */
$testimonial_client_profession = array(
    'id'          => 'testimonial_client_profession',
    'title'       => __('Testimonial Content', 'nany'),
    'desc'        => '',
    'pages'       => array( 'testimonial' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(
      array(
        'id'          => 'testimonial_client_profession',
        'label'       => __('Client Profession', 'nany'),
        'desc'        => __('Eg : CEO, My Company', 'nany'),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
      ),
      array(
        'id'          => 'testimonial_client_image',
        'label'       => __('Client Image', 'nany'),
        'desc'        => __('Upload your client image here. Recommended Size : 210x210', 'nany'),
        'std'         => '',
        'type'        => 'upload',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
      )
    )
);

ot_register_meta_box( $testimonial_client_profession );

/* ==============================================
    Portfolio Metabox
=============================================== */
$portfolio_nany_theme = array(
    'id'          => 'portfolio_nany_theme',
    'title'       => __('Portfolio options', 'nany'),
    'desc'        => '',
    'pages'       => array( 'portfolio' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(

      array(
        'id'          => 'portfolio_style',
        'label'       => 'Layout Style',
        'desc'        => '',
        'std'         => 'style-1',
        'type'        => 'radio-image',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'condition'   => ''
      ),
       array(
        'id'          => 'portfolio_date',
        'label'       => __( 'Date', 'nany' ),
        'desc'        => __( 'Pick the date of this project done.', 'nany' ),
        'std'         => '',
        'type'        => 'date-picker',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'operator'    => 'or',
        'condition'   => 'portfolio_style:is(style-2),portfolio_style:is(style-3)',
      ),
      array(
        'id'          => 'portfolio_skills',
        'label'       => __( 'Skills', 'nany' ),
        'desc'        => __( 'Skills that you have used in this project.', 'nany' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'operator'    => 'or',
        'condition'   => 'portfolio_style:is(style-2),portfolio_style:is(style-3)'
      ),
      array(
        'id'          => 'disable_category_list',
        'label'       => __( 'Disable Category List?', 'nany' ),
        'desc'        => __( 'If you need to disable category list in this single item, check this.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'operator'    => 'or',
        'condition'   => 'portfolio_style:is(style-2),portfolio_style:is(style-3)',
        'choices'     => array(
          array(
            'value'       => 'disable_category_list',
            'label'       => __( 'Disable Please.', 'nany' ),
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'portfolio_images_videos',
        'label'       => __( 'Add Portfolio Items.', 'nany' ),
        'desc'        => __( 'Add Images or Videos iframe. Click "Add New"', 'nany' ),
        'std'         => '',
        'type'        => 'list-item',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'operator'    => 'or',
        'condition'   => 'portfolio_style:is(style-2),portfolio_style:is(style-3)',
        'settings'    => array(
            array(
                'id'          => 'image_or_video',
                'label'       => __( 'If you need image click on, if you need video click off.', 'nany' ),
                'type'        => 'on-off',
                'std'         => 'on',
            ),
            array(
                'id'          => 'image',
                'label'       => __( 'Image', 'nany' ),
                'type'        => 'upload',
                'condition'   => 'image_or_video:is(on)',
            ),
            array(
                'id'          => 'video',
                'label'       => __( 'Video', 'nany' ),
                'type'        => 'textarea',
                'rows'        => '6',
                'condition'   => 'image_or_video:is(off)',
            )
        ),
      )

    )
  );

ot_register_meta_box( $portfolio_nany_theme );




/* ==============================================
    Portfolio Page Metabox
=============================================== */
$portfolio_page_metabox = array(
    'id'          => 'portfolio_page_metabox',
    'title'       => __('Portfolio options', 'nany'),
    'desc'        => '',
    'pages'       => array( 'page' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(

      array(
        'id'          => 'portfolio_columns',
        'label'       => __('Select Portfolio Columns', 'nany'),
        'desc'        => __('Portfolio columns for archive & taxonomy pages.', 'nany'),
        'std'         => '',
        'type'        => 'select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'portfolio-4-column',
            'label'       => __('Portfolio Column 4', 'nany'),
            'src'         => ''
          ),
          array(
            'value'       => 'portfolio-3-column',
            'label'       => __('Portfolio Column 3', 'nany'),
            'src'         => ''
          ),
          array(
            'value'       => 'portfolio-2-column',
            'label'       => __('Portfolio Column 2', 'nany'),
            'src'         => ''
          )
        ),
      ),

      array(
        'id'          => 'portfolio_item_limit',
        'label'       => __('How many items show per page?', 'nany'),
        'desc'        => __('Leave it blank if you want to display all.', 'nany'),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),

      array(
        'id'          => 'portfolio_cat_filter',
        'label'       => __('Show category filter?', 'nany'),
        'desc'        => '',
        'std'         => 'show',
        'type'        => 'radio',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'show',
            'label'       => 'Show',
            'src'         => ''
          ),
          array(
            'value'       => 'hide',
            'label'       => 'Hide',
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'portfolio_item_order',
        'label'       => __('Order', 'nany'),
        'desc'        => __('Select Order which you want.', 'nany'),
        'std'         => '',
        'type'        => 'select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'ASC',
            'label'       => 'ASC',
            'src'         => ''
          ),
          array(
            'value'       => 'DESC',
            'label'       => 'DESC',
            'src'         => ''
          )
        )
      ),
      array(
        'id'          => 'portfolio_item_orderby',
        'label'       => __('Orderby', 'nany'),
        'desc'        => __('Select Orderby which you want.', 'nany'),
        'std'         => '',
        'type'        => 'select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'ID',
            'label'       => 'ID',
            'src'         => ''
          ),
          array(
            'value'       => 'author',
            'label'       => 'Author',
            'src'         => ''
          ),
          array(
            'value'       => 'title',
            'label'       => 'Title',
            'src'         => ''
          ),
          array(
            'value'       => 'date',
            'label'       => 'Date',
            'src'         => ''
          ),
          array(
            'value'       => 'modified',
            'label'       => 'Modified',
            'src'         => ''
          ),
          array(
            'value'       => 'parent',
            'label'       => 'Parent',
            'src'         => ''
          ),
          array(
            'value'       => 'rand',
            'label'       => 'Random',
            'src'         => ''
          ),
        )
      ),
      array(
        'id'          => 'portfolio_show_category',
        'label'       => __('Show only certain categories?', 'nany'),
        'desc'        => __('Enter category <strong>SLUGS</strong> (comma separated) you want to display.<br/>If you want to display only one category, disable category filter!<br/><span style="color:green;">LEAVE EMPTY TO DISPLAY ALL CATEGORIES!</span>', 'nany'),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'portfolio_item_offset',
        'label'       => __('Offset', 'nany'),
        'desc'        => __('Number of items need to offset.', 'nany'),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
      )
    )
  );

ot_register_meta_box( $portfolio_page_metabox );


/* ==============================================
    Blog Page Metabox
=============================================== */
$blog_page_metabox = array(
    'id'          => 'blog_page_metabox',
    'title'       => __('Blog options', 'nany'),
    'desc'        => '',
    'pages'       => array( 'page' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(


      array(
        'id'          => 'blog_notification_mb',
        'label'       => __( 'Blog Page', 'nany' ),
        'desc'        => __( 'More & Global Options is under <strong>Appearance > Theme Options > Blog</strong>', 'nany' ),
        'std'         => '',
        'type'        => 'textblock',
        'section'     => 'nany_blog',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'blog_item_limit',
        'label'       => __('How many items show per page?', 'nany'),
        'desc'        => __('Leave it blank if you want to display all.', 'nany'),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'enable_fullwidth',
        'label'       => __( 'Full width blog', 'nany' ),
        'desc'        => __( 'Disables sidebar for the blog page.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => 'nany_blog',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array(
          array(
            'value'       => 'enable_fullwidth',
            'label'       => __( 'Enable full width for blog', 'nany' ),
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'sidebar_position',
        'label'       => __('Sidebar Position', 'nany'),
        'desc'        => __('Select sidebar position for your blog page.', 'nany'),
        'std'         => '',
        'type'        => 'select',
        'section'     => 'nany_blog',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'right',
            'label'       => __('Right', 'nany'),
            'src'         => ''
          ),
          array(
            'value'       => 'left',
            'label'       => __('Left', 'nany'),
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'blog_item_order',
        'label'       => __('Order', 'nany'),
        'desc'        => __('Select Order which you want.', 'nany'),
        'std'         => '',
        'type'        => 'select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'ASC',
            'label'       => 'ASC',
            'src'         => ''
          ),
          array(
            'value'       => 'DESC',
            'label'       => 'DESC',
            'src'         => ''
          )
        )
      ),
      array(
        'id'          => 'blog_item_orderby',
        'label'       => __('Orderby', 'nany'),
        'desc'        => __('Select Orderby which you want.', 'nany'),
        'std'         => '',
        'type'        => 'select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'ID',
            'label'       => 'ID',
            'src'         => ''
          ),
          array(
            'value'       => 'author',
            'label'       => 'Author',
            'src'         => ''
          ),
          array(
            'value'       => 'title',
            'label'       => 'Title',
            'src'         => ''
          ),
          array(
            'value'       => 'date',
            'label'       => 'Date',
            'src'         => ''
          ),
          array(
            'value'       => 'modified',
            'label'       => 'Modified',
            'src'         => ''
          ),
          array(
            'value'       => 'parent',
            'label'       => 'Parent',
            'src'         => ''
          ),
          array(
            'value'       => 'rand',
            'label'       => 'Random',
            'src'         => ''
          ),
        )
      ),
      array(
        'id'          => 'blog_show_category',
        'label'       => __('Show only certain categories?', 'nany'),
        'desc'        => __('Enter category <strong>SLUGS</strong> (comma separated) you want to display.<br/>If you want to display only one category, disable category filter!<br/><span style="color:green;">LEAVE EMPTY TO DISPLAY ALL CATEGORIES!</span>', 'nany'),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'blog_item_offset',
        'label'       => __('Offset', 'nany'),
        'desc'        => __('Number of items need to offset.', 'nany'),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
      )
    )
  );

ot_register_meta_box( $blog_page_metabox );


/* ==============================================
    Post Formats
=============================================== */

/* Status */
$post_format_status = array(
    'id'          => 'post_format_status',
    'title'       => __('Status Format', 'nany'),
    'desc'        => '',
    'pages'       => array( 'post' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(

      array(
        'id'          => 'status_content',
        'label'       => __( 'Status Content', 'nany' ),
        'desc'        => __( 'This content area mostly used for embed codes from third party social media.', 'nany' ),
        'std'         => '',
        'type'        => 'textarea',
        'section'     => '',
        'rows'        => '8',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),

    )
  );

ot_register_meta_box( $post_format_status );

/* Link */
$post_format_link = array(
    'id'          => 'post_format_link',
    'title'       => __('Link Format', 'nany'),
    'desc'        => '',
    'pages'       => array( 'post' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(

      array(
        'id'          => 'link_content',
        'label'       => __( 'link Content', 'nany' ),
        'desc'        => __( 'Just paste link here.', 'nany' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),

    )
  );

ot_register_meta_box( $post_format_link );

/* Audio */
$post_format_audio = array(
    'id'          => 'post_format_audio',
    'title'       => __('Audio Format', 'nany'),
    'desc'        => '',
    'pages'       => array( 'post' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(

      array(
        'id'          => 'audio_content',
        'label'       => __( 'Audio Content', 'nany' ),
        'desc'        => __( 'Just paste audio embed code here.', 'nany' ),
        'std'         => '',
        'type'        => 'textarea',
        'section'     => '',
        'rows'        => '8',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),

    )
  );

ot_register_meta_box( $post_format_audio );

/* Video */
$post_format_video = array(
    'id'          => 'post_format_video',
    'title'       => __('Video Format', 'nany'),
    'desc'        => '',
    'pages'       => array( 'post' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(

      array(
        'id'          => 'video_content',
        'label'       => __( 'Video Content', 'nany' ),
        'desc'        => __( 'Just paste video embed code here.', 'nany' ),
        'std'         => '',
        'type'        => 'textarea',
        'section'     => '',
        'rows'        => '8',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),

    )
  );

ot_register_meta_box( $post_format_video );

/* Quote */
$post_format_quote = array(
    'id'          => 'post_format_quote',
    'title'       => __('Quote Format', 'nany'),
    'desc'        => '',
    'pages'       => array( 'post' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(

      array(
        'id'          => 'quote_content',
        'label'       => __( 'Quote Content', 'nany' ),
        'desc'        => __( 'Just paste quote embed code here.', 'nany' ),
        'std'         => '',
        'type'        => 'textarea',
        'section'     => '',
        'rows'        => '8',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),

    )
  );

ot_register_meta_box( $post_format_quote );

/* Gallery */
$post_format_gallery = array(
    'id'          => 'post_format_gallery',
    'title'       => __('Gallery Format', 'nany'),
    'desc'        => '',
    'pages'       => array( 'post' ),
    'context'     => 'normal',
    'priority'    => 'high',
    'fields'      => array(

      array(
        'id'          => 'gallery_content',
        'label'       => __( 'Gallery Content', 'nany' ),
        'desc'        => __( 'Just paste gallery embed code here.', 'nany' ),
        'std'         => '',
        'type'        => 'list-item',
        'section'     => '',
        'rows'        => '8',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'settings'    => array(
            array(
                'id'          => 'image_or_video',
                'label'       => __( 'If you need image click on, if you need video click off.', 'nany' ),
                'type'        => 'on-off',
                'std'         => 'on',
            ),
            array(
                'id'          => 'image',
                'label'       => __( 'Image', 'nany' ),
                'type'        => 'upload',
                'condition'   => 'image_or_video:is(on)',
            ),
            array(
                'id'          => 'video',
                'label'       => __( 'Video', 'nany' ),
                'type'        => 'textarea',
                'rows'        => '6',
                'condition'   => 'image_or_video:is(off)',
            )
        ),
      ),

    )
  );

ot_register_meta_box( $post_format_gallery );

/* ==============================================
    Under Construction Page
=============================================== */
$under_construction_metabox = array(
    'id'          => 'under_construction_metabox',
    'title'       => 'Under Construction',
    'desc'        => '',
    'pages'       => array( 'page' ),
    'context'     => 'normal',
    'priority'    => 'default',
    'fields'      => array(
      array(
        'id'          => 'uc_bg_image',
        'label'       => __( 'Background image', 'nany' ),
        'desc'        => __( 'Upload under construction full background image.', 'nany' ),
        'std'         => '',
        'type'        => 'upload',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'uc_heading',
        'label'       => __( 'Heading', 'nany' ),
        'desc'        => __( 'Enter heading text for under construction.', 'nany' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'uc_subheading',
        'label'       => __( 'Sub Heading', 'nany' ),
        'desc'        => __( 'Enter sub heading text for under construction.', 'nany' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'uc_date_pick',
        'label'       => __( 'Counder Date Estimate', 'nany' ),
        'desc'        => __( 'Pick your estimate time for your under construction schedule.<br /> <strong>NOTE: Format should be like : 2014-11-30(Year-Month-Day)</strong>', 'nany' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'uc_color',
        'label'       => __( 'All Content Color', 'nany' ),
        'desc'        => __( 'Pick color for this page content.', 'nany' ),
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
  )
  );

ot_register_meta_box( $under_construction_metabox );

/* ==============================================
    Shop Page
=============================================== */
$woo_opt_meta_box = array(
    'id'          => 'woo_opt_meta_box',
    'title'       => __( 'WooCommerce Options', 'nany' ),
    'desc'        => '',
    'pages'       => array( 'page' ),
    'context'     => 'normal',
    'priority'    => 'default',
    'fields'      => array(

  array(
        'id'          => 'woo_items_page',
        'label'       => __( 'How many items show per page?', 'nany' ),
        'desc'        => __( 'Enter item numbers to show how much items for per page.', 'nany' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
  array(
        'id'          => 'woo_category',
        'label'       => __( 'Category', 'nany' ),
        'desc'        => __( 'Enter category name', 'nany' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
    array(
        'id'          => 'woo_product_order',
        'label'       => __( 'Order', 'nany' ),
        'desc'        => __( 'Select Order which you want.', 'nany' ),
        'std'         => '',
        'type'        => 'select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
    'choices'     => array(
          array(
            'value'       => 'ASC',
            'label'       => __( 'ASC', 'nany' ),
            'src'         => ''
          ),
          array(
            'value'       => 'DESC',
            'label'       => __( 'DESC', 'nany' ),
            'src'         => ''
          )
        )
      ),
    array(
        'id'          => 'woo_port_orderby',
        'label'       => __( 'Orderby', 'nany' ),
        'desc'        => __( 'Select Orderby which you want.', 'nany' ),
        'std'         => '',
        'type'        => 'select',
        'section'     => '',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
    'choices'     => array(
          array(
            'value'       => 'ID',
            'label'       => __( 'ID', 'nany' ),
            'src'         => ''
          ),
          array(
            'value'       => 'author',
            'label'       => __( 'Author', 'nany' ),
            'src'         => ''
          ),
      array(
            'value'       => 'title',
            'label'       => __( 'Title', 'nany' ),
            'src'         => ''
          ),
      array(
            'value'       => 'date',
            'label'       => __( 'Date', 'nany' ),
            'src'         => ''
          ),
      array(
            'value'       => 'modified',
            'label'       => __( 'Modified', 'nany' ),
            'src'         => ''
          ),
      array(
            'value'       => 'parent',
            'label'       => __( 'Parent', 'nany' ),
            'src'         => ''
          ),
      array(
            'value'       => 'rand',
            'label'       => __( 'Random', 'nany' ),
            'src'         => ''
          ),
        )
      ),
    )
  );

ot_register_meta_box( $woo_opt_meta_box );


}