/* ==============================================
    Shop Page Template Metabox
=============================================== */
(function ($) {

    $(document).ready(function ($) {
        /*---------------------------------------------------------------*/
        /* =  Toggle Meta boxes based on page template
        /*---------------------------------------------------------------*/
        function toggle_metaboxes() {

            var choice = $("option[value='template-shop.php']:selected").val() || $("option[value='template-shop-left.php']:selected").val() || $("option[value='template-shop-right.php']:selected").val();

            $('#woo_opt_meta_box').hide();

            if (choice == 'template-shop.php' || choice == 'template-shop-left.php' || choice == 'template-shop-right.php') {
                $('').fadeOut('slow');
                $('#woo_opt_meta_box').slideDown('slow');
            }

        }

        toggle_metaboxes(); // Execute on document ready

        $('#pageparentdiv select[id="page_template"]').click(toggle_metaboxes);
    });

})(jQuery);


/* ==============================================
    Portfolio Page Template Metabox
=============================================== */
(function ($) {

    $(document).ready(function ($) {
        /*---------------------------------------------------------------*/
        /* =  Toggle Meta boxes based on page template
        /*---------------------------------------------------------------*/
        function toggle_metaboxes() {

            var choice = $("option[value='page-portfolio.php']:selected").val();

            $('#portfolio_page_metabox').hide();

            if (choice == 'page-portfolio.php') {
                $('').fadeOut('slow');
                $('#portfolio_page_metabox').slideDown('slow');
            }

        }

        toggle_metaboxes(); // Execute on document ready

        $('#pageparentdiv select[id="page_template"]').click(toggle_metaboxes);
    });

})(jQuery);

/* ==============================================
    Under Construction Page Template Metabox
=============================================== */
(function ($) {

    $(document).ready(function ($) {
        /*---------------------------------------------------------------*/
        /* =  Toggle Meta boxes based on page template
        /*---------------------------------------------------------------*/
        function toggle_metaboxes() {

            var choice = $("option[value='template-underconstruction.php']:selected").val();

            $('#under_construction_metabox').hide();

            if (choice == 'template-underconstruction.php') {
                $('').fadeOut('slow');
                $('#under_construction_metabox').slideDown('slow');
            }

        }

        toggle_metaboxes(); // Execute on document ready

        $('#pageparentdiv select[id="page_template"]').click(toggle_metaboxes);
    });

})(jQuery);

/* ==============================================
    Blog Page Template Metabox
=============================================== */
(function ($) {

    $(document).ready(function ($) {
        /*---------------------------------------------------------------*/
        /* =  Toggle Meta boxes based on page template
        /*---------------------------------------------------------------*/
        function toggle_metaboxes() {

            var choice = $("option[value='page-blog.php']:selected").val();

            $('#blog_page_metabox').hide();

            if (choice == 'page-blog.php') {
                $('').fadeOut('slow');
                $('#blog_page_metabox').slideDown('slow');
            }

        }

        toggle_metaboxes(); // Execute on document ready

        $('#pageparentdiv select[id="page_template"]').click(toggle_metaboxes);
    });

})(jQuery);




(function ($) {

    $(document).ready(function ($) {
        /*---------------------------------------------------------------*/
        /* =  Toggle Meta boxes based on post formats
        /*---------------------------------------------------------------*/
        function toggle_metaboxes() {

            var format = $("input[name='post_format']:checked").val();

            $('#post_format_status, #post_format_link, #post_format_audio, #post_format_video, #post_format_quote, #post_format_gallery').hide();

            if (format == 'audio') {
                $('').slideUp('fast');
                $('#post_format_audio').slideDown('slow');
            }
            if (format == 'video') {
                $('').slideUp('fast');
                $('#post_format_video').slideDown('slow');
            }
            if (format == 'gallery') {
                $('').slideUp('fast');
                $('#post_format_gallery').slideDown('slow');
            }
            if (format == 'link') {
                $('').slideUp('fast');
                $('#post_format_link').slideDown('slow');
            }
            if (format == 'quote') {
                $('').slideUp('fast');
                $('#post_format_quote').slideDown('slow');
            }
            if (format == 'status') {
                $('').slideUp('fast');
                $('#post_format_status').slideDown('slow');
            }
        }

        toggle_metaboxes(); // Execute on document ready

        $('#post-formats-select input[type="radio"]').click(toggle_metaboxes);
    });

})(jQuery);