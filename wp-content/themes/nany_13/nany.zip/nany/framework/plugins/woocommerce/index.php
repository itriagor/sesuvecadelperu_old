<?php
/*
*	---------------------------------------------------------------------
*	Woocommerce functions
*	---------------------------------------------------------------------
*/

if ( class_exists( 'Woocommerce' ) ) {

	// Add Support
	add_theme_support( 'woocommerce' );

	// Disable WooCommerce styles
	if ( version_compare( WOOCOMMERCE_VERSION, "2.1" ) >= 0 ) {
		add_filter( 'woocommerce_enqueue_styles', '__return_false' );
	} else {
		define( 'WOOCOMMERCE_USE_CSS', false );
	}

	// Add Single onsale badge
	add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_show_product_loop_sale_flash', 10 );
	add_action( 'woocommerce_before_single_product_summary', 'woocommerce_show_product_sale_flash', 10);

	// Define Wrapper
	remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
	remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);

	// Theme Wrapper
	add_action('woocommerce_before_main_content', 'my_theme_wrapper_start', 10);
	add_action('woocommerce_after_main_content', 'my_theme_wrapper_end', 10);

	/* WooCommerce Shop page layout Settings in Theme Options */
	function my_theme_wrapper_start() {
		$layout = ot_get_option('woo_layout');
		$custom_class = '';

		if ($layout === 'full_width') {
			$layout = 'col-lg-12 col-md-12';
			$custom_column = '4';
		} elseif ($layout === 'right_sidebar') {
			$layout = 'col-lg-8 col-md-8';
			$custom_column = '3';
		} elseif ($layout === 'left_sidebar') {
			$layout = 'col-lg-8 col-md-8';
			$custom_column = '3';
			$custom_class = 'woo-right-content';
		} else {
			$layout = 'col-lg-8 col-md-8';
			$custom_column = '3';
		}
		echo '<div class="shop-template '. $layout .' product-col-'. $custom_column .' '. $custom_class .'">';
	}

	function my_theme_wrapper_end() {
	  echo '</div>';
	}


	// Remove Breadcrumbs
	remove_action( 'woocommerce_before_main_content', 'woocommerce_breadcrumb', 20, 0);

	// Related Products
	function woocommerce_output_related_products() {

		$layout = ot_get_option('woo_layout');
		$custom_class = '';

		if ($layout === 'full_width') {
			$custom_column = '4';
		} elseif ($layout === 'right_sidebar') {
			$custom_column = '3';
		} elseif ($layout === 'left_sidebar') {
			$custom_column = '3';
		} else {
			$custom_column = '3';
		}

		$args = array(
			'posts_per_page' => $custom_column,
			'columns' => $custom_column,
			'orderby' => 'rand'
		);

		$related_products = ot_get_option('disable_related_products');

		if (!$related_products) {
			woocommerce_related_products( apply_filters( 'woocommerce_output_related_products_args', $args ) );
		}

	}

	// You may also like products
	function woocommerce_upsell_display() {
		$layout = ot_get_option('woo_layout');
		$custom_class = '';

		if ($layout === 'full_width') {
			$custom_column = '4';
		} elseif ($layout === 'right_sidebar') {
			$custom_column = '3';
		} elseif ($layout === 'left_sidebar') {
			$custom_column = '3';
		} else {
			$custom_column = '3';
		}
		woocommerce_get_template( 'single-product/up-sells.php', array(
			'posts_per_page' => $custom_column,
			'orderby' => 'rand',
			'columns' => $custom_column
		) );
	}

	// Exclude Category From WooCoomerce Products
	add_action( 'pre_get_posts', 'custom_pre_get_posts_query' );
	function custom_pre_get_posts_query( $q ) {

		$woo_exclude_category = ot_get_option('woo_exclude_category');
		$woo_exclude_category = explode(" ", $woo_exclude_category);
		$woo_exclude_category = array_map('trim', $woo_exclude_category);

		if ( ! $q->is_main_query() ) return;
		if ( ! $q->is_post_type_archive() ) return;
		if ( ! is_admin() && is_shop() ) {
			$q->set(
				'tax_query',
				array(
					array(
						'taxonomy' => 'product_cat',
						'field' => 'slug',
						'terms' => $woo_exclude_category, // Don't display products in the knives category on the shop page
						'operator' => 'NOT IN'
					)
				)
			);

		}
		remove_action( 'pre_get_posts', 'custom_pre_get_posts_query' );
	}

	// Remove WooCommerce prettyPhoto
	global $woocommerce;
	if($woocommerce) {

		function removeWooPrettyPhoto() {
			wp_dequeue_style( 'woocommerce_prettyPhoto_css' );
			wp_dequeue_script( 'prettyPhoto-init' );
			wp_dequeue_script( 'prettyPhoto' );
		}

	add_action( 'wp_enqueue_scripts', 'removeWooPrettyPhoto', 99 );

	}

	// Add image wrap
	add_action( 'woocommerce_before_shop_loop_item_title', 'woocommerce_product_thumbnail_wrap_open', 9, 2);

	if (!function_exists('woocommerce_product_thumbnail_wrap_open')) {
		function woocommerce_product_thumbnail_wrap_open() {
			echo '<div class="img-wrap">';
		}
	}

	// Add to Wishlist - Shortcode
	function woo_yith_wishlist() {
		if ( function_exists( 'yit_is_woocommerce_active' ) ) {
			echo do_shortcode('[yith_wcwl_add_to_wishlist]');
		}
		global $post;
		$large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
		$large_image = $large_image[0];
		echo '<a href="'. esc_url($large_image) .'" class="nany-product-details woo-popup-link">'. __('Details', 'nany') .'</a>';
	}
	add_action( 'woocommerce_after_shop_loop_item_title', 'woo_yith_wishlist', 9, 2);

	// Add the inner div in product loop
	add_action( 'woocommerce_before_shop_loop_item_title', 'artificer_product_inner_open', 14, 2);
	add_action( 'woocommerce_after_shop_loop_item_title', 'artificer_product_inner_close', 12, 2);

	function artificer_product_inner_open() {
		$title_nub = ot_get_option('title_nub');
		global $post;
		$large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
		$large_image = $large_image[0];
		echo '<div class="product-inner woo-hover"><a href="'. esc_url($large_image) .'" class="woo-nub woo-popup-link"><img src="'. esc_attr($title_nub) .'" alt=""></a>';
	}
	function artificer_product_inner_close() {
		echo '</div>';
	}

	// Change rating position
	remove_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 5 );
	add_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_rating', 11 );

	// Change add to cart position
	remove_action( 'woocommerce_after_shop_loop_item', 'woocommerce_template_loop_add_to_cart', 10 );
	add_action( 'woocommerce_after_shop_loop_item_title', 'woocommerce_template_loop_add_to_cart', 11 );

	// Sidebar based on woocommerce page layout
	if ( ! function_exists( 'woocommerce_get_sidebar' ) ) {
		function woocommerce_get_sidebar() {
			if(ot_get_option('woo_layout') === 'full_width'){
				// no sidebars
				get_sidebar('none');
			} else {
				// Display the sidebar if full width option is disabled on archives
				get_sidebar('shop');
			}

			echo '<div class="clear"></div>';
		}
	}

}

/**
* Hook in on activation
*/
// add_image_size( 'small_shop_catelog', 270, 270 ); // Hard crop left top
// $shop_catalog	= wc_get_image_size( 'small_shop_catelog' );
global $pagenow;
if ( is_admin() && isset( $_GET['activated'] ) && $pagenow == 'themes.php' ) add_action( 'init', 'yourtheme_woocommerce_image_dimensions', 1 );

	/**
	* Define image sizes
	*/
	function yourtheme_woocommerce_image_dimensions() {
		$catalog = array(
			'width' => '270',	// px
			'height'	=> '270',	// px
			'crop'	=> 1 // true
		);

	// Image sizes
	update_option( 'shop_catalog_image_size', $catalog ); // Product category thumbs

}
?>