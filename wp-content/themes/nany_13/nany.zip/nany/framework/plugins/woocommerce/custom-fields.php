<?php

// Display Fields
add_action( 'woocommerce_product_options_general_product_data', 'woo_add_custom_general_fields' );

// Save Fields
add_action( 'woocommerce_process_product_meta', 'woo_add_custom_general_fields_save' );

function woo_add_custom_general_fields() {

global $woocommerce, $post;
echo '<div class="options_group">';
	// Select
	woocommerce_wp_select(
			array(
			'id' => '_badge_select',
			'label' => __( 'Select Badge', 'woocommerce' ),
			'description' => __( 'Select badge to expose this product.', 'woocommerce' ),
			'options' => array(
				'select' => __( 'Select One', 'woocommerce' ),
				'new'   => __( 'New', 'woocommerce' ),
				'hot'   => __( 'Hot', 'woocommerce' ),
				'offer' => __( 'Offer', 'woocommerce' ),
				'sale'  => __( 'Sale', 'woocommerce' ),
				'from'  => __( 'From', 'woocommerce' ),
				'free'  => __( 'Free', 'woocommerce' )
			)
		)
	);

	// Text Field
	woocommerce_wp_text_input(
		array(
			'id' => '_badge_texts',
			'label' => __( 'Only for (Offer, From) badges', 'woocommerce' ),
			'placeholder' => __( 'Price value or % value', 'woocommerce' ),
			'desc_tip' => 'true',
			'description' => __( 'Enter the price or % value here.', 'woocommerce' )
		)
	);

echo '</div>';
}

function woo_add_custom_general_fields_save( $post_id ){
	// Text
	$woocommerce_select = $_POST['_badge_texts'];
	if( !empty( $woocommerce_select ) )
	update_post_meta( $post_id, '_badge_texts', esc_attr( $woocommerce_select ) );
	// Select
	$woocommerce_select = $_POST['_badge_select'];
	if( !empty( $woocommerce_select ) )
	update_post_meta( $post_id, '_badge_select', esc_attr( $woocommerce_select ) );
}

/**
 *  Add Custom Tabs - Process meta
 *
 * Processes the custom tab options when a post is saved
 */
function process_product_meta_custom_tab( $post_id ) {
    update_post_meta( $post_id, 'custom_tab_enabled', ( isset($_POST['custom_tab_enabled']) && $_POST['custom_tab_enabled'] ) ? 'yes' : 'no' );
    update_post_meta( $post_id, 'custom_tab_title', $_POST['custom_tab_title']);
    update_post_meta( $post_id, 'custom_tab_content', $_POST['custom_tab_content']);
	update_post_meta( $post_id, '_title_icon', $_POST['_title_icon']);
}
add_action('woocommerce_process_product_meta', 'process_product_meta_custom_tab', 10, 2);

/**
 * Render the custom product tab panel content for the callback 'custom_product_tabs_panel_content'
 */
function custom_product_tabs_panel_content( $key, $custom_tab_options ) {
    echo '<h2>' . $custom_tab_options['title'] . '</h2>';
    echo $custom_tab_options['content'];
}

function custom_tab_options_tab_spec() {
?>
    <li class="custom_tab3"><a href="#custom_tab_data3"><?php _e('Custom Tab', 'woocommerce'); ?></a></li>
<?php
}
add_action('woocommerce_product_write_panel_tabs', 'custom_tab_options_tab_spec');


/**
 * Custom Tab Options
 *
 * Provides the input fields and add/remove buttons for custom tabs on the single product page.
 */
function custom_tab_options_spec() {
    global $post;

    $custom_tab_options_spec = array(
            'titlec' => get_post_meta($post->ID, 'custom_tab_title_spec', true),
            'contentc' => get_post_meta($post->ID, 'custom_tab_content_spec', true),
			'title_icon' => get_post_meta($post->ID, '_title_icon_spec', true),
    );

?>
    <div id="custom_tab_data3" class="panel woocommerce_options_panel">

        <div class="options_group">
            <p class="form-field">
				<?php woocommerce_wp_checkbox( array( 'id' => 'custom_tab_enabled_spec', 'label' => __('Enable Custom Tab?', 'woocommerce'), 'description' => __('Enable this option to enable the custom tab on the frontend.', 'woocommerce') ) ); ?>
            </p>
        </div>

        <div class="options_group custom_tab_options">
            <p class="form-field">
                <label><?php _e('Custom Tab Title:', 'woocommerce'); ?></label>
                <input type="text" size="5" name="custom_tab_title_spec" value="<?php echo esc_attr(@$custom_tab_options_spec['titlec']); ?>" placeholder="<?php _e('Enter your custom tab title', 'woocommerce'); ?>" />
            </p>
        </div>

        <?php
			// Text Field
			woocommerce_wp_text_input(
				array(
					'id' => '_title_icon_spec',
					'label' => __( 'Title Icon', 'woocommerce' ),
					'placeholder' => 'fa-file',
					'description' => __( 'Enter icon class here. <a href="http://fortawesome.github.io/Font-Awesome/cheatsheet/" target="_blank">Get icon classes here</a>', 'woocommerce' )
				)
			);
		?>

        <p class="form-field">

			<?php _e('Custom Tab Content:', 'woocommerce'); ?>

        </p>

        <table class="form-table">
            <tr>
                <td>
					<?php
						$settings = array(
						'text_area_name'=> 'custom_tab_content_spec',
						'quicktags'     => true,
						'tinymce'               => true,
						'media_butons'  => false,
						'textarea_rows' => 98,
						'editor_class'  => 'contra',
						'editor_css'    => '<style>#wp-custom_tab_content_spec-editor-container .wp-editor-area{height:250px; width:100%;} #custom_tab_data3 .quicktags-toolbar input {width:auto;}</style>'
						);

						$id = 'custom_tab_content_spec';

						wp_editor($custom_tab_options_spec['contentc'],$id,$settings);

                    ?>
                </td>
            </tr>
        </table>
    </div>

<?php
}
add_action('woocommerce_product_write_panels', 'custom_tab_options_spec');

/*************/

/**
 * Process meta
 *
 * Processes the custom tab options when a post is saved
 */
function process_product_meta_custom_tab_spec( $post_id ) {
    update_post_meta( $post_id, 'custom_tab_enabled_spec', ( isset($_POST['custom_tab_enabled_spec']) && $_POST['custom_tab_enabled_spec'] ) ? 'yes' : 'no' );
    update_post_meta( $post_id, 'custom_tab_title_spec', $_POST['custom_tab_title_spec']);
    update_post_meta( $post_id, 'custom_tab_content_spec', $_POST['custom_tab_content_spec']);
	update_post_meta( $post_id, '_title_icon_spec', $_POST['_title_icon_spec']);
}
add_action('woocommerce_process_product_meta', 'process_product_meta_custom_tab_spec', 10, 2);


/**
 * Display Tab
 *
 * Display Custom Tab on Frontend of Website for WooCommerce 2.0
 */
add_filter( 'woocommerce_product_tabs', 'woocommerce_product_custom_tab_spec' );


function woocommerce_product_custom_tab_spec( $tabs ) {
    global $post, $product;

    $custom_tab_options_spec = array(
        'enabled' => get_post_meta($post->ID, 'custom_tab_enabled_spec', true),
        'titlec' => get_post_meta($post->ID, 'custom_tab_title_spec', true),
        'contentc' => get_post_meta($post->ID, 'custom_tab_content_spec', true),
		'title_icon' => get_post_meta($post->ID, '_title_icon_spec', true),
    );

    if ( $custom_tab_options_spec['enabled'] == 'yes' ){
        $tabs['woo_custom'] = array(
            'title'    => '<i class="fa '. $custom_tab_options_spec['title_icon'] .'"></i>' .$custom_tab_options_spec['titlec'],
            'priority' => 60,
            'callback' => 'custom_product_tabs_panel_content_spec',
            'content'  => $custom_tab_options_spec['contentc']
        );
    }
    return $tabs;
}


/**
* Render the custom product tab panel content for the callback 'custom_product_tabs_panel_content_spec'
*/
function custom_product_tabs_panel_content_spec( $key, $custom_tab_options_spec ) {

    global $post, $product;

    $custom_tab_options_spec = array(
        'enabled' => get_post_meta($post->ID, 'custom_tab_enabled_spec', true),
        'titlec' => get_post_meta($post->ID, 'custom_tab_title_spec', true),
        'contentc' => get_post_meta($post->ID, 'custom_tab_content_spec', true),
		'title_icon' => get_post_meta($post->ID, '_title_icon_spec', true),
    );

	echo '<div class="custom_tab_inner">';
    echo '<h2>' . $custom_tab_options_spec['titlec'] . '</h2>';
    echo do_shortcode($custom_tab_options_spec['contentc']);
	echo '</div><div class="clear"></div>';

}