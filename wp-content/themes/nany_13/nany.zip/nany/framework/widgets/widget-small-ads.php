<?php
/**
 * widget-small-ads.php
 *
 * Plugin Name: Nany Small Ads
 * Plugin URI: http://www.themeforest.net/user/defatch
 * Description: A widget that displays small ads.
 * Version: 1.0
 * Author: Defatch
 * Author URI: http://www.themeforest.net/user/defatch
*/

class Nany_small_ads extends WP_Widget {

	/**
	 * Specifies the widget name, description, class name and instatiates it
	 */
	public function __construct() {
		parent::__construct(
			'widget-nany-small-ads',
			__( 'Nany: 150x150 Ads', 'nany' ),
			array(
				'classname'   => 'widget-nany-small-ads',
				'description' => __( 'A custom widget that displays small ads.', 'nany' )
			)
		);
	}


	/**
	 * Generates the back-end layout for the widget
	 */
	public function form( $instance ) {
		// Default widget settings
		$defaults = array(
			'title'               => '',
			'small_ads_one'       => '[small_ads link="#" target="new_window" image="IMAGE URL" alt="IMAGE ALT TEXT" class="custom-class"]',
			'small_ads_two'       => '[small_ads link="#" target="new_window" image="IMAGE URL" alt="IMAGE ALT TEXT" class="custom-class"]',
			'small_ads_three'     => '[small_ads link="#" target="new_window" image="IMAGE URL" alt="IMAGE ALT TEXT" class="custom-class"]',
			'small_ads_four'      => '[small_ads link="#" target="new_window" image="IMAGE URL" alt="IMAGE ALT TEXT" class="custom-class"]',
			'custom_class'        => ''
		);

		$instance = wp_parse_args( (array) $instance, $defaults );

		// The widget content ?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'nany' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $instance['title'] ); ?>">
		</p>

		<!-- Small_ads_one -->
		<p>
			<label for="<?php echo $this->get_field_id( 'small_ads_one' ); ?>"><?php _e( '150 Ad One:', 'nany' ); ?></label>
			<textarea cols="30" rows="3" class="widefat" id="<?php echo $this->get_field_id( 'small_ads_one' ); ?>" name="<?php echo $this->get_field_name( 'small_ads_one' ); ?>"><?php echo esc_textarea( $instance['small_ads_one'] ); ?></textarea>
		</p>

		<!-- Small_ads_two -->
		<p>
			<label for="<?php echo $this->get_field_id( 'small_ads_two' ); ?>"><?php _e( '150 Ad Two:', 'nany' ); ?></label>
			<textarea cols="30" rows="3" class="widefat" id="<?php echo $this->get_field_id( 'small_ads_two' ); ?>" name="<?php echo $this->get_field_name( 'small_ads_two' ); ?>"><?php echo esc_textarea( $instance['small_ads_two'] ); ?></textarea>
		</p>

		<!-- Small_ads_three -->
		<p>
			<label for="<?php echo $this->get_field_id( 'small_ads_three' ); ?>"><?php _e( '150 Ad Three:', 'nany' ); ?></label>
			<textarea cols="30" rows="3" class="widefat" id="<?php echo $this->get_field_id( 'small_ads_three' ); ?>" name="<?php echo $this->get_field_name( 'small_ads_three' ); ?>"><?php echo esc_textarea( $instance['small_ads_three'] ); ?></textarea>
		</p>

		<!-- Small_ads_four -->
		<p>
			<label for="<?php echo $this->get_field_id( 'small_ads_four' ); ?>"><?php _e( '150 Ad Four:', 'nany' ); ?></label>
			<textarea cols="30" rows="3" class="widefat" id="<?php echo $this->get_field_id( 'small_ads_four' ); ?>" name="<?php echo $this->get_field_name( 'small_ads_four' ); ?>"><?php echo esc_textarea( $instance['small_ads_four'] ); ?></textarea>
		</p>

		<!-- Custom Class -->
		<p>
			<label for="<?php echo $this->get_field_id( 'custom_class' ); ?>"><?php _e( 'Custom Class:', 'nany' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'custom_class' ); ?>" name="<?php echo $this->get_field_name( 'custom_class' ); ?>" value="<?php echo esc_attr( $instance['custom_class'] ); ?>">
		</p> <?php
	}


	/**
	 * Processes the widget's values
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		// Update values
		$instance['title']           = strip_tags( stripslashes( $new_instance['title'] ) );
		$instance['small_ads_one']   = strip_tags( stripslashes( $new_instance['small_ads_one'] ) );
		$instance['small_ads_two']   = strip_tags( stripslashes( $new_instance['small_ads_two'] ) );
		$instance['small_ads_three'] = strip_tags( stripslashes( $new_instance['small_ads_three'] ) );
		$instance['small_ads_four']  = strip_tags( stripslashes( $new_instance['small_ads_four'] ) );
		$instance['custom_class']    = strip_tags( stripslashes( $new_instance['custom_class'] ) );

		return $instance;
	}


	/**
	 * Output the contents of the widget
	 */
	public function widget( $args, $instance ) {
		// Extract the arguments
		extract( $args );

		$title           = apply_filters( 'widget_title', $instance['title'] );
		$small_ads_one   = apply_filters( 'widget_text', $instance['small_ads_one']);
		$small_ads_two   = apply_filters( 'widget_text', $instance['small_ads_two']);
		$small_ads_three = apply_filters( 'widget_text', $instance['small_ads_three']);
		$small_ads_four  = apply_filters( 'widget_text', $instance['small_ads_four']);
		$custom_class    = $instance['custom_class'];

		// Display the markup before the widget (as defined in functions.php)
		echo $before_widget;

		if ( $title ) {
			echo $before_title . $title . $after_title;
		}

		echo '<ul class="nany_small_ads '. $custom_class .'">';
			echo $small_ads_one;
			echo $small_ads_two;
			echo $small_ads_three;
			echo $small_ads_four;
		echo '</ul>';

		// Display the markup after the widget (as defined in functions.php)
		echo $after_widget;
	}
}

// Register the widget using an annonymous function
add_action( 'widgets_init', create_function( '', 'register_widget( "Nany_small_ads" );' ) );
?>