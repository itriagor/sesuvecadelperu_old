<?php

/* ==============================================
  All Scripts and Styles Enqueue in this file.
=============================================== */

function nany_enqueue_style() {

  // Carousel style
  wp_enqueue_style('owl-style-carousel',  SCRIPTS . '/owl/owl.carousel.css', false );
  wp_enqueue_style('owl-style-theme',  SCRIPTS . '/owl/owl.theme.css', false );
  wp_enqueue_style('owl-style-transition',  SCRIPTS . '/owl/owl.transitions.css', false );

  wp_enqueue_style('bootstrap', STYLES . '/bootstrap.css', false, '', 'all');
  wp_enqueue_style('animate', STYLES . '/animate.css', false, '', 'all');
  wp_enqueue_style('fontawesome', STYLES . '/font-awesome.min.css', false, '', 'all');
  wp_enqueue_style('styles', STYLES . '/styles.css', false, '', 'all');
  wp_enqueue_style('style', get_template_directory_uri() . '/style.css', false, '', 'all');
  wp_enqueue_style('magnific', STYLES . '/magnific-popup.css', false, '', 'all');
  wp_enqueue_style('YTPlayer', STYLES . '/YTPlayer.css', false, '', 'all');

  // Woocommerce style
  if (class_exists( 'Woocommerce' )){
    wp_enqueue_style( 'my-woocommerce', get_template_directory_uri() . '/framework/plugins/woocommerce/woocommerce.css', null, 1.0, 'all' );
  }

  if(!ot_get_option('nany_site_layout')) {
    wp_enqueue_style('responsive', STYLES . '/responsive.css', false, '', 'all');
  }

}

add_action( 'wp_enqueue_scripts', 'nany_enqueue_style' );

/* ==============================================
   All Scripts
=============================================== */
function nany_enqueue_script() {

  // jQuery
  wp_enqueue_script( 'jquery' );
  // wp_deregister_script( 'jquery' );
  // wp_enqueue_script('jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js', '', '', true);
  wp_enqueue_script('jquery-ui.min', 'http://code.jquery.com/ui/1.11.0/jquery-ui.min.js', array('jquery'), '', true);

  // Filter Scripts
  wp_enqueue_script('jquery-quicksand', SCRIPTS . '/jquery.quicksand.js', array('jquery'), '', false);
  wp_enqueue_script('jquery-easing', SCRIPTS . '/jquery.easing.1.3.js', array('jquery'), '', false);
  wp_enqueue_script('quicksand-custom', SCRIPTS . '/quicksand.custom.js', array('jquery'), '', true);

  // Modernizr Custom Script
  wp_enqueue_script('modernizr-scripts', SCRIPTS . '/modernizr.custom.js', array('jquery'), '', true);

  // Bootstrap Script
  wp_enqueue_script('bootstrap-scripts', SCRIPTS . '/bootstrap.min.js', array('jquery'), '', true);

  // FitVideos
  wp_enqueue_script('jquery-fitvids', SCRIPTS . '/jquery.fitvids.js', array('jquery'), '', true);

  // Magnific Popup Script
  wp_enqueue_script('magnific-popup-scripts', SCRIPTS . '/jquery.magnific-popup.min.js', array('jquery'), '', true);

  $disable_sticky_nav = ot_get_option('disable_sticky_nav');

  if(!$disable_sticky_nav) {
    // Sticky Script
    wp_enqueue_script('sticky-scripts', SCRIPTS . '/jquery.sticky.js', array('jquery'), '', true);
  }

  // TouchSwipe Script
  wp_enqueue_script('touchswipe-scripts', SCRIPTS . '/jquery.touchSwipe.min.js', array('jquery'), '', true);

  // Touch Effects Script
  wp_enqueue_script('toucheffects-scripts', SCRIPTS . '/toucheffects.js', array('jquery'), '', true);

  // Waypoints Script
  wp_enqueue_script('waypoints-scripts', SCRIPTS . '/waypoints.min.js', array('jquery'), '', true);

  // Wow Script
  wp_enqueue_script('wow-scripts', SCRIPTS . '/wow.min.js', array('jquery'), '', true);

  // Theme scripts
  wp_enqueue_script('main-scripts', SCRIPTS . '/scripts.js', array('jquery'), '', true);

  // Register Owl Scripts
  wp_enqueue_script( 'owl-script', SCRIPTS . '/owl/owl.carousel.min.js', array('jquery'), false, true );

  // Dynamic style
  wp_enqueue_style('dynamic-style', get_template_directory_uri() . '/dynamic-style.php', false, '', 'all');

  // Comment Script
  if(is_singular() && comments_open()){
    wp_enqueue_script( 'comment-reply' );
  }

  function comment_validation_init() { ?>
    <script type="text/javascript" src="//ajax.aspnetcdn.com/ajax/jquery.validate/1.9/jquery.validate.min.js"></script>
    <script type="text/javascript">
    jQuery(document).ready(function($) {
    $('#commentform').validate({

    rules: {
      author: {
        required: true,
        minlength: 2
      },

      email: {
        required: true,
        email: true
      },

      comment: {
        required: true,
        minlength: 20
      }
    },

    messages: {
      author: "Please fill the required field",
      email: "Please enter a valid email address.",
      comment: "Please fill the required field"
    },

    errorElement: "div",
    errorPlacement: function(error, element) {
      element.after(error);
    }

    });
    });
    </script>
    <?php
    }
  add_action('wp_footer', 'comment_validation_init');

}

add_action( 'wp_enqueue_scripts', 'nany_enqueue_script' );


/* Fixes of : Custom Post Type - Portfolio active state of post menu item issue */
function dtbaker_wp_nav_menu_objects($sorted_menu_items, $args){
  // check if the current page is really a blog post.
  global $wp_query;
  global $post;
  $current_page = $post;
  if(!empty($wp_query->queried_object_id)){
    if($current_page && $current_page->post_type=='post'){
      //yes!
    }else{
      $current_page = false;
    }
  }else{
    $current_page = false;
  }

  $home_page_id = (int) get_option( 'page_for_posts' );
  foreach($sorted_menu_items as $id => $menu_item){
    if ( ! empty( $home_page_id ) && 'post_type' == $menu_item->type && empty( $wp_query->is_page ) && $home_page_id == $menu_item->object_id ){
      if(!$current_page){
        foreach($sorted_menu_items[$id]->classes as $classid=>$classname){
          if($classname=='current_page_parent'){
            unset($sorted_menu_items[$id]->classes[$classid]);
          }
        }
      }
    }
  }
  return $sorted_menu_items;
}
add_filter('wp_nav_menu_objects','dtbaker_wp_nav_menu_objects',10,2);


/* ==============================================
    Custom WordPress login
=============================================== */
function custom_login_head() {
  $login_logo = ot_get_option('login_logo');
  if($login_logo) {
    $login_logo = $login_logo;
  } else {
    $login_logo = IMAGES . '/logo-black.png';
  }
  if($login_logo){
  echo "
    <style>
    body.login #login h1 a {
    background: url('$login_logo') no-repeat scroll center bottom transparent;
    height: 100px;
    width: 100%;
    margin-bottom:0px;
    }
    </style>";
  }
}
add_action('login_head', 'custom_login_head');

/* WordPress login logo link wordpress.org instead of our own link  */
function custom_login_url() {
  return site_url();
}
add_filter( 'login_headerurl', 'custom_login_url', 10, 4 );

/* WordPress login logo title instead of site title  */
function custom_login_title() {
     return get_bloginfo('name');
}
add_filter('login_headertitle', 'custom_login_title');


/* ==============================================
    Exclude category from blog
=============================================== */
function excludeCat($query) {
  if ( $query->is_home ) {
    $exclude_cat_ids = ot_get_option('exclude_categories_from_blog');
    if($exclude_cat_ids){
      foreach( $exclude_cat_ids as $exclude_cat_id ) {
        $exclude_from_blog[] = '-'. $exclude_cat_id;
      }
      $query->set('cat', implode(',', $exclude_from_blog));
    }
  }
  return $query;
}
add_filter('pre_get_posts', 'excludeCat');


/* ==============================================
   Blog Excerpt
=============================================== */
function custom_excerpt_length( $length ) {
  $excerpt_length = ot_get_option('blog_excerpt_lenght');
  if($excerpt_length) {
    $excerpt_length = $excerpt_length;
  } else {
    $excerpt_length = '82';
  }
  return $excerpt_length;
}
add_filter( 'excerpt_length', 'custom_excerpt_length', 999 );

function new_excerpt_more( $more ) {
  return '.';
}
add_filter('excerpt_more', 'new_excerpt_more');

/* ==============================================
   HEX to RGB
=============================================== */
/* HEX to RGB */
function hex2rgb($hex) {
   $hex = str_replace("#", "", $hex);

   if(strlen($hex) == 3) {
      $r = hexdec(substr($hex,0,1).substr($hex,0,1));
      $g = hexdec(substr($hex,1,1).substr($hex,1,1));
      $b = hexdec(substr($hex,2,1).substr($hex,2,1));
   } else {
      $r = hexdec(substr($hex,0,2));
      $g = hexdec(substr($hex,2,2));
      $b = hexdec(substr($hex,4,2));
   }

   $rgb = array($r, $g, $b);
   return implode(",", $rgb);
}
?>