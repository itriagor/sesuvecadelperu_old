<?php
/**
 * content-gallery.php
 *
 * The default template for displaying content.
 */
?>

<!-- Post Starts -->
<article id="post-<?php the_ID(); ?>" <?php post_class('post-list'); ?>>

  <?php
  // If the post has a thumbnail and it's not password protected
  // then display the thumbnail
  if (get_post_meta( $post->ID, "gallery_content", true ) && !post_password_required()) { ?>
    <div id="blog-slider" class="owl-carousel owl-theme zoom-gallery">
      <?php $items = get_post_meta( $post->ID, "gallery_content", true );
          if ($items) {
          foreach($items as $item) :
              if ($item['image']) {
      ?>
      <a href="<?php echo esc_url($item['image']); ?>" class="image-popup-fit-width" title="<?php echo esc_attr($item['title']); ?>">
          <img src="<?php echo esc_attr($item['image']); ?>" alt="<?php echo esc_attr($item['title']); ?>" style="width:100%;"/>
      </a>

      <?php } elseif ($item['video']) { echo '<p class="fit-videos">' . $item['video'] . '</p>'; } endforeach; } ?>
    </div>
  <?php
  } elseif ( has_post_thumbnail() && ! post_password_required() ) {
    $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumbnail_size' );
    $url = $thumb['0']; ?>
    <div class="featured-image zoom-gallery">
      <a href="<?php echo esc_url($url); ?>" class="image-popup-fit-width" title="<?php echo esc_attr(the_title()); ?>">
          <?php add_image_size( 'custom-size', 760, 9999 ); // Hard crop left top
                the_post_thumbnail('custom-size');
          ?>
      </a>
    </div>
  <?php } ?>

  <div class="post-meta-before">
      <?php
          // Display the meta information
          nany_post_meta_before();
      ?>
  </div>

  <?php

    // If single page, display the title
    // Else, we display the title in a link
    if ( is_single() ) : ?>
      <h2 class="post-title"><?php the_title(); ?></h2>
    <?php else : ?>
      <a href="<?php esc_url(the_permalink()); ?>" rel="bookmark" class="post-title"><?php the_title(); ?></a>
    <?php endif; ?>

    <div class="post-meta-after">
      <?php
        // Display the meta information
        nany_post_meta_after();
      ?>
    </div>

  <!-- Article content -->
  <div class="post-content">
    <?php
      if ( !is_single() && !post_password_required() ) {
        $excerpt = the_excerpt();
        echo '<p>'. $excerpt .'</p>';
      } elseif ( post_password_required() ) { ?>
        <div class="password-protected"><?php the_content(); ?></div>
      <?php
      } else {
        the_content('',FALSE,'');

        ?>
        <div class="pagelink"><?php wp_link_pages(); ?></div>
        <?php echo nany_post_social_share(); ?>
        <?php
      }
      if ( !is_single() ) {
        $blog_readmore_btn = ot_get_option('blog_readmore_btn');
        if($blog_readmore_btn) {
          $blog_readmore_btn = $blog_readmore_btn;
        } else {
          $blog_readmore_btn = __( 'Read More', 'nany' );
        }
    ?>
    <a href="<?php esc_url(the_permalink()); ?>" class="btn-style-four read-more uppercase"><?php echo $blog_readmore_btn; ?></a>
    <?php } ?>
  </div> <!-- end post-content -->

<?php
  // If we have a single page and the author bio exists, display it
  if ( is_single() ) {
    $hide_author_box = ot_get_option('hide_author_box');
    if(!$hide_author_box) {
?>
  <!-- Author Bio -->
  <div class="hr"></div>
  <div class="author-bio">
    <div class="author-image">
        <?php echo get_avatar( get_the_author_meta( 'ID' ), 100 ); ?>
    </div>
    <div class="author-name"><h3><?php echo get_the_author(); ?></h3></div>
    <?php if(get_the_author_meta( 'description' )) { ?>
    <div class="author-description">
        <p><?php echo the_author_meta( 'description' ); ?></p>
    </div>
    <?php } ?>
  </div> <!-- end author-bio -->
  <div class="hr"></div>

<?php } } ?>

</article>