<?php
/**
 * template-full-width.php
 *
 * Template Name: Full Width Page
 */
?>

<?php get_header(); ?>

	<div class="main-content col-md-12" role="main">
		<?php while( have_posts() ) : the_post(); ?>
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<!-- Article content -->
				<div class="entry-content">
					<?php the_content(); ?>

					<div class="pagelink"><?php wp_link_pages(); ?></div>
				</div> <!-- end entry-content -->

			</article>

		<?php endwhile; ?>
	</div> <!-- end main-content -->

<?php get_footer(); ?>