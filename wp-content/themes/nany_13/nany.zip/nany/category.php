<?php
/**
 * category.php
 *
 * The template for displaying category pages.
 */

$full_width = ot_get_option('enable_fullwidth');
$sidebar_position = ot_get_option('sidebar_position');

if(!$full_width) {
	$full_width = 'col-lg-8 col-md-8 col-sm-12';
} else {
	$full_width = 'col-lg-12';
}
 ?>

<?php get_header(); ?>

<?php if($full_width && $sidebar_position === 'left') { get_sidebar(); } ?>

	<div class="main-content <?php echo $full_width; ?>" role="main">
		<?php if ( have_posts() ) : ?>
			<header class="page-header">
				<h1>
					<?php
						printf( __( 'Category Archives for %s', 'nany' ), single_cat_title( '', false ) );
					?>
				</h1>

				<?php
					// Show an optional category description.
					if ( category_description() ) {
						echo '<p>' . category_description() . '</p>';
					}
				?>
			</header>

			<?php while( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'content', get_post_format() ); ?>
			<?php endwhile; ?>

			<?php nany_paging_nav(); ?>
		<?php else : ?>
			<?php get_template_part( 'content', 'none' ); ?>
		<?php endif; ?>
	</div> <!-- end main-content -->

<?php if($full_width && $sidebar_position === 'right') { get_sidebar(); } ?>

<?php get_footer(); ?>