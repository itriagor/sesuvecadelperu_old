<?php
/**
 * footer.php
 *
 * The template for displaying the footer.
 */
?>
<?php
$animation = ot_get_option('footer_widgets_animations');
if ($animation) {
	$animation = $animation . ' wow animated';
} else {
	$animation = '';
}

if(is_page()) {
	$hide_footer_widgets = get_post_meta( $post->ID, "hide_footer_widgets", true );
} else {
	$hide_footer_widgets = '';
}

if ( is_page_template( 'template-extra-full-width.php' ) ) {
?>

<?php } else { ?>
		</div> <!-- end row -->
	</div> <!-- end container -->
<?php } ?>

</div> <!-- Wrapper -->

	<!-- FOOTER -->
	<?php if (!$hide_footer_widgets) { ?>
	<footer id="footer" class="site-footer">

		<?php if(!ot_get_option('footer_widgets')) { ?>
		<div class="container text-center">
	    <div class="row">

				<div class="footer-widget col-lg-3 col-md-3 col-sm-6 <?php echo $animation; ?>">
					<?php dynamic_sidebar( 'footer-one' );  ?>
				</div>
				<div class="footer-widget col-lg-3 col-md-3 col-sm-6 <?php echo $animation; ?>">
					<?php dynamic_sidebar( 'footer-two' );  ?>
				</div>
				<div class="footer-widget col-lg-3 col-md-3 col-sm-6 <?php echo $animation; ?>">
					<?php dynamic_sidebar( 'footer-three' );  ?>
				</div>
				<div class="footer-widget col-lg-3 col-md-3 col-sm-6 <?php echo $animation; ?>">
					<?php dynamic_sidebar( 'footer-four' );  ?>
				</div>

			</div> <!-- end row -->
		</div> <!-- end container -->
		<?php } ?>

		<?php if(!ot_get_option('copyright_bar')) { ?>
		<div class="bottom-bar">
			<div class="container">

				<div class="copyright">
					<p class="copyright-text">
						<?php echo ot_get_option('copyright_area_text'); ?>
					</p>
				</div>

				<div class="footer-menu">
					<?php
						if(has_nav_menu('footer-menu')) {
		            wp_nav_menu(array('theme_location'=>'footer-menu',
		                'walker'=>new wp_bootstrap_navwalker(),
		                'container_class'=>'',
		                'container_id'=>'')
		            );
		        }
					?>
				</div>

			</div> <!-- end copyright -->
		</div>
		<?php } ?>

	</footer> <!-- end site-footer -->
	<?php } else { ?>
	<div class="bottom-bar hide-footer">
		<div class="container">

			<div class="copyright">
				<p class="copyright-text">
					<?php echo ot_get_option('copyright_area_text'); ?>
				</p>
			</div>
		</div>
	</div>
	<?php } ?>

	<?php wp_footer(); ?>

</body>
</html>