<?php
/**
 * single-portfolio.php
 *
 * The template for displaying single portfolios.
 */
?>

<?php get_header(); ?>

    <div class="main-content" role="main">
        <?php while( have_posts() ) : the_post(); ?>
            <!-- Post Starts -->
            <article id="post-<?php the_ID(); ?>" <?php post_class('post-list'); ?>>

            <?php $portfolio_style = get_post_meta( $post->ID, "portfolio_style", true );
                if($portfolio_style === 'style-1') {

                    $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
                    $large_image = $large_image[0];

            ?>
                <!-- Article content -->
                <div class="port-featured-image zoom-gallery">
                    <a href="<?php echo esc_url($large_image); ?>" class="image-popup-fit-width" title="<?php echo esc_attr(the_title()); ?>">
                        <img src="<?php echo esc_attr($large_image); ?>" alt="<?php echo esc_attr(the_title()); ?>">
                    </a>
                </div>
                <div class="portfolio-content">
                    <?php the_content(); ?>
                </div> <!-- end portfolio-content -->
            <?php } ?>

            <?php if($portfolio_style === 'style-2') { ?>
            <div class="col-lg-6 col-md-6 col-sm-12">
                <?php if (get_post_meta( $post->ID, "portfolio_images_videos", true )) { ?>
                <div id="simple-slider-1" class="owl-carousel owl-theme zoom-gallery">

                    <?php $items = get_post_meta( $post->ID, "portfolio_images_videos", true );

                        if ($items) {
                        foreach($items as $item) :
                            if ($item['image']) {

                    ?>
                    <a href="<?php echo esc_url($item['image']); ?>" class="image-popup-fit-width" title="<?php echo esc_attr($item['title']) ; ?>">
                        <img src="<?php echo esc_attr($item['image']); ?>" alt="<?php echo esc_attr($item['title']); ?>" style="width:100%;"/>
                    </a>

                    <?php } elseif ($item['video']) { echo $item['video']; } endforeach; } ?>

                </div>
                <?php } ?>

                <?php
                $items = get_post_meta( $post->ID, "portfolio_images_videos", true );
                if(!$items) {
                // If the post has a thumbnail and it's not password protected
                // then display the thumbnail
                if ( has_post_thumbnail() ) :
                    $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumbnail_size' );
                    $url = $thumb['0']; ?>
                <div class="featured-image zoom-gallery">
                    <a href="<?php echo esc_url($url); ?>" class="image-popup-fit-width" title="<?php echo esc_attr(the_title()); ?>">
                        <?php add_image_size( 'custom-size', 560, 9999 ); // Hard crop left top
                           the_post_thumbnail('custom-size');
                        ?>
                    </a>
                </div>
                <?php endif; } ?>

            </div> <!-- col-lg-6 col-md-6 col-sm-12 -->

            <div class="col-lg-6 col-md-6 col-sm-12">

                <?php
                    $date = get_post_meta( $post->ID, 'portfolio_date', true );
                    $skills = get_post_meta( $post->ID, 'portfolio_skills', true );
                    $category = get_post_meta( $post->ID, 'disable_category_list', true );
                ?>

                <div class="project-details">
                    <?php if($date) { ?>
                        <span><i class="fa fa-calendar"></i><?php echo $date ?></span>
                    <?php } ?>
                    <?php if($skills) { ?>
                        <span><i class="fa fa-list"></i><?php echo $skills ?></span>
                    <?php } ?>
                    <?php if(!$category) { ?>
                    <?php echo get_the_term_list( $post->ID, 'portfolio_category', '<span class="portfolio-category-list"><i class="fa fa-bookmark-o"></i>', ', ', '</a></span>' ); ?>
                    <?php } ?>
                </div>

                <hr class="separator-dark-border">

                <!-- Article content -->
                <div class="portfolio-content">
                    <?php the_content(); ?>
                </div> <!-- end portfolio-content -->

            </div> <!-- col-lg-6 col-md-6 col-sm-12 -->

            <?php } ?>

            <?php if($portfolio_style === 'style-3') { ?>
            <div class="col-lg-12">
                <?php if (get_post_meta( $post->ID, "portfolio_images_videos", true )) { ?>
                <div id="simple-slider-1" class="owl-carousel owl-theme zoom-gallery">

                    <?php $items = get_post_meta( $post->ID, "portfolio_images_videos", true );

                        if ($items) {
                        foreach($items as $item) :
                            if ($item['image']) {

                    ?>
                    <a href="<?php echo esc_url($item['image']); ?>" class="image-popup-fit-width" title="<?php echo esc_attr($item['title']); ?>">
                        <img src="<?php echo esc_attr($item['image']); ?>" alt="<?php echo esc_attr($item['title']); ?>" style="width:100%;"/>
                    </a>

                    <?php } elseif ($item['video']) { echo $item['video']; } endforeach; } ?>

                </div>
                <?php } ?>

                <?php
                $items = get_post_meta( $post->ID, "portfolio_images_videos", true );
                if(!$items) {
                // If the post has a thumbnail and it's not password protected
                // then display the thumbnail
                if ( has_post_thumbnail() ) :
                    $thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumbnail_size' );
                    $url = $thumb['0']; ?>
                <div class="featured-image zoom-gallery">
                    <a href="<?php echo esc_url($url); ?>" class="image-popup-fit-width" title="<?php echo esc_attr(the_title()); ?>">
                        <?php add_image_size( 'custom-size', 560, 9999 ); // Hard crop left top
                           the_post_thumbnail('custom-size');
                        ?>
                    </a>
                </div>
                <?php endif; } ?>

            </div> <!-- col-lg-12 -->

            <div class="col-lg-12">

                <hr class="separator-dark-border border-1">

                <div class="col-lg-4 col-md-4 col-sm-12">
                    <?php
                        $date = get_post_meta( $post->ID, 'portfolio_date', true );
                        $skills = get_post_meta( $post->ID, 'portfolio_skills', true );
                        $category = get_post_meta( $post->ID, 'disable_category_list', true );
                    ?>

                    <div class="project-details">
                        <?php if($date) { ?>
                            <span><i class="fa fa-calendar"></i><?php echo $date ?></span>
                        <?php } ?>
                        <?php if($skills) { ?>
                            <span><i class="fa fa-list"></i><?php echo $skills ?></span>
                        <?php } ?>
                        <?php if(!$category) { ?>
                        <?php echo get_the_term_list( $post->ID, 'portfolio_category', '<span class="portfolio-category-list"><i class="fa fa-bookmark-o"></i>', ', ', '</a></span>' ); ?>
                        <?php } ?>
                    </div>
                </div>

                <!-- Article content -->
                <div class="portfolio-content col-lg-8 col-md-8 col-sm-12">
                    <?php the_content(); ?>
                </div> <!-- end portfolio-content -->

            </div> <!-- col-lg-12 -->

            <?php } ?>

            </article>
        <?php endwhile; ?>
    </div> <!-- end main-content -->

<?php get_footer(); ?>