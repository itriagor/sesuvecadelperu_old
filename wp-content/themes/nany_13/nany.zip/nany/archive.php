<?php
/**
 * archive.php
 *
 * The template for displaying archive pages.
 */

$full_width = ot_get_option('enable_fullwidth');
$sidebar_position = ot_get_option('sidebar_position');

if(!$full_width) {
	$full_width = 'col-lg-8 col-md-8 col-sm-12';
} else {
	$full_width = 'col-lg-12';
}
 ?>

<?php get_header(); ?>

<?php if($full_width && $sidebar_position === 'left') { get_sidebar(); } ?>

	<div class="main-content <?php echo $full_width; ?>" role="main">
		<?php if ( have_posts() ) : ?>
			<header class="page-header">
				<h1>
					<?php
						if ( is_day() ) {
							printf( __( 'Daily Archives for %s', 'nany' ), get_the_date() );
						} elseif ( is_month() ) {
							printf( __( 'Monthly Archives for %s', 'nany' ), get_the_date( _x( 'F Y', 'Monthly archives date format', 'nany' ) ) );
						} elseif ( is_year() ) {
							printf( __( 'Yearly Archives for %s', 'nany' ), get_the_date( _x( 'Y', 'Yearly archives date format', 'nany' ) ) );
						} else {
							_e( 'Archives', 'nany' );
						}
					?>
				</h1>
			</header>

			<?php while( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'content', get_post_format() ); ?>
			<?php endwhile; ?>

			<?php nany_paging_nav(); ?>
		<?php else : ?>
			<?php get_template_part( 'content', 'none' ); ?>
		<?php endif; ?>
	</div> <!-- end main-content -->

<?php if($full_width && $sidebar_position === 'right') { get_sidebar(); } ?>

<?php get_footer(); ?>