<?php
/**
 * Single Product Sale Flash
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $post, $product;
?>

<?php if (get_post_meta( get_the_ID(), '_badge_select', true ) == 'new') {
		echo '<span class="bd-' . get_post_meta( get_the_ID(), '_badge_select', true ) .'"><p>' . get_post_meta( get_the_ID(), '_badge_select', true ) .'</p></span>';
	} elseif (get_post_meta( get_the_ID(), '_badge_select', true ) == 'select') {
		echo '<span class="bd-' . get_post_meta( get_the_ID(), '_badge_select', true ) .'"><p>' . get_post_meta( get_the_ID(), '_badge_select', true ) .'</p></span>';
	} elseif (get_post_meta( get_the_ID(), '_badge_select', true ) == 'hot') {
		echo '<span class="bd-' . get_post_meta( get_the_ID(), '_badge_select', true ) .'"><p>' . get_post_meta( get_the_ID(), '_badge_select', true ) .'</p></span>';
	} elseif (get_post_meta( get_the_ID(), '_badge_select', true ) == 'offer') {

		if (get_post_meta( get_the_ID(), '_badge_texts', true )) {
			echo '<span class="bd-custom bd-' . get_post_meta( get_the_ID(), '_badge_select', true ) .'"><p>'. get_post_meta( get_the_ID(), '_badge_texts', true ) .'</p><small><p>' . get_post_meta( get_the_ID(), '_badge_select', true ) .'</p></small></span>';
		} else {
			echo '<span class="bd-' . get_post_meta( get_the_ID(), '_badge_select', true ) .'"><p>' . get_post_meta( get_the_ID(), '_badge_select', true ) .'</p></span>';
		}

	} elseif (get_post_meta( get_the_ID(), '_badge_select', true ) == 'sale') {
		echo '<span class="bd-' . get_post_meta( get_the_ID(), '_badge_select', true ) .'"><p>' . get_post_meta( get_the_ID(), '_badge_select', true ) .'</p></span>';
	} elseif (get_post_meta( get_the_ID(), '_badge_select', true ) == 'from') {

		if (get_post_meta( get_the_ID(), '_badge_texts', true )) {
			echo '<span class="bd-custom bd-' . get_post_meta( get_the_ID(), '_badge_select', true ) .'"><p>' . get_post_meta( get_the_ID(), '_badge_select', true ) .'</p><small><p>'. get_post_meta( get_the_ID(), '_badge_texts', true ) .'</p></small></span>';
		} else {
			echo '<span class="bd-' . get_post_meta( get_the_ID(), '_badge_select', true ) .'"><p>' . get_post_meta( get_the_ID(), '_badge_select', true ) .'</p></span>';
		}

	} elseif (get_post_meta( get_the_ID(), '_badge_select', true ) == 'free') {
		echo '<span class="bd-' . get_post_meta( get_the_ID(), '_badge_select', true ) .'"><p>' . get_post_meta( get_the_ID(), '_badge_select', true ) .'</p></span>';
	}
?>
