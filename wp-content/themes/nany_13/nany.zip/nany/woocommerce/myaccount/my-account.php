<?php
/**
 * My Account page
 *
 * @author 		WooThemes
 * @edited by     McLane Creative
 * @package 	WooCommerce/Templates
 * @version     2.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

wc_print_notices(); ?>
<div class="wc-account-tab">
	<ul class="wc-tabs">
		<li>
			<input type="radio" class="display-none" checked name="tabs" id="tab1">
			<label for="tab1"><i class="fa fa-home tabs-icon"></i> <?php _e('Dashboard', 'woocommerce'); ?></label>
			<div id="tab-content1" class="wc-tab-content animated fadeIn">
				<p class="myaccount_user">
					<?php
					printf(
					__( 'Hello <strong>%1$s</strong> (not %1$s? <a href="%2$s">Sign out</a>).</p>', 'woocommerce' ) . ' ',
					$current_user->display_name,
						wp_logout_url( get_permalink( wc_get_page_id( 'myaccount' ) ) )
					);

					printf( __( '<p>From your account dashboard you can view your recent orders, manage your shipping and billing addresses and <a href="%s">edit your password and account details</a>.', 'woocommerce' ),
						wc_customer_edit_account_url()
					);
					?>
				</p>
			</div>
		</li>
		<li>
			<input type="radio" class="display-none" name="tabs" id="tab2">
			<label for="tab2"><i class="fa fa-download tabs-icon"></i> <?php _e('Downloads', 'woocommerce'); ?></label>
			<div id="tab-content2" class="wc-tab-content animated fadeIn">
				<?php wc_get_template( 'myaccount/my-downloads.php' ); ?>
			</div>
		</li>
		<li>
			<input type="radio" class="display-none" name="tabs" id="tab3">
			<label for="tab3"><i class="fa fa-shopping-cart tabs-icon"></i> <?php _e('Orders', 'woocommerce'); ?></label>
			<div id="tab-content3" class="wc-tab-content animated fadeIn">
				<?php wc_get_template( 'myaccount/my-orders.php', array( 'order_count' => $order_count ) ); ?>
			</div>
		</li>
		<li>
			<input type="radio" class="display-none" name="tabs" id="tab5">
			<label for="tab5"><i class="fa fa-edit tabs-icon"></i> <?php _e('Edit Details', 'woocommerce'); ?></label>
			<div id="tab-content5" class="wc-tab-content animated fadeIn">
				<?php wc_get_template( 'myaccount/my-address.php' ); ?>
			</div>
		</li>
	</ul>
</div>