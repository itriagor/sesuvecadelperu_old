<?php
/**
 * sidebar-none.php
 *
 * The none sidebar.
 */
// Silence is Golden.