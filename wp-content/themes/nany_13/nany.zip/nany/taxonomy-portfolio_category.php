<?php get_header();

/* Columns from Theme Options */
$portfolio_columns = ot_get_option('portfolio_columns');
$hide_filter = ot_get_option('portfolio_cat_filter');
$pagination = ot_get_option('disable_pagination');


/* Category Filter */
    if ($hide_filter) {

        $pf_item_slugs = str_replace(', ', ',', '');
        $pf_item_slugs = rtrim($pf_item_slugs, ',');
        $pf_item_slugs =  explode(",", $pf_item_slugs);

        foreach ($pf_item_slugs as $pf_item_slug) {
          $pf_show_only[] ='.catfilter li a.'. $pf_item_slug;
        }
        $pf_show_only = implode(', ', $pf_show_only);
        echo '<style>.catfilter li a{display:none;} .catfilter li a.all, ' . $pf_show_only . '{display:inline !important;}</style>';
      ?>
      <ul class="catfilter">
        <li class="active"><a href="javascript:void(0)" class="all"><?php _e('All', 'nany'); ?></a></li>
        <?php $terms = get_terms('portfolio_category');
          $count = count($terms);
          $i=0;
          $term_list = '';
          if ($count > 0) {
            foreach ($terms as $term) {
              $i++;
              $term_list .= '<li><a href="javascript:void(0)" class="'. $term->slug .'" title="' . esc_attr($term->name) . '">' . $term->name . '</a></li>';
              if ($count != $i) {
                $term_list .= '';
              } else {
                $term_list .= '';
              }
            }
            echo $term_list;
          }
        ?>
        <div class="clearfix"></div>
      </ul>
    <?php } ?>

	<!-- Portfolio Items -->
    <div id="port-items" class="portfolio-page">
      <div class="port-main-wrap">
        <div class="port-inner-wrap">

		<ul class="nany-portfolio cat-container <?php echo $portfolio_columns; ?>">
			<?php

			while (have_posts()) : the_post();

      $terms = wp_get_post_terms($post->ID, 'portfolio_category');

			if ( (function_exists('has_post_thumbnail')) && (has_post_thumbnail()) ) {
        $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
        $large_image = $large_image[0];

        if ($portfolio_columns === 'portfolio-3-column') {
          $portfolio_img = aq_resize( $large_image, '360', '260', true );
        } elseif ($portfolio_columns === 'portfolio-2-column') {
          $portfolio_img = aq_resize( $large_image, '560', '400', true );
        } else {
          $portfolio_img = aq_resize( $large_image, '255', '240', true );
        }
      } else {
        $large_image = IMAGES .'/dummy/560x400.jpg';

        if ($portfolio_columns === 'portfolio-3-column') {
          $portfolio_img = IMAGES .'/dummy/560x400.jpg';
        } elseif ($portfolio_columns === 'portfolio-2-column') {
          $portfolio_img = IMAGES .'/dummy/560x400.jpg';
        } else {
          $portfolio_img = IMAGES .'/dummy/255x240.jpg';
        }
      }

		  ?>

  			<li id="item-<?php echo $post->ID; ?>" class="portfolio-square" <?php if ($hide_filter) { ?>data-id="id-<?php echo $count; ?>"<?php } ?> data-type="<?php foreach ($terms as $term) { echo $term->slug . ' ';} ?>">

                <div class="port-hover">
                    <div class="hover-text">
                        <?php echo get_the_term_list( $post->ID, 'portfolio_category', '<span class="port-categroy">', ', ', '</span>' ); ?>
                        <div class="categroy-sep"></div>
                        <span class="port-likes"><?php echo zilla_likes(); ?> <?php echo __('Likes', 'nany'); ?></span>
                        <span class="port-views"><i class="fa fa-eye"></i> <small><?php echo bawpvc_views_sc( $content = null ); ?></small> <?php echo __('Views', 'nany'); ?></span>
                    </div>
                </div>
                <a href="<?php echo esc_url(get_permalink()); ?>"><img src="<?php echo esc_attr($portfolio_img); ?>" alt="<?php echo esc_attr(get_the_title()); ?>" /></a>
                <div class="port-title">
                  <a href="<?php echo esc_url($large_image); ?>" class="port-nub woo-popup-link">
                    <i class="fa fa-plus"></i>
                    <img src="<?php echo esc_attr(ot_get_option('title_nub')); ?>" alt="">
                  </a>
                  <a href="<?php echo esc_url(get_permalink()); ?>"><?php echo get_the_title(); ?></a>
                </div>

            </li>

			<?php if ($hide_filter) { $count++; } ?>
			<?php endwhile; ?>
			<div class="clearfix"></div>
      <?php wp_reset_query(); ?>
		</ul>
		<div class="clearfix"></div>

		</div>
	</div>
</div>

<?php if(!$pagination) { ?>
<div class="post-navigation">
	<?php
    if ( function_exists('wp_pagenavi')) {
      wp_pagenavi();
      wp_reset_postdata();  // avoid errors further down the page
    }
  ?>
</div>
<?php } ?>

<div class="clearfix"></div>
<?php get_footer(); ?>