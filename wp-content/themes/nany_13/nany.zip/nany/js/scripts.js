jQuery(document).ready(function($){
var is_mobile=false;
"use strict";


function detectmob() {
 if( navigator.userAgent.match(/Android/i)
 || navigator.userAgent.match(/webOS/i)
 || navigator.userAgent.match(/iPhone/i)
 || navigator.userAgent.match(/iPad/i)
 || navigator.userAgent.match(/iPod/i)
 || navigator.userAgent.match(/BlackBerry/i)
 || navigator.userAgent.match(/Windows Phone/i)
 ){

    return true;
  }
 else {
    return false;
  }
}
if(detectmob()){
    is_mobile=true;
}else
{
    is_mobile=false;
}

if(!is_mobile)
{
    try{

        if(!Modernizr.touch){

            try{
                jQuery.stellar();
            }catch(ex)
            {

            }

        }

    }catch(e)
    {
        console.log(e);
    }
}


//Add body class
function add_body_class()
{
    if(detectmob()){
        $('body').addClass('is_mobile');
    }
}
add_body_class();

/*
  Search Bar
*/
$('.search-toggle').click(function () {
  $(this).toggleClass('search-active');
  $('.search-toggle i.fa').toggleClass('fa-close');
  $('#header-search').fadeToggle('slow');
});

/* ==============================================
Sticky Navbar
=============================================== */
$(document).ready(function(){
  "use strict";

  $(".sticky-nav").sticky({topSpacing:0});
});

/* ==============================================
    Header on Scroll - Appear
=============================================== */
(function ($) {
  $(document).ready(function(){

    "use strict";

  // hide .navbar first
      $(".header-top").hide();
      // fade in .navbar
      $(function () {
        $(window).scroll(function () {
                  // set distance user needs to scroll before we fadeIn navbar
        if ($(this).scrollTop() > 50) {
          $('.header-top').fadeIn();
        } else {
          $('.header-top').fadeOut();
        }
      });
    });
  });
}(jQuery));


/* ==============================================
  Hover on dropdown only in >= 768px devices
=============================================== */
function close_nav_dropdown() {

  "use strict";

  if ($(window).width() >= 768) {
    $('.navbar .dropdown').hover(function() {
      $(this).find('.dropdown-menu').first().stop(true, true).slideDown(150);
    }, function() {
      $(this).find('.dropdown-menu').first().stop(true, true).slideUp(105);
    });
  }
}
close_nav_dropdown();
$(window).resize(close_nav_dropdown);

/* ==============================================
WOW plugin triggers animation.css on scroll
Disable this feature on mobile
=============================================== */
if(!is_mobile)
{
    try{

        var wow = new WOW(
          {
            boxClass:     'wow',      // animated element css class (default is wow)
            animateClass: 'animated', // animation css class (default is animated)
            offset:       150,          // distance to the element when triggering the animation (default is 0)
            mobile:       false        // trigger animations on mobile devices (true is default)
          }
        );
        wow.init();

    }catch(e){
        console.log(e);
    }

}

/* ==============================================
Bootstrap Alert, Tabs
=============================================== */
jQuery(document).ready(function($) {
  "use strict";

    var active = true;
    $('#collapse-init').click(function () {
        if (active) {
            active = false;
            $('.panel-collapse').collapse('show');
            $('.panel-title').attr('data-toggle', '');
            $(this).text('Close All');
        } else {
            active = true;
            $('.panel-collapse').collapse('hide');
            $('.panel-title').attr('data-toggle', 'collapse');
            $(this).text('Open All');
        }
    });
    $('#accordion').on('show.bs.collapse', function () {
        if (active) $('#accordion .in').collapse('hide');
    });
});

jQuery(document).ready(function($) {
  $('#myTab a').click(function (e) {
    "use strict";

    e.preventDefault();
    $(this).tab('show');
  });
});

/* ==============================================
mb.YTPlayer
=============================================== */
if(!is_mobile)
{

    $(function(){
        try{

            // $(".player").tubular();
            $(".player").mb_YTPlayer();
        }catch(e)
        {
            console.log(e);
        }

    });

}


if(!is_mobile)
{
    /* ==============================================
    Skill Bars
    =============================================== */
    $('.skillbar').waypoint(function() {
       jQuery('.skillbar').each(function(){
            jQuery(this).find('.skillbar-bar').animate({
                width:jQuery(this).attr('data-percent')
            },2000);
        });

        }, { offset: '100%'
    });
} else {
    jQuery('.skillbar').each(function(){
            jQuery(this).find('.skillbar-bar').animate({
                width:jQuery(this).attr('data-percent')
            },2000);
    });
}

/* ==============================================
Fit Vids
=============================================== */
jQuery(document).ready(function($) {
  "use strict";
    // Target your .container, .wrapper, .post, etc.
    $("#fit-videos").fitVids();
    $(".fit-videos").fitVids();
  });

/* ==============================================
Parallax
=============================================== */
    try
    {
        if(is_mobile==false)
        {
            $(window).stellar({
                horizontalScrolling: false
            });
        }

    }catch(e)
    {
        console.log(e);
    }

/* ==============================================
    Counter Up
=============================================== */
jQuery(document).ready(function($) {
  "use strict";

  var counter_class = $('body').find('.counter-wrap');
  if(counter_class.length) {
      $('.counter-letters').counterUp({
          delay: 10,
          time: 800
      });
  }


});
/* ==============================================
    Smooth scrolling to anchor for home buttons
=============================================== */
jQuery(document).ready(function($) {

  "use strict";

    $('.nany-btn a,.move a').bind('click', function(event) {
        var $anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: $($anchor.attr('href')).offset().top - 94
        }, 1500, 'easeOutExpo');
        event.preventDefault();
    });

    $('.scroll-down').bind('click', function(event) {
        var $anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: $($anchor.attr('href')).offset().top - 94
        }, 1500, 'easeOutExpo');
        event.preventDefault();
    });
});
jQuery(document).ready(function($) {

  "use strict";

    $('.smooth-scroll-btn a,.move a').bind('click', function(event) {
        var $anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: $($anchor.attr('href')).offset().top - 94
        }, 1500, 'easeOutExpo');
        event.preventDefault();
    });
});

/* ==============================================
Smooth Scroll To Anchor
=============================================== */
//jQuery for page scrolling feature - requires jQuery Easing plugin
jQuery(document).ready(function($) {

  "use strict";

    $('#main-nav a').bind('click', function(event) {
        var $anchor = $(this);
        $('html, body').stop().animate({
            scrollTop: $($anchor.attr('href')).offset().top - 94
        }, 1500, 'easeOutExpo');
        event.preventDefault();
    });
});

/* ==============================================
    Active Menu Item on Page Scroll
=============================================== */
var sections = $('section');
  nav = $('nav');
  nav_height = nav.outerHeight();

$(window).on('scroll', function () {

  "use strict";

  var cur_pos = $(this).scrollTop();

  sections.each(function() {
    var top = $(this).offset().top - nav_height,
        bottom = top + $(this).outerHeight();

    if (cur_pos >= top && cur_pos <= bottom) {
      nav.find('a').removeClass('current');
      sections.removeClass('current');

      $(this).addClass('current');
      nav.find('a[href="#'+$(this).attr('id')+'"]').addClass('current');
    }
  });
});

/*****  All Owl Slider Starts *****/

/* ==============================================
  Testimonial Slider
=============================================== */
jQuery(document).ready(function($) {

  $('#testi-slider').owlCarousel({

    pagination : true,
    paginationNumbers: false,
    singleItem : true,
    autoPlay : 5000,
    lazyEffect : 'fade',

  });

});

/* ==============================================
  Client Logo Slider
=============================================== */
jQuery(document).ready(function($) {

  $("#client-logo").owlCarousel({

    navigation : true,
    autoPlay : 5000,
    slideSpeed : 800,
    paginationSpeed : 800,
    singleItem : false,
    items : 4,
    autoHeight : true,
    navigation : true,
    pagination : false,
    navigationText : ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],

  });

});


/* ==============================================
    Blog Gallery Slider
=============================================== */
jQuery(document).ready(function($) {

  $("#blog-slider").owlCarousel({

    items : 1,
    itemsCustom : false,
    itemsDesktop : [1199,1],
    itemsDesktopSmall : [980,1],
    itemsTablet: [768,1],
    itemsTabletSmall: false,
    itemsMobile : [479,1],
    singleItem : true,
    itemsScaleUp : false,

    navigation : true,
    autoPlay : 5000,
    slideSpeed : 800,
    paginationSpeed : 800,
    singleItem : false,
    autoHeight : true,
    navigation : true,
    pagination : true,
    navigationText : ["<i class='fa fa-angle-left'></i>", "<i class='fa fa-angle-right'></i>"],

  });

});

/* ==============================================
  Simple Slider
=============================================== */
jQuery(document).ready(function($) {

  $("#simple-slider-1, #simple-slider-2, #simple-slider-3, #simple-slider-4").owlCarousel({

    navigation : true,
    autoPlay : 5000,
    slideSpeed : 800,
    paginationSpeed : 800,
    autoHeight : false,
    navigation : false,
    pagination : true,
    stopOnHover : true,
    items : 1,
    itemsDesktop : [1199,1],
    itemsDesktopSmall : [992,1],
    itemsTablet: [768,1],
    itemsTabletSmall: false,
    itemsMobile : [479,1],
    singleItem : true,
    itemsScaleUp : true,

  });

});

/* ==============================================
  Magnicfic Popup for App Screen Slider
=============================================== */

jQuery(document).ready(function($) {
  $('.woo-popup-link').magnificPopup({
    type: 'image'
    // other options
  });

  $('.gallery').each(function() { // the containers for all your galleries
      $(this).magnificPopup({
          delegate: 'a', // the selector for gallery item
          type: 'image',
          gallery: {
            enabled:true
          }
      });
  });

});

jQuery(document).ready(function($) {

  "use strict";

  $('.zoom-gallery').magnificPopup({
    delegate: 'a',
    type: 'image',
    closeOnContentClick: false,
    closeBtnInside: false,
    mainClass: 'mfp-with-zoom mfp-img-mobile',
    image: {
      verticalFit: true,
      titleSrc: function(item) {
        return item.el.attr('title');
      }
    },
    gallery: {
      enabled: true
    },
    zoom: {
      enabled: true,
      duration: 300, // don't foget to change the duration also in CSS
      opener: function(element) {
        return element.find('img');
      }
    }

  });

  $('.grid-of-images').magnificPopup({
    delegate: 'a',
    type: 'image',
    closeOnContentClick: false,
    closeBtnInside: false,
    mainClass: 'mfp-with-zoom mfp-img-mobile',
    image: {
      verticalFit: true,
      titleSrc: function(item) {
        return item.el.attr('title');
      }
    },
    gallery: {
      enabled: false
    },
    zoom: {
      enabled: true,
      duration: 300, // don't foget to change the duration also in CSS
      opener: function(element) {
        return element.find('img');
      }
    }

  });

  $('.gallery-item').magnificPopup({
    delegate: 'a',
    type: 'image',
    closeOnContentClick: false,
    closeBtnInside: false,
    mainClass: 'mfp-with-zoom mfp-img-mobile',
    image: {
      verticalFit: true,
      titleSrc: function(item) {
        return item.el.attr('title');
      }
    },
    gallery: {
      enabled: true
    },
    zoom: {
      enabled: true,
      duration: 300, // don't foget to change the duration also in CSS
      opener: function(element) {
        return element.find('img');
      }
    }
  });


});


/* ==============================================
  Alert Notification
=============================================== */
jQuery(document).ready(function($) {

  /* Alert Notification */
  $(".alert .toggle-alert").click(function(){
     $(this).closest(".alert").slideUp();
     return false;
  });

});

/* ==============================================
  Ajax team popup
=============================================== */
jQuery(document).ready(function($) {
  $('.popup-with-zoom-anim').magnificPopup({
    type: 'inline',

    fixedContentPos: false,
    fixedBgPos: true,

    overflowY: 'auto',

    closeBtnInside: true,
    preloader: false,

    midClick: true,
    removalDelay: 300,
    mainClass: 'team-zoom-in'
  });

  $('.popup-with-move-anim').magnificPopup({
    type: 'inline',

    fixedContentPos: false,
    fixedBgPos: true,

    overflowY: 'auto',

    closeBtnInside: true,
    preloader: false,

    midClick: true,
    removalDelay: 300,
    mainClass: 'team-slide-bottom'
  });
});

/* ==============================================
   Contact Form Validation
=============================================== */
jQuery(document).ready(function($) {
  $.fn.wpcf7NotValidTip = function(message) {
    return this.each(function() {
      var into = $(this);

      $theParent = into.parent("span");
      $parentInp = $theParent.parent("input");

      into.find(':input').css('border-color', '#ff0000');

      into.find(':input').mouseover(function() {
        into.find(':input').css('border-color','#E1E1E1');
      });
      into.find(':input').focus(function() {
        into.find(':input').css('border-color','#E1E1E1');
      });
    });
  };
});
});

/* ==============================================
   Map Show & Hide
=============================================== */
jQuery(document).ready(function($) {
  $(function(){
      $(".viewnow").click(function(){
        $(".map-show").slideToggle();
      });
      $('.viewnow').click(function(){
            $('.viewnow i.fa').toggleClass('fa-chevron-down fa-chevron-up');
      });
  });
});

/* ==============================================
   Tabs
=============================================== */
jQuery(document).ready(function($) {
  $(function() {
      $('.proc-tabs a').click(function(){
          switch_tabs($(this));
      });
      switch_tabs($('.defaulttab'));
  });
  $('.proc-tabs li:first-child a').addClass('defaulttab');
  $('.proc-tabs li:first-child a > div').addClass('activ-process');
  function switch_tabs(obj) {
      $('.tab-content').fadeOut();
      var id = obj.attr("title");
      $('#'+id).fadeIn();
  }
  $(function() {
      $('.processlist ul li .tab-icon').on('click', function(e){
          e.preventDefault();
          $('.processlist ul li .tab-icon.activ-process').removeClass('activ-process');
          $(this).addClass('activ-process');
      });
  });
});

/* ==============================================
   Tooltip
=============================================== */
jQuery(document).ready(function($) {
  $("[data-toggle='tooltip']").tooltip();
  "use strict";

    $(".alert").alert();
});