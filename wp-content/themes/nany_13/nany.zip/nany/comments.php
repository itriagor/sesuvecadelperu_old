<?php
/**
 * comments.php
 *
 * The template for displaying comments.
 */
?>

<?php
    // Prevent the direct loading of comments.php.
    if ( ! empty( $_SERVER['SCRIPT-FILENAME'] ) && basename( $_SERVER['SCRIPT-FILENAME'] ) == 'comments.php' ) {
        die( __( 'You cannot access this page directly.', 'nany' ) );
    }
?>

<?php
    // If the post is password protected,One comment display info text and return.
    if ( post_password_required() ) : ?>
        <p>
            <?php
                _e( 'This post is password protected. Enter the password to view the comments.', 'nany' );

                return;
            ?>
        </p>
    <?php endif; ?>

<!-- Comments Area -->
<div class="comment-wrapper" id="comments">
    <?php if ( have_comments() ) : ?>
        <h3>
            <?php
                printf( _nx( 'Comments (%1$s)', 'Comments (%1$s)', get_comments_number(), 'Comment title', 'nany' ), number_format_i18n( get_comments_number() ) );
            ?>
        </h3>

        <ul class="comments">
            <?php wp_list_comments('type=comment&callback=nany_comment_modification'); ?>
        </ul>

        <?php
            // If the comments are paginated, display the controls.
            if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
        ?>
        <nav class="comment-nav" role="navigation">
            <p class="comment-nav-prev">
                <?php previous_comments_link( __( '&larr; Older Comments', 'nany' ) ); ?>
            </p>

            <p class="comment-nav-next">
                <?php next_comments_link( __( 'Newer Comments &rarr;', 'nany' ) ); ?>
            </p>
        </nav> <!-- end comment-nav -->
        <?php endif; ?>

        <?php
            // If the comments are closed, display an info text.
            if ( ! comments_open() && get_comments_number() ) :
        ?>
            <p class="no-comments">
                <?php _e( 'Comments are closed.', 'nany' ); ?>
            </p>
        <?php endif; ?>
    <?php endif; ?>

    <?php
    /* ==============================================
         Comment Forms
    =============================================== */
    if ( comments_open() ) : ?>
        <?php

        $fields = array(
            'author' => '<div class="col-lg-4 form-author-name"><input type="text" id="author" name="author" value="' .
        esc_attr( $commenter['comment_author'] ) . '" tabindex="1" placeholder="' . __( 'Name', 'nany' ) . '" /></div>',
            'email' => '<div class="email-comment col-lg-4 form-author-email"><input type="text" id="email" name="email" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" tabindex="2" placeholder="' . __( 'Email', 'nany' ) . '"  /></div>',
            'URL' => '<div class="col-lg-4 form-author-url"><input type="text" id="url" name="url" value="' . esc_attr( $commenter['comment_author_url'] ) . '" tabindex="3" placeholder="' . __( 'Website', 'nany' ) . '" /></div>'
        );

        $defaults = array(
            'comment_notes_before' => '',
            'comment_notes_after'  => '',
            'fields' => apply_filters( 'comment_form_default_fields', $fields),
            'id_form'              => 'commentform',
            'id_submit'            => 'submit',
            'title_reply'          => '<span class="reply-title-wrapper">'. __( 'Add comment', 'nany' ) .'</span>',
            'title_reply_to'       => '<span class="reply-title-wrapper">'. __( 'Add comment to %s', 'nany' ) .'</span>',
            'cancel_reply_link'    => '<i class="fa fa-times-circle"></i>'. __( '', 'nany' ),
            'label_submit'         => __( 'Add Comment', 'nany' ),
            'comment_field' => '<div class="col-lg-12"><textarea id="comment" name="comment" tabindex="6" rows="6" cols="45" placeholder="' . __( 'Your Comments', 'nany' ) . '"></textarea></div>'
        );

        comment_form($defaults);
        ?>
<?php endif; ?>
</div> <!-- end comments-area -->