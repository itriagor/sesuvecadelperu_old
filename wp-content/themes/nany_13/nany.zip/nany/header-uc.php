<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<meta name="keywords" content="<?php echo ot_get_option('nany_meta_keywords'); ?>" />
<meta name="description" content="<?php echo ot_get_option('nany_meta_descriptions'); ?>" />
<?php
  if(!ot_get_option('nany_site_layout')) {
    ?><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" /><?php
  }
?>
<link rel="alternate" type="application/rss+xml" title="<?php esc_attr(bloginfo('name')); ?> RSS Feed" href="<?php esc_url(bloginfo('rss2_url')); ?>" />


  <?php if (ot_get_option('nany_favicon')){
    echo '<link rel="shortcut icon" href="'. esc_url(ot_get_option('nany_favicon')) .'" />';
  } else {
    echo '<link rel="shortcut icon" href="'. get_template_directory_uri() .'/images/fav.png" />';
  }

  if (ot_get_option('ipad_retina_icon')){
    echo '<link rel="apple-touch-icon" sizes="144x144" href="'. esc_url(ot_get_option('ipad_retina_icon')) .'" >';
  }

  if (ot_get_option('iphone_retina_icon')){
    echo '<link rel="apple-touch-icon" sizes="114x114" href="'. esc_url(ot_get_option('iphone_retina_icon')) .'" >';
  }

  if (ot_get_option('ipad_icon')){
    echo '<link rel="apple-touch-icon" sizes="72x72" href="'. esc_url(ot_get_option('ipad_icon')) .'" >';
  }

  if (ot_get_option('iphone_icon')){
    echo '<link rel="apple-touch-icon" href="'. esc_url(ot_get_option('iphone_icon')) .'" >';
  } ?>

    <title><?php wp_title('', true, 'left'); ?></title>
    <?php echo ot_get_option('analytics_code'); ?>
    <?php wp_head(); ?>
</head>
<?php
$uc_bg_image = get_post_meta( $post->ID, "uc_bg_image", true );
if($uc_bg_image) {
    $uc_bg_image = 'style="background-image:url('. $uc_bg_image .');"';
} else {
    $uc_bg_image = '';
}
?>
<body <?php body_class('under-construction'); ?> <?php echo $uc_bg_image; ?>>

    <!-- Site Wrapper Starts -->
    <div id="uc-wrapper">
        <!-- Single Blog Post -->
        <div class="container section">
            <div class="row">