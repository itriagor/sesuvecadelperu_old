<?php
$output = $el_class = $css = '';
extract(shortcode_atts(array(
    'el_class'        => '',
    'select_pre_nubs'        => '',
    'row_nub_image'        => '',

    /* Custom Row Styling */
    'row_id'   => '',
    'center_row_content'   => '',
    'custom_row_visibility'   => '',
    'row_text_color'   => '',
    'row_bg_color'   => '',
    'row_bg_image_style'   => '',
    'row_bg_image_parallax'   => '',
    'row_bg_background_parallax'   => '',
    'row_parallax_ratio'   => '0.5',
    'row_bg_image'   => '',
    'enable_background_overlay'   => '',
    'position_relative_parallax'   => '',
    'position_relative'   => '',
    'position_relative_video'   => '',

    /* Video */
    'enable_video_background'   => '',
    'video_url'   => '',
    'need_controls'   => '',
    'disable_video_loop'   => '',
    'disable_auto_play'   => '',
    'disable_audio_mute'   => '',
    'start_time'   => '',
    'video_quality'   => '',

    /* Border */
    'border_style'   => '',
    'border_color'   => '',
    'border_width'   => '',
    'row_margin_top'   => '',
    'row_margin_bottom'   => '',
    'row_margin_left'   => '',
    'row_margin_right'   => '',
    'row_padding_top'   => '',
    'row_padding_bottom'   => '',
    'row_padding_left'   => '',
    'row_padding_right'   => '',
    'center_row_content_before'   => '',
    'center_row_content_after'   => '',

    'col_right_left_space'   => '',

    'css' => ''
), $atts));

// wp_enqueue_style( 'js_composer_front' );
wp_enqueue_script( 'wpb_composer_front_js' );
// wp_enqueue_style('js_composer_custom_css');

if($row_bg_image) {
  $image_url = wp_get_attachment_url( $row_bg_image );
  $row_bg_image = "background-image:url('$image_url');";
}
if($row_id) {
  $video_row_id = $row_id;
} else {
  $video_row_id = '';
}
if ($video_row_id) {
  $position_relative_video = 'style="position:relative;"';
} else {
  $position_relative_video = '';
}
if($row_id) {
  $row_id = 'id="'. $row_id .'"';
}

/* Design */
if($custom_row_visibility) {
  $custom_row_visibility = ' ' . $custom_row_visibility .'';
}
if($row_bg_color) {
  $row_bg_color = 'background-color:'. $row_bg_color .';';
}
if($row_text_color) {
  $row_text_color = 'color:'. $row_text_color .';';
}
if($row_bg_image_style === 'fixed') {
  $row_bg_image_style = 'background-attachment:fixed;';
} elseif($row_bg_image_style === 'repeat') {
  $row_bg_image_style = 'background-repeat:repeat;';
} elseif($row_bg_image_style === 'cover') {
  $row_bg_image_style = '-webkit-background-size: cover;-moz-background-size: cover;-o-background-size: cover;background-size: cover;';
}
if($row_bg_background_parallax) {
  // Stellar Script
  wp_enqueue_script('stellar-scripts', SCRIPTS . '/jquery.stellar.js', array('jquery'), '', true);
  $row_bg_background_parallax = 'data-stellar-background-ratio="'. $row_parallax_ratio .'"';
}
if($enable_background_overlay) {
  $enable_background_overlay = '<div class="parallax-overlay"></div>';
  $position_relative_parallax = 'position:relative;';
}

/* Video Background */
if($need_controls === 'yes') {
  $need_controls = 'true';
} else {
  $need_controls = 'false';
}
if($disable_auto_play === 'yes') {
  $disable_auto_play = 'false';
} else {
  $disable_auto_play = 'true';
}
if($disable_video_loop === 'yes') {
  $disable_video_loop = 'false';
} else {
  $disable_video_loop = 'true';
}
if($disable_audio_mute === 'yes') {
  $disable_audio_mute = 'false';
} else {
  $disable_audio_mute = 'true';
}
if($start_time) {
  $start_time = $start_time;
} else {
  $start_time = '0';
}
if($video_quality) {
  $video_quality = $video_quality;
} else {
  $video_quality = 'default';
}
if($enable_video_background) {
  $enable_video_background = '<a class="player" data-property="{videoURL:\''. $video_url .'\',containment:\'#'. $video_row_id .'\', showControls:'. $need_controls .', autoPlay:'. $disable_auto_play .', loop:'. $disable_video_loop .', mute:'. $disable_audio_mute .', startAt:'. $start_time .', opacity:1, quality:\''. $video_quality .'\'}"></a>';
  // YTPlayer Script
  wp_enqueue_script('player-scripts', SCRIPTS . '/jquery.mb.YTPlayer.js', array('jquery'), '', true);
}

/* Border */
if($border_width) {
  $border_width = 'border-style:'. $border_style .';border-width:'. $border_width .';border-color:'. $border_color .';';
}

/* Margins */
if($row_margin_top) {
  $row_margin_top = 'margin-top:'. $row_margin_top .';';
}
if($row_margin_bottom) {
  $row_margin_bottom = 'margin-bottom:'. $row_margin_bottom .';';
}
if($row_margin_left) {
  $row_margin_left = 'margin-left:'. $row_margin_left .';';
}
if($row_margin_right) {
  $row_margin_right = 'margin-right:'. $row_margin_right .';';
}

/* Paddings */
if($row_padding_top) {
  $row_padding_top = 'padding-top:'. $row_padding_top .';';
}
if($row_padding_bottom) {
  $row_padding_bottom = 'padding-bottom:'. $row_padding_bottom .';';
}
if($row_padding_left) {
  $row_padding_left = 'padding-left:'. $row_padding_left .';';
}
if($row_padding_right) {
  $row_padding_right = 'padding-right:'. $row_padding_right .';';
}

/* Center Contents */
if($center_row_content === 'yes') {
  $center_row_content_before = '<div class="container"><div class="row">';
  $center_row_content_after = '</div></div>';
}

/* Columns Hide Paddings Spaces */
if($col_right_left_space === 'yes') {
  $col_right_left_space = ' column-zero-space';
} else {
  $col_right_left_space = ' column-have-space';
}
if ($select_pre_nubs) {
  $row_nub_image = '<div class="row-nub"><img src="' . get_template_directory_uri() .'/images/nubs/nany-'. $select_pre_nubs .'.png" alt="nany-nub" /></div>';
  $position_relative = 'position:relative;';
} elseif ( $select_pre_nubs === 'custom' ) {
  $image_url = wp_get_attachment_url( $row_nub_image );
  $row_nub_image = '<div class="row-nub"><img src="'. esc_attr($image_url) .'" alt="nany-nub" /></div>';
  $position_relative = 'position:relative;';
} else {
  $row_nub_image = '';
  $position_relative = '';
}

$el_class = $this->getExtraClass($el_class);

$css_class = apply_filters( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, 'vc_row wpb_row '. ( $this->settings('base')==='vc_row_inner' ? 'vc_inner ' : '' ) . get_row_css_class() . $el_class . vc_shortcode_custom_css_class( $css, ' ' ), $this->settings['base'], $atts );

$output .= '<section '. $row_id .' '. $position_relative_video .'><div class="'. $css_class . $custom_row_visibility . $col_right_left_space .'" '. $row_bg_background_parallax .' style="'. $row_bg_image . $row_bg_color . $row_text_color . $row_bg_image_style . $position_relative . $position_relative_parallax . $border_width . $row_margin_top . $row_margin_bottom . $row_margin_left . $row_margin_right . $row_padding_top . $row_padding_bottom . $row_padding_left . $row_padding_right .'">'. $row_nub_image . $enable_background_overlay . $enable_video_background . '';

$output .= $center_row_content_before;

$output .= wpb_js_remove_wpautop($content);

$output .= $center_row_content_after;

$output .= '</div></section>'.$this->endBlockComment('row');

echo $output;