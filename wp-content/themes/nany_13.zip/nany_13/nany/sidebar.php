<?php
/**
 * sidebar.php
 *
 * The primary sidebar.
 */

$full_width = ot_get_option('enable_fullwidth');
if(is_page()) {
  $page_full_width = get_post_meta($post->ID, 'enable_fullwidth', true);
} else {
  $page_full_width = $full_width;
}

$sidebar_select = get_post_meta( $post->ID, "sidebar_select", true );

if(is_page()) {
  if(!$full_width && !$page_full_width) { ?>
  	<div class="col-lg-4 col-md-4 col-sm-12 sidebar" role="complementary">
  		<?php
        if ($sidebar_select) {
          dynamic_sidebar($sidebar_select);
        } else {
          dynamic_sidebar( 'page-widget' );
        }
      ?>
  	</div> <!-- end sidebar -->
  <?php }
} else {
  if(!$full_width && !$page_full_width) { ?>
  <div class="col-lg-4 col-md-4 col-sm-12 sidebar" role="complementary">
    <?php
      if ($sidebar_select) {
        dynamic_sidebar($sidebar_select);
      } else {
        dynamic_sidebar( 'sidebar-1' );
      }
    ?>
  </div> <!-- end sidebar -->
<?php } } ?>