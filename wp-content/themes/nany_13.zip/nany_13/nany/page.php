<?php
/**
 * page.php
 *
 * The template for displaying all pages.
 */
?>

<?php get_header(); ?>

	<div class="main-content col-md-8" role="main">
		<?php while( have_posts() ) : the_post(); ?>
			<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

				<!-- Article content -->
				<div class="entry-content">
					<?php the_content(); ?>

        	<div class="pagelink"><?php wp_link_pages(); ?></div>
				</div> <!-- end entry-content -->

			</article>

			<?php
			if(ot_get_option('nany_page_comments')) {
				comments_template();
			}
			?>
		<?php endwhile; ?>
	</div> <!-- end main-content -->

<?php get_sidebar(); ?>

<?php get_footer(); ?>