<?php
/**
 * The template for displaying search forms
 */

?>
<div class="searchform-wrapper">
  <form method="get" class="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
    <input placeholder="<?php echo __('Search...', 'nany'); ?>" type="text" value="<?php echo esc_attr(get_search_query()); ?>" name="s" class="s" />
  </form>
</div>