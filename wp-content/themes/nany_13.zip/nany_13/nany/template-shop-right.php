<?php
/*
Template Name: Shop Right Sidebar
*/
?>

<?php get_header(); ?>

<div class="main-content col-md-8" role="main">
	<?php while( have_posts() ) : the_post(); ?>
	<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

		<!-- Article content -->
		<div class="entry-content">
			<?php the_content(); ?>

	<div class="pagelink"><?php wp_link_pages(); ?></div>
		</div> <!-- end entry-content -->

	</article>
	<?php endwhile; ?>


<?php
// Strings to get values
$items = get_post_meta($post->ID,'woo_items_page', true);
$order = get_post_meta($post->ID,'woo_product_order', true);
$orderby = get_post_meta($post->ID,'woo_port_orderby', true);

if ($items) { $items = $items; } else { $items = 8; }

// Category
$recent_category = get_post_meta($post->ID,'woo_category', true);

// Columns
$woocommerce_loop['columns'] = 3;

// Pagination Issue Fixed
global $paged;
if( get_query_var( 'paged' ) )
	$my_page = get_query_var( 'paged' );
else {
	if( get_query_var( 'page' ) )
		$my_page = get_query_var( 'page' );
	else
		$my_page = 1;
	set_query_var( 'paged', $my_page );
	$paged = $my_page;
}

// args
if($recent_category) {

	$recent_category = explode(",", $recent_category);
	$recent_category = array_map('trim', $recent_category);

	$args = array(
		'post_type'				=> 'product',
		'post_status' 			=> 'publish',
		'ignore_sticky_posts'	=> 1,
		'orderby' 				=> esc_attr($orderby),
		'order' 				=> esc_attr($order),
		'posts_per_page'		=> (int)$items,
		'paged'					=> esc_attr($my_page),
		'tax_query' 			=> array(
			array(
				'taxonomy' 		=> 'product_cat',
				'terms' 		=> esc_attr($recent_category),
				'field' 		=> 'slug',
				'operator' 		=> 'IN'
			)
		)
	);
} else {
	$args = array(
		'post_type'				=> 'product',
		'post_status' 			=> 'publish',
		'ignore_sticky_posts'	=> 1,
		'orderby' 				=> esc_attr($orderby),
		'order' 				=> esc_attr($order),
		'posts_per_page'		=> (int)$items,
		'paged'					=> esc_attr($my_page),
	);
}

$wp_query = new WP_Query( $args );

?>

	<div class="woocommerce woocommerce-page" role="main">

		<div class="entry-content product-col-3">

			<ul class="products">

				<?php if ( $wp_query->have_posts() ) while ( $wp_query->have_posts() ) : $wp_query->the_post();
					get_template_part( 'woocommerce/content', 'product' );
				endwhile; ?>

			</ul>

			<div class="post-navigation">
	            <?php
					if ( function_exists('wp_pagenavi')) {
						wp_pagenavi(array( 'query' => $wp_query ) );
						wp_reset_postdata();	// avoid errors further down the page
					}
				?>
	        </div>

		</div>

	</div> <!-- end main-content -->

</div>

<?php get_sidebar('shop'); ?>

<?php get_footer(); ?>