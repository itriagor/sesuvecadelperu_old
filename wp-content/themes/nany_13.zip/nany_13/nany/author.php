<?php
/**
 * author.php
 *
 * The template for displaying author archive pages.
 */

$full_width = ot_get_option('enable_fullwidth');
$sidebar_position = ot_get_option('sidebar_position');

if(!$full_width) {
	$full_width = 'col-lg-8 col-md-8 col-sm-12';
} else {
	$full_width = 'col-lg-12';
}
 ?>

<?php get_header(); ?>

<?php if($full_width && $sidebar_position === 'left') { get_sidebar(); } ?>

	<div class="main-content <?php echo $full_width; ?>" role="main">
		<?php if ( have_posts() ) : the_post(); ?>
			<header class="page-header">
				<h1>
					<?php printf( __( 'All posts by %s.', 'nany' ), get_the_author() ); ?>
				</h1>

				<?php
					// If the author bio exists, display it.
					if ( get_the_author_meta( 'description' ) ) {
						echo '<p>' . the_author_meta( 'description' ) . '</p>';
					}
				?>

				<?php rewind_posts(); ?>
			</header>

			<?php while( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'content', get_post_format() ); ?>
			<?php endwhile; ?>

			<?php nany_paging_nav(); ?>
		<?php else : ?>
			<?php get_template_part( 'content', 'none' ); ?>
		<?php endif; ?>
	</div> <!-- end main-content -->

<?php if($full_width && $sidebar_position === 'right') { get_sidebar(); } ?>

<?php get_footer(); ?>