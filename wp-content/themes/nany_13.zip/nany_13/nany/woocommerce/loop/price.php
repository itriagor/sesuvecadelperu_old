<?php
/**
 * Loop Price
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     1.6.4
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

global $product;
?>
<div class="product-cus-meta <?php if ( $rating_html = $product->get_rating_html() ) { echo 'has-rating';} else { echo 'not-has-rating'; } ?>"> <!-- Product Custom Metas -->
	<?php if ( $price_html = $product->get_price_html() ) : ?>
		<span class="price"><?php echo $price_html; ?></span>
	<?php endif; ?>