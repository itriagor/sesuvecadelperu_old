<?php
/**
 * content-status.php
 *
 * The default template for displaying content.
 */
?>

<!-- Post Starts -->
<article id="post-<?php the_ID(); ?>" <?php post_class('post-list'); ?>>

	<?php
		$status_content = get_post_meta( $post->ID, "status_content", true );
		if ( !is_single() && !post_password_required() ) {
			echo '<p>' . $status_content . '</p>';
		} elseif ( post_password_required() ) { ?>
			<div class="password-protected"><?php the_content(); ?></div>
		<?php
		}
    ?>

	<div class="post-meta-before">
        <?php
            // Display the meta information
            nany_post_meta_before();
        ?>
    </div>

	<?php

		// If single page, display the title
		// Else, we display the title in a link
		if ( is_single() ) : ?>
			<h2 class="post-title"><?php the_title(); ?></h2>
		<?php else : ?>
			<a href="<?php esc_url(the_permalink()); ?>" rel="bookmark" class="post-title"><?php the_title(); ?></a>
		<?php endif; ?>

		<div class="post-meta-after">
			<?php
				// Display the meta information
				nany_post_meta_after();
			?>
		</div>

	<!-- Article content -->
	<div class="post-content">
     <?php
     if(is_single()) {
				echo $status_content;
        the_content('',FALSE,'');

				?>
        <div class="pagelink"><?php wp_link_pages(); ?></div>
		<?php echo nany_post_social_share(); ?>
        <?php
		}
		if ( !is_single() ) {
        $blog_readmore_btn = ot_get_option('blog_readmore_btn');
        if($blog_readmore_btn) {
          $blog_readmore_btn = $blog_readmore_btn;
        } else {
          $blog_readmore_btn = __( 'Read More', 'nany' );
        }
		?>
		<a href="<?php esc_url(the_permalink()); ?>" class="btn-style-four read-more uppercase"><?php echo $blog_readmore_btn; ?></a>
		<?php } ?>
	</div> <!-- end post-content -->

<?php
	// If we have a single page and the author bio exists, display it
	if ( is_single() ) {
    $hide_author_box = ot_get_option('hide_author_box');
    if(!$hide_author_box) {
?>
	<!-- Author Bio -->
	<div class="hr"></div>
  <div class="author-bio">
		<div class="author-image">
        <?php echo get_avatar( get_the_author_meta( 'ID' ), 100 ); ?>
    </div>
    <div class="author-name"><h3><?php echo get_the_author(); ?></h3></div>
    <?php if(get_the_author_meta( 'description' )) { ?>
    <div class="author-description">
        <p><?php echo the_author_meta( 'description' ); ?></p>
    </div>
    <?php } ?>
	</div> <!-- end author-bio -->
	<div class="hr"></div>

<?php } } ?>

</article>