<?php
/**
 * functions.php
 *
 * The theme's functions and definitions.
 */

/**
 * ----------------------------------------------------------------------------------------
 * 1.0 - Define constants.
 * ----------------------------------------------------------------------------------------
 */
define( 'THEMEROOT', get_template_directory_uri() );
define( 'IMAGES', THEMEROOT . '/images' );
define( 'STYLES', THEMEROOT . '/css' );
define( 'SCRIPTS', THEMEROOT . '/js' );
define( 'FRAMEWORK', get_template_directory() . '/framework' );
define( 'WOO_SHOP', THEMEROOT . '/woocommerce');


/**
 * ----------------------------------------------------------------------------------------
 * 2.0 - Load the framework.
 * ----------------------------------------------------------------------------------------
 */
require_once( FRAMEWORK . '/init.php' );

/* WooCommerce */
include_once(FRAMEWORK . '/plugins/woocommerce/index.php');
include_once(FRAMEWORK . '/plugins/woocommerce/custom-fields.php');

/* Quantity Plus and Minus Icons */
add_action( 'wp_enqueue_scripts', 'wcqi_enqueue_polyfill' );
function wcqi_enqueue_polyfill() {
    wp_enqueue_script( 'wcqi-number-polyfill' );
}

/* Yith Wishlist Browse Wishlist Text */
add_filter( 'yith-wcwl-browse-wishlist-label', 'nany_yith_added_text' );
function nany_yith_added_text() {
	return __( 'Added', 'nany' );
}

/**
 * ----------------------------------------------------------------------------------------
 * 3.0 - Set up the content width value based on the theme's design.
 * ----------------------------------------------------------------------------------------
 */
if ( ! isset( $content_width ) ) {
	$content_width = 800;
}


/**
 * ----------------------------------------------------------------------------------------
 * 4.0 - Set up theme default and register various supported features.
 * ----------------------------------------------------------------------------------------
 */
if ( ! function_exists( 'nany_setup' ) ) {
	function nany_setup() {
		/**
		 * Make the theme available for translation.
		 */
		$lang_dir = get_template_directory() . '/languages';
		load_theme_textdomain( 'nany', $lang_dir );

		/**
		 * Add support for post formats.
		 */
		add_theme_support( 'post-formats',
			array(
				'image',
				'gallery',
				'link',
				'status',
				'quote',
				'video',
				'audio'
			)
		);

		/**
		 * Add support for automatic feed links.
		 */
		add_theme_support( 'automatic-feed-links' );

		/**
		 * Add support for post thumbnails.
		 */
		add_theme_support( 'post-thumbnails' );

		/**
		 * Add support for widgets shortcode.
		 */
		add_filter( 'widget_text', 'do_shortcode');
		add_filter( 'the_excerpt', 'do_shortcode');

		/**
		 * Add support for Breadcrumb Trail.
		 */
		add_theme_support( 'breadcrumb-trail' );

		/**
		 * Register nav menus.
		 */
		register_nav_menus(
			array(
	    		'main-menu' => __( 'Main Menu', 'nany' ),
	    		'one-page' => __( 'One Page Menu', 'nany' ),
				'footer-menu' => __( 'Footer Menu', 'nany' )
			)
		);
	}

	add_action( 'after_setup_theme', 'nany_setup' );
}


/**
 * ----------------------------------------------------------------------------------------
 * 5.0 - Display meta information for a specific post.
 * ----------------------------------------------------------------------------------------
 */
/*
 Before Post Metas - Category
 */
if ( ! function_exists( 'nany_post_meta_before' ) ) {
	function nany_post_meta_before() {

		if ( get_post_type() === 'post' ) {

			$hide_meta = ot_get_option('hide_meta');

			// The categories.
			if(!isset($hide_meta[1])) {
			$category_list = get_the_category_list( '', ', ' );
				if ( $category_list ) {
					echo '<div class="post-category"> ' . $category_list . ' </div>';
				}
			}

		}
	}
}

/*
 After Post Metas - Date & Like
 */

if ( ! function_exists( 'nany_post_meta_after' ) ) {
	function nany_post_meta_after() {

		if ( get_post_type() === 'post' ) {

			$hide_meta = ot_get_option('hide_meta');

			// Get the date.
			if(!isset($hide_meta[0])) {
				echo '<span class="post-date"> ' . get_the_date('d M y') . ' </span>';
			}

			if(!isset($hide_meta[2])) {
				echo '<span class="post-likes"> ' . zilla_likes() . ' </span>';
			}

			// Edit link.
			if ( is_user_logged_in() ) {
				echo '<span class="post-comments">';
				edit_post_link( __( 'Edit', 'nany' ), '<span class="meta-edit">', '</span>' );
				echo '</span>';
			}
		}
	}
}

// Add sticky class in article title to style sticky posts differently
function cpt_sticky_class($classes) {
    if ( is_sticky() ) :
       $classes[] = 'sticky';
        return $classes;
        endif;
        return $classes;
}
add_filter('post_class', 'cpt_sticky_class');

/*
	Social Share
 */
if ( ! function_exists( 'nany_post_social_share' ) ) {
	function nany_post_social_share() {
		global $post;
		$thumb = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'thumbnail_size' );
		$url = $thumb['0'];

		$tag_list = get_the_tag_list( '', ', ' );
		if ( $tag_list ) {
			echo '<span class="post-tag"><i class="fa fa-tag"></i> ' . $tag_list . ' </span>';
		}

		// get the details which have to be shared
		// get the url, title, and description (linkedin will display this)
		$page_url = get_permalink($post->ID );
		$title = $post->post_title;
		$media = $url;
    ?>

    <ul class="social-share">
      <li><a href="http://www.facebook.com/sharer/sharer.php?u=<?php urlencode(the_permalink()); ?>&t=<?php the_title(); ?>" class="ss-facebook"><i class="fa fa-facebook"></i></a></li>
      <li><a href="http://twitter.com/home?status=<?php print(urlencode($title)); ?>+<?php print(urlencode($page_url)); ?>" class="ss-twitter"><i class="fa fa-twitter"></i></a></li>
      <li><a href="http://www.linkedin.com/shareArticle?mini=true&url=<?php print(urlencode($page_url)); ?>&title=<?php print(urlencode($title)); ?>" class="ss-linkedin"><i class="fa fa-linkedin"></i></a></li>
      <li><a href="https://pinterest.com/pin/create/button/?url=<?php print(urlencode($page_url)); ?>&media=<?php echo esc_url($media); ?>&description=<?php print(urlencode($title)); ?>" class="ss-pinterest"><i class="fa fa-pinterest"></i></a></li>
      <li><a href="https://plus.google.com/share?url=<?php print(urlencode($page_url)); ?>" class="ss-google-plus"><i class="fa fa-google-plus"></i></a></li>
    </ul>

	<?php
	}
}

/**
 * ----------------------------------------------------------------------------------------
 * 6.0 - Display navigation to the next/previous set of posts.
 * ----------------------------------------------------------------------------------------
 */
if ( ! function_exists( 'nany_paging_nav' ) ) {
	function nany_paging_nav() {
		global $wp_query;
		$big = 999999999;
		if($wp_query->max_num_pages == '1' ) {
		}else {
			echo "";
		}
		echo paginate_links( array(
			'base' => str_replace( $big, '%#%', get_pagenum_link( $big ) ),
			'format' => '?paged=%#%',
			'prev_text' => __( '<i class="fa fa-chevron-left"></i>', 'nany' ),
    	'next_text' => __( '<i class="fa fa-chevron-right"></i>', 'nany' ),
			'current' => max( 1, get_query_var('paged') ),
			'total' => $wp_query->max_num_pages,
			'type' => 'list'
		));
		if($wp_query->max_num_pages == '1' ) {
		}else {
			echo "";
		}
	}
}

/**
 * ----------------------------------------------------------------------------------------
 * 7.0 - Register the widget areas.
 * ----------------------------------------------------------------------------------------
 */
if ( ! function_exists( 'nany_widget_init' ) ) {
	function nany_widget_init() {
		if ( function_exists( 'register_sidebar' ) ) {
			register_sidebar(
				array(
					'name' => __( 'Default Widget', 'nany' ),
					'id' => 'sidebar-1',
					'description' => __( 'Appears on posts.', 'nany' ),
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget' => '</div> <!-- end widget -->',
					'before_title' => '<h3 class="widget-title">',
					'after_title' => '</h3><div class="title-bar"></div>',
				)
			);

			register_sidebar(
				array(
					'name' => __( 'Page Widget', 'nany' ),
					'id' => 'page-widget',
					'description' => __( 'Appears on pages.', 'nany' ),
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget' => '</div> <!-- end widget -->',
					'before_title' => '<h3 class="widget-title">',
					'after_title' => '</h3><div class="title-bar"></div>',
				)
			);

			register_sidebar(
				array(
					'name' => __( 'Footer One', 'nany' ),
					'id' => 'footer-one',
					'description' => __( 'Appears on the footer.', 'nany' ),
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget' => '</div> <!-- end widget -->',
					'before_title' => '<h2 class="footer-widget-title">',
					'after_title' => '</h2><div class="title-bar"></div>',
				)
			);

			register_sidebar(
				array(
					'name' => __( 'Footer Two', 'nany' ),
					'id' => 'footer-two',
					'description' => __( 'Appears on the footer.', 'nany' ),
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget' => '</div> <!-- end widget -->',
					'before_title' => '<h2 class="footer-widget-title">',
					'after_title' => '</h2><div class="title-bar"></div>',
				)
			);

			register_sidebar(
				array(
					'name' => __( 'Footer Three', 'nany' ),
					'id' => 'footer-three',
					'description' => __( 'Appears on the footer.', 'nany' ),
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget' => '</div> <!-- end widget -->',
					'before_title' => '<h2 class="footer-widget-title">',
					'after_title' => '</h2><div class="title-bar"></div>',
				)
			);

			register_sidebar(
				array(
					'name' => __( 'Footer Four', 'nany' ),
					'id' => 'footer-four',
					'description' => __( 'Appears on the footer.', 'nany' ),
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget' => '</div> <!-- end widget -->',
					'before_title' => '<h2 class="footer-widget-title">',
					'after_title' => '</h2><div class="title-bar"></div>',
				)
			);

			register_sidebar(
				array(
					'name' => __( 'Shop Widget', 'nany' ),
					'id' => 'shop-widget',
					'description' => __( 'Appears on pages.', 'nany' ),
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget' => '</div> <!-- end widget -->',
					'before_title' => '<h3 class="widget-title">',
					'after_title' => '</h3><div class="title-bar"></div>',
				)
			);

			register_sidebar(
				array(
					'name' => __( 'Twitter Widget', 'nany' ),
					'id' => 'twitter-widget',
					'description' => __( 'Add "TweetScroll" widget here. Then Add "Widgetised Sidebar" on your page & Select this widget.', 'nany' ),
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget' => '</div> <!-- end widget -->',
					'before_title' => '<h3 class="widget-title">',
					'after_title' => '</h3><div class="title-bar"></div>',
				)
			);

			/* Custom Widgets */
			$custom_sidebars = ot_get_option('custom_sidebars_list');
			if ($custom_sidebars) {
				foreach($custom_sidebars as $custom_sidebar) :
				$heading = $custom_sidebar['title'];
				$own_id = preg_replace('/[^a-z]/', "-", strtolower($heading));

				register_sidebar( array(
					'name' => __( $heading, 'nany' ),
					'id' => $own_id,
					'description' => __( $custom_sidebar['custom_sidebars_description'], 'nany' ),
					'before_widget' => '<div id="%1$s" class="widget %2$s">',
					'after_widget' => '</div> <!-- end widget -->',
					'before_title' => '<h3 class="widget-title">',
					'after_title' => '</h3><div class="title-bar"></div>',
				) );

				endforeach; }

		}
	}

	add_action( 'widgets_init', 'nany_widget_init' );
}

/**
 * ----------------------------------------------------------------------------------------
 * 8.0 - Function that validates a field's length.
 * ----------------------------------------------------------------------------------------
 */
if ( ! function_exists( 'nany_validate_length' ) ) {
	function nany_validate_length( $fieldValue, $minLength ) {
		// First, remove trailing and leading whitespace
		return ( strlen( trim( $fieldValue ) ) > $minLength );
	}
}


/**
 * ----------------------------------------------------------------------------------------
 * 9.0 - OptionTree Integration Settings for Theme Options
 * ----------------------------------------------------------------------------------------
 */

/**
 * This will hide the settings & documentation pages.
 */
add_filter( 'ot_show_pages', '__return_false' );

/**
 * Set theme mode true
 */
add_filter( 'ot_theme_mode', '__return_true' );

/**
* Hide layout option from option tree
*/
add_filter( 'ot_show_new_layout', '__return_false' );

/**
 * OptionTree in Theme Mode
 */
 require( trailingslashit( get_template_directory() ) . 'framework/theme-options/option-tree/ot-loader.php' );

/**
 * Theme Options
 */
 require( trailingslashit( get_template_directory() ) . 'framework/theme-options/theme-options.php' );

/**
 * MetaBox
 */
 require( trailingslashit( get_template_directory() ) . 'framework/theme-options/meta-boxes.php' );

/**
 * Import & Export
 */
 require( trailingslashit( get_template_directory() ) . 'framework/theme-options/import-export.php' );

/**
 * Google Fonts
*/
require( trailingslashit( get_template_directory() ) . 'framework/theme-options/google-fonts.php' );


/**
 * Theme Options Config
 */
 require( trailingslashit( get_template_directory() ) . 'framework/theme-options/theme-options-config.php' );

/**
 * This will change the default text of Send to OptionTree.
 */
add_filter( 'ot_upload_text', 'nany_option_tree_upload_text' );
function nany_option_tree_upload_text() {
	return __( 'Set Image', 'nany' );
}

/**
 * ----------------------------------------------------------------------------------------
 * 10.0 - Visual Composer - Inbuild
 * ----------------------------------------------------------------------------------------
 */

/* Creating a Own Template and Remove Default Templates from Visual Composer */
 require( get_template_directory() . '/framework/visual-composer/vc-templates.php' );

/* Set Visual Composer as a in-built with this theme */
 require( get_template_directory() . '/framework/visual-composer/vc-init.php' );


/* Set Visual Composer Directory */
if ( is_admin() ) {
    if (function_exists('vc_set_as_theme') ) {

        $dir = get_stylesheet_directory() . '/framework/visual-composer/';
        vc_set_template_dir($dir);

    } // End function
} // End if


function my_admin_theme_style() {
    wp_enqueue_style('my-admin-theme', THEMEROOT . '/framework/visual-composer/css/visual-composer.css', __FILE__);
    wp_enqueue_script('my-admin-theme', THEMEROOT . '/framework/plugins/metabox-on-select.js', __FILE__);
}
add_action('admin_enqueue_scripts', 'my_admin_theme_style');

/* ==============================================
   11.0 Custom Comment Area Modification
=============================================== */
function nany_comment_modification($comment, $args, $depth) {
	$GLOBALS['comment'] = $comment;
	extract($args, EXTR_SKIP);

	if ( 'div' == $args['style'] ) {
		$tag = 'div';
		$add_below = 'comment';
	} else {
		$tag = 'li';
		$add_below = 'div-comment';
	}
?>
	<<?php echo $tag ?> <?php comment_class( empty( $args['has_children'] ) ? '' : 'parent' ) ?> id="comment-<?php comment_ID() ?>">
	<?php if ( 'div' != $args['style'] ) : ?>
	<div id="div-comment-<?php comment_ID() ?>" class="comment-body">
	<?php endif; ?>
	<div class="comment-nany">
		<div class="comment-image">
			<?php if ( $args['avatar_size'] != 0 ) echo get_avatar( $comment, 60 ); ?>
		</div>
		<?php printf( __( '<h4>%s</h4>', 'nany' ), get_comment_author() ); ?>
		<!-- .comments-date -->
		<div class="comments-meta">
		  <span class="comments-date"><?php echo get_comment_date('M d, Y'); ?></span>
		</div>
		<!-- .comments-date -->

		<div class="comments-reply">
			<?php
		 comment_reply_link( array_merge( $args, array(
		 'reply_text' => 'Reply',
		 'before' => '<i class="fa fa-reply"></i>',
		 'class'  => 'comments-reply',
		 'depth' => $depth,
		 'max_depth' => $args['max_depth']
		 ) ) ); ?>
	  </div><!-- .comments-reply -->

	</div>
	<div class="comment-area">

	<?php if ( $comment->comment_approved == '0' ) : ?>
		<em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'nany' ); ?></em>
	<?php endif; ?>
  <?php comment_text(); ?>

	</div>

	<?php if ( 'div' != $args['style'] ) : ?>
	</div>
	<?php endif; ?>
<?php
}

/**
 * ----------------------------------------------------------------------------------------
 * 12.0 - Title Area
 * ----------------------------------------------------------------------------------------
 */
if ( ! function_exists( 'nany_title_area' ) ) {
	function nany_title_area() {

		global $post, $wp_query;

	if ( is_home() ) {
      echo bloginfo('name');
    } elseif ( is_search() ) {
      printf( __( 'Search Results for %s', 'nany' ), '<span>' . get_search_query() . '</span>' );
    } elseif ( is_category() || is_tax() ){
      single_cat_title();
    } elseif ( is_tag() ){
      single_tag_title(__('Posts Tagged: ', 'nany'));
    } elseif ( is_archive() ){
      if ( is_day() ) {
        printf( __( 'Archive for <span>%s</span>', 'nany' ), get_the_date());
      } elseif ( is_month() ) {
        printf( __( 'Archive for <span>%s</span>', 'nany' ), get_the_date( 'F, Y' ));
      } elseif ( is_year() ) {
        printf( __( 'Archive for <span>%s</span>', 'nany' ), get_the_date( 'Y' ));
      } elseif ( is_author() ) {
        printf( __( 'Archives by: <span>%s</span>', 'nany' ), get_the_author_meta( 'display_name', $wp_query->post->post_author ));
      } elseif ( is_post_type_archive() ) {
        post_type_archive_title();
      } else {
        _e( 'Archives', 'nany' );
      }
    } elseif( is_404() ) {
      _e('Error 404', 'nany');
    } elseif( get_post_meta( $post->ID, "page_custom_title", true ) ) {
      echo get_post_meta( $post->ID, "page_custom_title", true );
    } else {
      the_title();
    }

	}
}


/**
 * ----------------------------------------------------------------------------------------
 * 13.0 - Short - Title for anywhere - Used for WooCommerce
 * ----------------------------------------------------------------------------------------
 */
function short_title($after = '', $length) {
	$mytitle = explode(' ', get_the_title(), $length);
	if (count($mytitle)>=$length) {
		array_pop($mytitle);
		$mytitle = implode(" ",$mytitle). $after;
	} else {
		$mytitle = implode(" ",$mytitle);
	}
	return $mytitle;
}

/**
 * ----------------------------------------------------------------------------------------
 * 14.0 - Slider Revolution Theme Mode
 * ----------------------------------------------------------------------------------------
 */
if(function_exists( 'set_revslider_as_theme' )){
	add_action( 'init', 'nany_revslider_theme_mode' );
	function nany_revslider_theme_mode() {
		set_revslider_as_theme();
	}
}

/* Widget Category */
add_filter('widget_categories_args','show_empty_categories_links');
function show_empty_categories_links($args) {
	$args['hide_empty'] = 0;
	return $args;
}

/* ==============================================
	WordPress Default Focus Remove
=============================================== */
if(!function_exists('a_focus_remove'))
{
    function a_focus_remove(){
        ?>
        <style>
        	a:focus{color:#124964;-webkit-box-shadow:0 0 0 0px #5b9dd9,0 0 0px 0px rgba(30,140,190,.8);box-shadow:0 0 0 0px #5b9dd9,0 0 0px 0px rgba(30,140,190,.8)}
        </style>
        <?php
    }
}
add_action('admin_footer', 'a_focus_remove');


/* ==============================================
	Title Tag Edit
=============================================== */
function theme_wp_title( $title ) {
    // Get the Site Name
    $site_name = get_bloginfo( 'name' ) . ' | ';
    // Prepend name
    $filtered_title = $site_name . $title;
    // If site front page, append description
    if ( is_front_page() ) {
        // Get the Site Description
        $site_description = get_bloginfo( 'description' );
        // Append Site Description to title
        $filtered_title .= $site_description;
    }
    // Return the modified title
    return $filtered_title;
}
// Hook into 'wp_title'
add_filter( 'wp_title', 'theme_wp_title' );

?>