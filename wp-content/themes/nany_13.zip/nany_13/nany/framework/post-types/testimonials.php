<?php
/* ==============================================
    Testimonials Custom Post Type
=============================================== */
function nany_testimonials_type() {
  $labels = array(
    'name'               => __( 'Testimonials', 'nany' ),
    'singular_name'      => __( 'testimonial', 'nany' ),
    'add_new'            => __( 'Add New', 'nany' ),
    'add_new_item'       => __( 'Add New Testimonial', 'nany' ),
    'edit_item'          => __( 'Edit Testimonial', 'nany' ),
    'new_item'           => __( 'New Testimonial', 'nany' ),
    'all_items'          => __( 'All Testimonials', 'nany' ),
    'view_item'          => __( 'View Testimonial', 'nany' ),
    'search_items'       => __( 'Search Testimonials', 'nany' ),
    'not_found'          => __( 'No Testimonials found', 'nany' ),
    'not_found_in_trash' => __( 'No Testimonials found in the Trash', 'nany' ),
    'parent_item_colon'  => '',
    'menu_name'          => __( 'Testimonials', 'nany' )
  );
  $args = array(
    'labels'        => $labels,
    'description'   => 'Holds our testimonials and testimonial specific data',
    'public'        => true,
    'menu_position' => 20,
    'supports'      => array( 'title', 'editor' ),
    'has_archive'   => true,
  );
  register_post_type( 'testimonial', $args );
}
add_action( 'init', 'nany_testimonials_type' );


/* ==============================================
   Edit Text of - Enter Title Here
=============================================== */
add_filter('gettext','testimonial_custom_title');

function testimonial_custom_title( $input ) {

    global $post_type;

    if( is_admin() && 'Enter title here' == $input && 'testimonial' == $post_type )
        return 'Enter client name here';

    return $input;
}


/* ==============================================
   Help Text
=============================================== */
function my_contextual_help( $contextual_help, $screen_id, $screen ) {
  if ( 'testimonial' == $screen->id ) {

    $contextual_help = __( '<h2>Testimonials</h2><p>Testimonials only have Title(Client Name), Content(Testimonial Content), Client Profession, Featured Image(Client Image).</p><p>You can add this on shortcode called, testimonial slider.</p>', 'nany' );

  } elseif ( 'edit-testimonial' == $screen->id ) {

    $contextual_help = __( '<h2>Testimonials</h2><p>Testimonials only have Title(Client Name), Content(Testimonial Content), Client Profession, Featured Image(Client Image).</p><p>You can add this on shortcode called, testimonial slider.</p>', 'nany' );

  }
  return $contextual_help;
}
add_action( 'contextual_help', 'my_contextual_help', 10, 3 );

/* ==============================================
    Add Icons CSS
=============================================== */
function add_testimonial_menu_icon(){
?>
<style>
#menu-posts-testimonial .dashicons-before:before {
content: "\f130" !important;
}
</style>
<?php
}
add_action( 'admin_head', 'add_testimonial_menu_icon' );
?>