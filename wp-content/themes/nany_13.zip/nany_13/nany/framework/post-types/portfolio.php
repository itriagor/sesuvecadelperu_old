<?php
/*
*	---------------------------------------------------------------------
*	Add custom post type for portfolio
*	---------------------------------------------------------------------
*/


// Register portfolio post type
add_action( 'init', 'nany_portfolio_type' );

function nany_portfolio_type() {

    $portfolio_slug = ot_get_option('portfolio_slug', 'portfolio-item');
    $portfolio_name = ot_get_option('portfolio_name', 'Portfolio Item');

    $labels = array(
        'name' => __( $portfolio_name, 'nany' ),
        'singular_name' => __( $portfolio_name, 'nany' ),
        'add_new' => __( 'Add New', 'nany' ),
        'add_new_item' => __( 'Add New Item', 'nany' ),
        'edit_item' => __( 'Edit Item', 'nany' ),
        'new_item' => __( 'New '. $portfolio_name .' Item', 'nany' ),
        'view_item' => __( 'View '. $portfolio_name .' Item', 'nany' ),
        'search_items' => __( 'Search in '. $portfolio_name .'', 'nany' ),
        'not_found' => __( 'No '. $portfolio_name .' found', 'nany' ),
        'not_found_in_trash' => __( 'No Items found in Trash', 'nany' ),
        'parent_item_colon' => __( 'Parent '. $portfolio_name .':', 'nany' ),
        'menu_name' => __( ''. $portfolio_name .'', 'nany' ),
    );

    $args = array(
        'labels' => $labels,
        'hierarchical' => false,
        'supports' => array( 'title', 'editor', 'thumbnail' ),
        'public' => true,
        'show_ui' => true,
        'show_in_menu' => true,
        'menu_position' => 20,

        'show_in_nav_menus' => true,
        'publicly_queryable' => true,
        'exclude_from_search' => false,
        'has_archive' => true,
        'query_var' => true,
        'can_export' => true,
        'rewrite' => array('slug' => $portfolio_slug),
        'capability_type' => 'post',
    );

    register_post_type( 'portfolio', $args );
}

// Register custom taxonomie
add_action( 'init', 'create_portfolio_taxonomies', 0 );

function create_portfolio_taxonomies()
{
// Add new taxonomy, NOT hierarchical (like tags)
  $labels = array(
    'name' => __( 'Category', 'nany' ),
    'singular_name' => __( 'Category', 'nany' ),
    'search_items' =>  __( 'Search Categories', 'nany' ),
    'all_items' => __( 'All Categories', 'nany' ),
    'parent_item' => __( 'Parent Category', 'nany' ),
    'parent_item_colon' => __( 'Parent Category:', 'nany' ),
    'edit_item' => __( 'Edit Category', 'nany' ),
    'update_item' => __( 'Update Category', 'nany' ),
    'add_new_item' => __( 'Add New Category', 'nany' ),
    'new_item_name' => __( 'New Category Name', 'nany' ),
    'menu_name' => __( 'Categories', 'nany' ),
  );

  register_taxonomy('portfolio_category',array('portfolio'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'query_var' => true,
	'rewrite' => true,
	));
}

// Custom portfolio column
add_filter('manage_edit-portfolio_columns', 'add_new_portfolio_columns');

function add_new_portfolio_columns($gallery_columns) {
	$new_columns['cb'] = '<input type="checkbox" />';

	$new_columns['thumbnail'] = __('Thumbnail', 'nany' );
	$new_columns['title'] = __('Title', 'nany');
	$new_columns['author'] = __('Author', 'nany' );

	$new_columns['portfolio_categories'] = __('Categories', 'nany' );

	$new_columns['date'] = __('Date', 'nany');

	return $new_columns;
}

add_action('manage_portfolio_posts_custom_column', 'manage_portfolio_columns', 10, 2);

function manage_portfolio_columns($column_name) {
	global $post;
	switch ($column_name) {

	case 'thumbnail':
		echo get_the_post_thumbnail( $post->ID, 'thumbnail' );
	break;

	case 'portfolio_categories':
		$terms = wp_get_post_terms($post->ID, 'portfolio_category');
		foreach ($terms as $term) {
			echo $term->name .', ';
		}
	break;

	} // end switch
}

?>