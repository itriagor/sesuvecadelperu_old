<?php
function filter_radio_images( $array, $field_id ) {


  if ( $field_id == 'portfolio_style' ) {
    $array = array(
      array(
        'value'   => 'style-1',
        'label'   => __( 'Style 1', 'nany' ),
        'src'     => IMAGES . '/theme-options/layout/port-style-1.png'
      ),
	  array(
        'value'   => 'style-2',
        'label'   => __( 'Style 2', 'nany' ),
        'src'     => IMAGES . '/theme-options/layout/port-style-2.png'
      ),
	  array(
        'value'   => 'style-3',
        'label'   => __( 'Style 3', 'nany' ),
        'src'     => IMAGES . '/theme-options/layout/port-style-3.png'
      )
    );
  }

  return $array;

}
add_filter( 'ot_radio_images', 'filter_radio_images', 10, 2 );
?>