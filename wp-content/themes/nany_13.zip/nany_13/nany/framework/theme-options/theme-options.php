<?php
/**
 * Initialize the custom Theme Options.
 */
add_action( 'admin_init', 'custom_theme_options' );

/**
 * Build the custom settings & update OptionTree.
 *
 * @return    void
 * @since     2.0
 */
function custom_theme_options() {

  /**
   * The shortcode instruction file
   * @var text
  */
  ob_start();
  include_once dirname( __FILE__ ) . '/shortcode-reference.php';
  $shortcode_reference_context_html = ob_get_clean();
  $shortcode_reference_context = $shortcode_reference_context_html;

  /**
   * Get a copy of the saved settings array.
   */
  $saved_settings = get_option( ot_settings_id(), array() );

  /**
   * Custom settings array that will eventually be
   * passes to the OptionTree Settings API Class.
   */
  $custom_settings = array(


    /* ==============================================
        Sections
    =============================================== */
    'sections'        => array(
      array(
        'id'          => 'general_options',
        'title'       => __( 'General', 'nany' )
      ),
      array(
        'id'          => 'header_options',
        'title'       => __( 'Header', 'nany' )
      ),
      array(
        'id'          => 'color_options',
        'title'       => __( 'Color Options', 'nany' )
      ),array(
        'id'          => 'typography_option',
        'title'       => __( 'Typography', 'nany' )
      ),
      array(
        'id'          => 'nany_portfolio',
        'title'       => __( 'Portfolio', 'nany' )
      ),
      array(
        'id'          => 'nany_blog',
        'title'       => __( 'Blog', 'nany' )
      ),
      array(
        'id'          => 'nany_woo',
        'title'       => __( 'WooCommerce', 'nany' )
      ),
      array(
        'id'          => 'footer_options',
        'title'       => __( 'Footer', 'nany' )
      ),
      array(
        'id'          => 'custom_error',
        'title'       => __( '404 Page', 'nany' )
      ),
      array(
        'id'          => 'custom_css',
        'title'       => __( 'Custom CSS', 'nany' )
      ),
      array(
        'id'          => 'custom_sidebars',
        'title'       => __( 'Custom Sidebars', 'nany' ),
      ),
      array(
        'id'          => 'nany_shortcodes',
        'title'       => __( 'Shortcodes', 'nany' )
      ),
      array(
        'id' => 'shortcode-reference',
        'title' => 'Shortcode Reference'
      )
    ),

    /* ==============================================
        Settings Starts from here
    =============================================== */
    'settings'        => array(
      /* General */
      array(
        'id'          => 'nany_meta_keywords',
        'label'       => __( 'Enter your site keywords', 'nany' ),
        'desc'        => __( 'This will improve your site listing in search results. Each one sholud different with comma. Eg : wordpress, themes', 'nany' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'nany_meta_descriptions',
        'label'       => __( 'Enter your site description', 'nany' ),
        'desc'        => __( 'This will improve your site listing in search results.', 'nany' ),
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'general_options',
        'rows'        => '6',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'nany_site_layout',
        'label'       => __( 'Responsive layout', 'nany' ),
        'desc'        => __( 'Disable responsiveness mode for your website.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'disable_responsive',
            'label'       => __( 'Disable Responsive', 'nany' ),
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'nany_page_comments',
        'label'       => __( 'Enable page comments', 'nany' ),
        'desc'        => __( 'Enable page comments.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'enable_page_comments',
            'label'       => __( 'Enable Page Comments', 'nany' ),
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'nany_favicon',
        'label'       => __( 'Custom favicon', 'nany' ),
        'desc'        => __( 'Add custom favicon (16px x 16px)', 'nany' ),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'iphone_icon',
        'label'       => __( 'Apple iPhone icon', 'nany' ),
        'desc'        => __( 'Icon for Apple iPhone (57px x 57px). This icon is used for Bookmark on Home screen.', 'nany' ),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'iphone_retina_icon',
        'label'       => __( 'Apple iPhone retina icon', 'nany' ),
        'desc'        => __( 'Icon for Apple iPhone retina (114px x114px). This icon is used for Bookmark on Home screen.', 'nany' ),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'ipad_icon',
        'label'       => __( 'Apple iPad icon', 'nany' ),
        'desc'        => __( 'Icon for Apple iPad (72px x 72px). This icon is used for Bookmark on Home screen.', 'nany' ),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'ipad_retina_icon',
        'label'       => __( 'Apple iPad retina icon', 'nany' ),
        'desc'        => __( 'Icon for Apple iPad retina (144px x 144px). This icon is used for Bookmark on Home screen.', 'nany' ),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'login_logo',
        'label'       => __( 'Custom WP admin login logo', 'nany' ),
        'desc'        => __( 'Upload a custom logo for Wordpress login page.', 'nany' ),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'general_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
    array(
        'id'          => 'analytics_code',
        'label'       => __( 'Analytics code', 'nany' ),
        'desc'        => __( 'Paste your Google Analytics or other tracking code in text area.', 'nany' ),
        'std'         => '',
        'type'        => 'textarea-simple',
        'section'     => 'general_options',
        'rows'        => '6',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),


      /* Header */
      array(
        'id'          => 'logo_upload',
        'label'       => __( 'Logo upload', 'nany' ),
        'desc'        => __( 'Click Upload button to insert the image.', 'nany' ),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'header_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'retina_logo_upload',
        'label'       => __( 'Retina logo upload', 'nany' ),
        'desc'        => __( 'Retina logo should be 2x the size of default logo keeping the aspect ratio!', 'nany' ),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'header_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'title_background',
        'label'       => __( 'Title area background', 'nany' ),
        'desc'        => __( 'This option is for title area background.', 'nany' ),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'header_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'title_nub',
        'label'       => __( 'Title area Nub', 'nany' ),
        'desc'        => __( 'Upload your nub icon here. We\'ve included Photoshop file in this theme package under PSD folder - Open it, Change your brand color, Save it as a .png format and upload it here.<br /> It\'s looks like : <img src="'. get_template_directory_uri() .'/images/nubs/nany-blue.png" alt="title nub"/>', 'nany' ),
        'std'         => get_template_directory_uri() .'/images/nubs/nany-blue.png',
        'type'        => 'upload',
        'section'     => 'header_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'title_nub_bg_color',
        'label'       => __( 'Breadcrumbs BG Color', 'nany' ),
        'desc'        => __( 'Background color for breadcrumb bar.', 'nany' ),
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'header_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'disable_parallax_overlay',
        'label'       => __( 'Parallax Overlay', 'nany' ),
        'desc'        => __( 'Disables parallax overlay from page title area.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => 'header_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'disable_parallax_overlay',
            'label'       => __( 'Disable Parallax Overlay', 'nany' ),
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'disable_breadcrumbs',
        'label'       => __( 'Breadcrumbs', 'nany' ),
        'desc'        => __( 'This will hide breadcrumbs, bg and that nub.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => 'header_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'disable_breadcrumbs',
            'label'       => __( 'Disable breadcrumbs', 'nany' ),
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'disable_sticky_nav',
        'label'       => __( 'Sticky Navigation', 'nany' ),
        'desc'        => __( 'Disables sticky navigation.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => 'header_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'disable_sticky_nav',
            'label'       => __( 'Disable Sticky Navigation', 'nany' ),
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'disable_search',
        'label'       => __( 'Search', 'nany' ),
        'desc'        => __( 'Disables search icon from navigation.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => 'header_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'disable_search',
            'label'       => __( 'Disable Search Icon', 'nany' ),
            'src'         => ''
          )
        ),
      ),

      /* Color */
      array(
        'id'          => 'nany_primary_color',
        'label'       => __( 'Primary Color', 'nany' ),
        'desc'        => __( 'Click input field for colorpicker or enter your custom value', 'nany' ),
        'std'         => '#497bb8',
        'type'        => 'colorpicker',
        'section'     => 'color_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),

      array(
        'id'          => 'menu_notifications',
        'label'       => __( 'Text', 'nany' ),
        'desc'        => __( 'Menu Color', 'nany' ),
        'std'         => '',
        'type'        => 'textblock',
        'section'     => 'color_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'nany_menu_text_color',
        'label'       => __( 'Menu Text', 'nany' ),
        'desc'        => __( 'Click input field for colorpicker or enter your custom value', 'nany' ),
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'color_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),

      array(
        'id'          => 'heading_notifications',
        'label'       => __( 'Text', 'nany' ),
        'desc'        => __( 'Headings Color', 'nany' ),
        'std'         => '',
        'type'        => 'textblock',
        'section'     => 'color_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'nany_header_text_color',
        'label'       => __( 'Heading Text color (Content Area)', 'nany' ),
        'desc'        => __( 'Enter your header text color', 'nany' ),
        'std'         => '#444444',
        'type'        => 'colorpicker',
        'section'     => 'color_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'nany_sidebar_text_color',
        'label'       => __( 'Sidebar Heading Color', 'nany' ),
        'desc'        => __( 'Click input field for colorpicker or enter your custom value', 'nany' ),
        'std'         => '#444444',
        'type'        => 'colorpicker',
        'section'     => 'color_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'nany_footer_header_color',
        'label'       => __( 'Footer heading color', 'nany' ),
        'desc'        => __( 'Click input field for colorpicker or enter your custom value', 'nany' ),
        'std'         => '#ffffff',
        'type'        => 'colorpicker',
        'section'     => 'color_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),

      /* Typography */
      array(
        'id'          => 'google_body_font',
        'label'       => __( 'Body font', 'nany' ),
        'desc'        => __( 'Select body font styles using these options.', 'nany' ),
        'std'         => '',
        'type'        => 'typography',
        'section'     => 'typography_option',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'google_menu_font',
        'label'       => __( 'Menu font', 'nany' ),
        'desc'        => __( 'Select font for menus.', 'nany' ),
        'std'         => '',
        'type'        => 'typography',
        'section'     => 'typography_option',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'google_page_font',
        'label'       => __( 'Page title font', 'nany' ),
        'desc'        => __( 'Select page title font styles using these options.', 'nany' ),
        'std'         => '',
        'type'        => 'typography',
        'section'     => 'typography_option',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'google_fonts_headings',
        'label'       => __( 'Heading font', 'nany' ),
        'desc'        => __( 'Select content heading font styles using these options.', 'nany' ),
        'std'         => '',
        'type'        => 'typography',
        'section'     => 'typography_option',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'google_custom_font',
        'label'       => __( 'Custom font - Read Description', 'nany' ),
        'desc'        => __( 'To use custom font add CSS class - "custom-font" ( class="custom-font" ) to an element.', 'nany' ),
        'std'         => '',
        'type'        => 'typography',
        'section'     => 'typography_option',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),


      /* WooCommerce */
      array(
        'id'          => 'woo_layout',
        'label'       => __( 'Layout style', 'nany' ),
        'desc'        => __( 'Choose layout style for main product catalog page.', 'nany' ),
        'std'         => 'content_left',
        'type'        => 'select',
        'section'     => 'nany_woo',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'right_sidebar',
            'label'       => __( 'Right sidebar', 'nany' ),
            'src'         => ''
          ),
          array(
            'value'       => 'left_sidebar',
            'label'       => __( 'Left sidebar', 'nany' ),
            'src'         => ''
          ),
          array(
            'value'       => 'full_width',
            'label'       => __( 'Full width', 'nany' ),
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'woo_exclude_category',
        'label'       => __( 'Exclude Category', 'nany' ),
        'desc'        => __( 'Enter category slugs separated with comma. To hide that category from shop pages.', 'nany' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'nany_woo',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'disable_related_products',
        'label'       => __( 'Disable related products in single page?', 'nany' ),
        'desc'        => __( 'If you need to disable related products, Check this.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => 'nany_woo',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array(
          array(
            'value'       => 'disable_related_products',
            'label'       => __( 'Yes Please.', 'nany' ),
            'src'         => ''
          )
        ),
      ),

      /* Custom Sidebars */
      array(
        'id'          => 'custom_sidebars_list',
        'label'       => __( 'Add Custom Sidebars', 'nany' ),
        'desc'        => __( '<p>You can able to add unlimited sidebars here. Then assign these sidebars on page editor using <strong>Select Sidebar</strong> metabox.</p> <img src="'. get_template_directory_uri() . '/images/theme-options/custom-widgets.png" />', 'nany' ),
        'std'         => '',
        'type'        => 'list-item',
        'section'     => 'custom_sidebars',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'settings'    => array(
          array(
            'id'          => 'custom_sidebars_description',
            'label'       => __( 'Custom Sidebars Description', 'nany' ),
            'desc'        => __( 'Its just a description of this sidebar.', 'nany' ),
            'std'         => '',
            'type'        => 'text',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
          )
        )
      ),

      /* Process */
      array(
        'id'          => 'process_notifications',
        'label'       => __( 'Text', 'nany' ),
        'desc'        => __( 'Add Process tab list here. And Add this on your page using <strong>Process</strong> Shortcode.', 'nany' ),
        'std'         => '',
        'type'        => 'textblock',
        'section'     => 'nany_shortcodes',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'process_tabs',
        'label'       => __( 'Process Tabs', 'nany' ),
        'desc'        => __( 'You can find this on Shortcodes, Named : <strong>Process</strong>. Maximum 5.', 'nany' ),
        'std'         => '',
        'type'        => 'list_item',
        'section'     => 'nany_shortcodes',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'settings'    => array(
          array(
            'id'          => 'process_icon',
            'label'       => __( 'Tab Icon', 'nany' ),
            'desc'        => 'Select icon from <a href="http://fortawesome.github.io/Font-Awesome/cheatsheet/" target="_blank">FontAwesome</a> lib. (Eg : fa-heart)',
            'std'         => '',
            'type'        => 'text',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
          ),
          array(
            'id'          => 'process_color',
            'label'       => __( 'Tab Color', 'nany' ),
            'desc'        => 'Pick this tab color.',
            'std'         => '',
            'type'        => 'colorpicker',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
          ),
          array(
            'id'          => 'process_content',
            'label'       => __( 'Tab Content', 'nany' ),
            'desc'        => 'Enter this tab content.',
            'std'         => '',
            'type'        => 'textarea',
            'rows'        => '6',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
          ),
        )
      ),

      /* Timeline */
      array(
        'id'          => 'timeline_notifications',
        'label'       => __( 'Text', 'nany' ),
        'desc'        => __( 'Add Timeline section list here. And Add this on your page using <strong>Timeline</strong> Shortcode.', 'nany' ),
        'std'         => '',
        'type'        => 'textblock',
        'section'     => 'nany_shortcodes',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'timeline_section',
        'label'       => __( 'Timeline Section', 'nany' ),
        'desc'        => __( 'You can find this on Shortcodes, Named : <strong>Timeline</strong>. Maximum 4.', 'nany' ),
        'std'         => '',
        'type'        => 'list_item',
        'section'     => 'nany_shortcodes',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'settings'    => array(
          array(
            'id'          => 'timeline_year',
            'label'       => __( 'Section Year', 'nany' ),
            'desc'        => 'Enter the timeline represent year.',
            'std'         => '',
            'type'        => 'text',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
          ),
          array(
            'id'          => 'timeline_icon',
            'label'       => __( 'Section Icon', 'nany' ),
            'desc'        => 'Select icon from <a href="http://fortawesome.github.io/Font-Awesome/cheatsheet/" target="_blank">FontAwesome</a> lib. (Eg : fa-heart)',
            'std'         => '',
            'type'        => 'text',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
          ),
          array(
            'id'          => 'timeline_color',
            'label'       => __( 'Section Color', 'nany' ),
            'desc'        => 'Pick this section color.',
            'std'         => '',
            'type'        => 'colorpicker',
            'rows'        => '',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
          ),
          array(
            'id'          => 'timeline_content',
            'label'       => __( 'Section Content', 'nany' ),
            'desc'        => 'Enter this section content.',
            'std'         => '',
            'type'        => 'textarea',
            'rows'        => '6',
            'post_type'   => '',
            'taxonomy'    => '',
            'min_max_step'=> '',
            'class'       => '',
            'condition'   => '',
            'operator'    => 'and'
          ),
        )
      ),

      /* Portfolio */
      array(
        'id'          => 'portfolio_notifications',
        'label'       => __( 'Text', 'nany' ),
        'desc'        => __( 'Under this settings only apply for <strong>Archives</strong> and <strong>Category*</strong> page of portfolio.<br /> If you want separate portfolio please create new page with <strong>Portfolio</strong> page template. There you can get custom options.', 'nany' ),
        'std'         => '',
        'type'        => 'textblock',
        'section'     => 'nany_portfolio',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),

      array(
        'id'          => 'portfolio_name',
        'label'       => __('Portfolio Name', 'nany'),
        'desc'        => __('Leave it blank if you want to default. NOTE : This will update your Portfolio Breadcrumbs.', 'nany'),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'nany_portfolio',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'portfolio_slug',
        'label'       => __('Portfolio Slug', 'nany'),
        'desc'        => __('Leave it blank if you want to default. NOTE : Once you update this you need to reset permalinks if not works. Settings > Permalinks', 'nany'),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'nany_portfolio',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'portfolio_columns',
        'label'       => __('Select Portfolio Columns', 'nany'),
        'desc'        => __('Portfolio columns for archive & taxonomy pages.', 'nany'),
        'std'         => '',
        'type'        => 'select',
        'section'     => 'nany_portfolio',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'portfolio-4-column',
            'label'       => __('Portfolio Column 4', 'nany'),
            'src'         => ''
          ),
          array(
            'value'       => 'portfolio-3-column',
            'label'       => __('Portfolio Column 3', 'nany'),
            'src'         => ''
          ),
          array(
            'value'       => 'portfolio-2-column',
            'label'       => __('Portfolio Column 2', 'nany'),
            'src'         => ''
          )
        ),
      ),

      array(
        'id'          => 'portfolio_cat_filter',
        'label'       => __( 'Category Filter', 'nany' ),
        'desc'        => '',
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => 'nany_portfolio',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array(
          array(
            'value'       => 'enable_filter',
            'label'       => __( 'Enable Category Filter', 'nany' ),
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'portfolio_item_order',
        'label'       => __('Order', 'nany'),
        'desc'        => __('Select Order which you want.', 'nany'),
        'std'         => '',
        'type'        => 'select',
        'section'     => 'nany_portfolio',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'ASC',
            'label'       => 'ASC',
            'src'         => ''
          ),
          array(
            'value'       => 'DESC',
            'label'       => 'DESC',
            'src'         => ''
          )
        )
      ),
      array(
        'id'          => 'portfolio_item_orderby',
        'label'       => __('Orderby', 'nany'),
        'desc'        => __('Select Orderby which you want.', 'nany'),
        'std'         => '',
        'type'        => 'select',
        'section'     => 'nany_portfolio',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'ID',
            'label'       => 'ID',
            'src'         => ''
          ),
          array(
            'value'       => 'author',
            'label'       => 'Author',
            'src'         => ''
          ),
          array(
            'value'       => 'title',
            'label'       => 'Title',
            'src'         => ''
          ),
          array(
            'value'       => 'date',
            'label'       => 'Date',
            'src'         => ''
          ),
          array(
            'value'       => 'modified',
            'label'       => 'Modified',
            'src'         => ''
          ),
          array(
            'value'       => 'parent',
            'label'       => 'Parent',
            'src'         => ''
          ),
          array(
            'value'       => 'rand',
            'label'       => 'Random',
            'src'         => ''
          ),
        )
      ),
      array(
        'id'          => 'portfolio_show_category',
        'label'       => __('Show only certain categories?', 'nany'),
        'desc'        => __('Enter category <strong>SLUGS</strong> (comma separated) you want to display.<br/>If you want to display only one category, disable category filter!<br/><span style="color:green;">LEAVE EMPTY TO DISPLAY ALL CATEGORIES!</span>', 'nany'),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'nany_portfolio',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'portfolio_item_offset',
        'label'       => __('Offset', 'nany'),
        'desc'        => __('Number of items need to offset.', 'nany'),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'nany_portfolio',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
      ),
      array(
        'id'          => 'disable_pagination',
        'label'       => __( 'Disable Pagination', 'nany' ),
        'desc'        => __( 'If you want to disable pagination check this. This should work on portfolio taxonomy page.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => 'nany_portfolio',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array(
          array(
            'value'       => 'disable_pagination',
            'label'       => __( 'Yes Please.', 'nany' ),
            'src'         => ''
          )
        ),
      ),

      /* Blog */
      array(
        'id'          => 'blog_notification_to',
        'label'       => __( 'Blog Page', 'nany' ),
        'desc'        => __( 'Blog Page', 'nany' ),
        'std'         => '',
        'type'        => 'textblock',
        'section'     => 'nany_blog',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),
      array(
        'id'          => 'enable_fullwidth',
        'label'       => __( 'Full width blog', 'nany' ),
        'desc'        => __( 'Disables sidebar for the blog page.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => 'nany_blog',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array(
          array(
            'value'       => 'enable_fullwidth',
            'label'       => __( 'Enable full width for blog', 'nany' ),
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'sidebar_position',
        'label'       => __('Sidebar Position', 'nany'),
        'desc'        => __('Select sidebar position for your blog page.', 'nany'),
        'std'         => '',
        'type'        => 'select',
        'section'     => 'nany_blog',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'right',
            'label'       => __('Right', 'nany'),
            'src'         => ''
          ),
          array(
            'value'       => 'left',
            'label'       => __('Left', 'nany'),
            'src'         => ''
          )
        ),
      ),

      array(
        'id'          => 'exclude_categories_from_blog',
        'label'       => __('Exclude categories from blog page', 'nany'),
        'desc'        => __('Select categories you want to exclude from blog page.', 'nany'),
        'std'         => '',
        'type'        => 'category-checkbox',
        'section'     => 'nany_blog',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),

      array(
        'id'          => 'blog_excerpt_lenght',
        'label'       => __('Excerpt length', 'nany'),
        'desc'        => __('Input the number of words you want to take from content to make excerpt.', 'nany'),
        'std'         => '82',
        'type'        => 'text',
        'section'     => 'nany_blog',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),

      array(
        'id'          => 'hide_meta',
        'label'       => __( 'Check items you want to hide from meta', 'nany' ),
        'desc'        => __( 'Check items you want to hide from blog/post meta field.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => 'nany_blog',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'date',
            'label'       => 'Date',
            'src'         => ''
          ),
          array(
            'value'       => 'category',
            'label'       => 'Category',
            'src'         => ''
          ),
          array(
            'value'       => 'likes',
            'label'       => 'Likes',
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'blog_readmore_btn',
        'label'       => __( 'Read More button text', 'nany' ),
        'desc'        => __( 'Enter Read More button text, if you want to change.', 'nany' ),
        'std'         => __( 'Read More', 'nany' ),
        'type'        => 'text',
        'section'     => 'nany_blog',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),

      /* Single Portfolio */
      array(
        'id'          => 'single_theme_options',
        'label'       => __( 'Text', 'nany' ),
        'desc'        => __( 'Single Blog', 'nany' ),
        'std'         => '',
        'type'        => 'textblock',
        'section'     => 'nany_blog',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and'
      ),

      array(
        'id'          => 'hide_author_box',
        'label'       => __( 'Author info', 'nany' ),
        'desc'        => __( 'Show or hide author information under the single post.<br /> Note: This will only available when you using your <strong>Biographical Info</strong> in <strong>Users > Your Profile</strong>.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => 'nany_blog',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'min_max_step'=> '',
        'class'       => '',
        'condition'   => '',
        'operator'    => 'and',
        'choices'     => array(
          array(
            'value'       => 'hide_author_info',
            'label'       => __( 'Hide author info box', 'nany' ),
            'src'         => ''
          )
        ),
      ),

      /* Footer */
      array(
        'id'          => 'copyright_bar',
        'label'       => __( 'Copyright bar', 'nany' ),
        'desc'        => __( 'This will disable copyright bar below the footer.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => 'footer_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'disable_copyright_bar',
            'label'       => 'Disable copyright bar',
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'copyright_area_text',
        'label'       => __( 'Copyright area text', 'nany' ),
        'desc'        => __( 'This text will appear on the bottom left of your website.', 'nany' ),
        'std'         => __( 'Copyright &copy; 2014 - Nany', 'nany' ),
        'type'        => 'textarea-simple',
        'section'     => 'footer_options',
        'rows'        => '6',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'footer_widgets',
        'label'       => __( 'Footer widgets', 'nany' ),
        'desc'        => __( 'This setting will disable footer.', 'nany' ),
        'std'         => '',
        'type'        => 'checkbox',
        'section'     => 'footer_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
        'choices'     => array(
          array(
            'value'       => 'disable_footer_widgets',
            'label'       => 'Disable  footer widgets',
            'src'         => ''
          )
        ),
      ),
      array(
        'id'          => 'footer_widgets_animations',
        'label'       => __( 'Widgets Scroll Effect', 'nany' ),
        'desc'        => __( 'Select animation type for footer widgets. <br />Live Action : <a href="http://daneden.github.io/animate.css/" target="_blank">Animate.css</a>. Eg : fadeIn', 'nany' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'footer_options',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => '',
      ),

      /* 404 Error */
      array(
        'id'          => 'error_heading',
        'label'       => __( '404 Heading', 'nany' ),
        'desc'        => __( 'Enter your text for 404 page heading.', 'nany' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'custom_error',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'error_content',
        'label'       => __( '404 Sub-Heading', 'nany' ),
        'desc'        => __( 'Enter your text for 404 page sub-heading.', 'nany' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'custom_error',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'error_button',
        'label'       => __( 'Button Text', 'nany' ),
        'desc'        => __( 'Enter your text for 404 page button.', 'nany' ),
        'std'         => '',
        'type'        => 'text',
        'section'     => 'custom_error',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'error_bg',
        'label'       => __( 'Background Image', 'nany' ),
        'desc'        => __( 'Upload background image for 404 page.', 'nany' ),
        'std'         => '',
        'type'        => 'upload',
        'section'     => 'custom_error',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),
      array(
        'id'          => 'error_all_color',
        'label'       => __( 'All Content Color', 'nany' ),
        'desc'        => __( 'Pick all content color.', 'nany' ),
        'std'         => '',
        'type'        => 'colorpicker',
        'section'     => 'custom_error',
        'rows'        => '',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),


      /* Custom CSS */
      array(
        'id'          => 'nany_styling',
        'label'       => __( 'Custom CSS', 'nany' ),
        'desc'        => __( 'Enter your custom css with that classes.', 'nany' ),
        'std'         => '',
        'type'        => 'css',
        'section'     => 'custom_css',
        'rows'        => '6',
        'post_type'   => '',
        'taxonomy'    => '',
        'class'       => ''
      ),

      /* Shortcodes */
      array(
        'id' => 'shortcode-reference-context',
        'label' => 'Shortcode Reference',
        'desc' => $shortcode_reference_context,
        'type' => 'text',
        'section' => 'shortcode-reference',
        'std' => ''
      )

    )
  );

  /* allow settings to be filtered before saving */
  $custom_settings = apply_filters( ot_settings_id() . '_args', $custom_settings );

  /* settings are not the same update the DB */
  if ( $saved_settings !== $custom_settings ) {
    update_option( ot_settings_id(), $custom_settings );
  }

}