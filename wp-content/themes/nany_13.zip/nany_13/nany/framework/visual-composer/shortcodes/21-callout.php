<?php

/* ==========================================================
    Visual Composer - Callout
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_callout')) {
  function nany_callout( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      /* General */
      'callout_heading'  => '',
      'callout_subheading'  => '',
      'callout_content'  => '',
      'content_alignment'  => '',
      'extra_class'  => '',

      /* Design */
      'heading_color'  => '',
      'heading_size'  => '',
      'subheading_color'  => '',
      'subheading_size'  => '',
      'heading_line_height'  => '',
      'content_color'  => '',
      'content_size'  => '',
      'content_line_height'  => '',

      /* Button One */
      'button_text'  => '',
      'button_link'  => '',
      'open_window'  => '',
      'button_style'  => '',
      'button_size'  => '',
      'bg_color'  => '',
      'text_color'  => '',
      'text_transform'  => '',
      'btn_top_space'  => '',
      'btn_bottom_space'  => '',

      /* Button Two */
      'button_text_2'  => '',
      'button_link_2'  => '',
      'open_window_2'  => '',
      'button_style_2'  => '',
      'button_size_2'  => '',
      'bg_color_2'  => '',
      'text_color_2'  => '',
      'text_transform_2'  => '',
      'btn_top_space_2'  => '',
      'btn_bottom_space_2'  => ''

    ), $atts));

    /* Design */
    if ($heading_color) {
      $heading_color = 'color:'. $heading_color .';';
    }
    if ($heading_size) {
      $heading_size = 'font-size:'. $heading_size .';';
    }
    if ($subheading_color) {
      $subheading_color = 'color:'. $subheading_color .';';
    }
    if ($subheading_size) {
      $subheading_size = 'font-size:'. $subheading_size .';';
    }
    if ($heading_line_height) {
      $heading_line_height = 'line-height:'. $heading_line_height .';';
    }
    if ($content_color) {
      $content_color = 'color:'. $content_color .';';
    }
    if ($content_size) {
      $content_size = 'font-size:'. $content_size .';';
    }
    if ($content_line_height) {
      $content_line_height = 'line-height:'. $content_line_height .';';
    }

    /* General */
    if ($callout_heading) {
      $callout_heading = '<h2 style="'. $heading_color . $heading_size . $heading_line_height .'">'. $callout_heading .'</h2>';
    }
    if ($callout_subheading) {
      $callout_subheading = '<h4 style="'. $subheading_color . $subheading_size . $heading_line_height .'">'. $callout_subheading .'</h4>';
    }
    if ($callout_content) {
      $callout_content = '<p style="'. $content_color . $content_size . $content_line_height .'">'. $callout_content .'</p>';
    }

    /* Button */
    if ( $open_window ) {
      $open_window = 'target="_blank"';
    }
    if ( $button_size ) {
      $button_size = $button_size;
    }
    if ( $button_style === 'btn-style-one' ) {
       $bg_color = 'background-color:'. $bg_color .';';
    }
    if ( $button_style === 'btn-style-three' ) {
       $bg_color = 'background-color:'. $bg_color .';';
    }
    if ( $button_style === 'btn-style-five' ) {
       $bg_color = 'background-color:'. $bg_color .';border:2px solid '. $bg_color .';';
    }
    if ( $button_style === 'btn-style-two' ) {
       $bg_color = 'border-color:'. $bg_color .';';
    }
    if ( $button_style === 'btn-style-four' ) {
       $bg_color = 'border-color:'. $bg_color .';';
    }
    if ( $text_color ) {
      $text_color = 'color:'. $text_color .';';
    }
    if ( $text_transform ) {
      $text_transform = 'text-transform:'. $text_transform .';';
    }
    if ( $btn_top_space ) {
      $btn_top_space = 'margin-top:'. $btn_top_space .' !important;';
    }
    if ( $btn_bottom_space ) {
      $btn_bottom_space = 'margin-bottom:'. $btn_bottom_space .' !important;';
    }
    if ( $button_link ) {
      $button_code = '<div class="smooth-scroll-btn callout-button"><a href="'. esc_url($button_link) .'" '. $open_window .' class="'. $button_style .' '. $button_size .'" style="'. $bg_color . $text_color . $text_transform . $btn_top_space . $btn_bottom_space .'">'. $button_text .'</a></div>';
    } else {
      $button_code = '';
    }

    /* Button Two */
    if ( $open_window_2 ) {
      $open_window_2 = 'target="_blank"';
    }
    if ( $button_size_2 ) {
      $button_size_2 = $button_size_2;
    }
    if ( $button_style_2 === 'btn-style-one' ) {
       $bg_color_2 = 'background-color:'. $bg_color_2 .';';
    }
    if ( $button_style_2 === 'btn-style-three' ) {
       $bg_color_2 = 'background-color:'. $bg_color_2 .';';
    }
    if ( $button_style_2 === 'btn-style-five' ) {
       $bg_color_2 = 'background-color:'. $bg_color_2 .';';
    }
    if ( $button_style_2 === 'btn-style-two' ) {
       $bg_color_2 = 'border-color:'. $bg_color_2 .';';
    }
    if ( $button_style_2 === 'btn-style-four' ) {
       $bg_color_2 = 'border-color:'. $bg_color_2 .';';
    }
    if ( $text_color_2 ) {
      $text_color_2 = 'color:'. $text_color_2 .';';
    }
    if ( $text_transform_2 ) {
      $text_transform_2 = 'text-transform:'. $text_transform_2 .';';
    }
    if ( $btn_top_space_2 ) {
      $btn_top_space_2 = 'margin-top:'. $btn_top_space_2 .' !important;';
    }
    if ( $btn_bottom_space_2 ) {
      $btn_bottom_space_2 = 'margin-bottom:'. $btn_bottom_space_2 .' !important;';
    }
    if ( $button_link_2 ) {
      $button_code_2 = '<div class="smooth-scroll-btn callout-button callout-button2"><a href="'. esc_url($button_link_2) .'" '. $open_window_2 .' class="'. $button_style_2 .' '. $button_size_2 .'" style="'. $bg_color_2 . $text_color_2 . $text_transform_2 . $btn_top_space_2 . $btn_bottom_space_2 .'">'. $button_text_2 .'</a></div>';
    } else {
      $button_code_2 = '';
    }

    /* Callout Align Left */
    if ($content_alignment === 'align-left') {
      $callout = '<div class="callout callout-align-left '. $extra_class .'"><div class="callout-content">'. $callout_heading . $callout_subheading . $callout_content .'</div><div class="callout-buttons">'. $button_code . $button_code_2 .'</div></div>';
    }

    /* Callout Align Center */
    if ($content_alignment === 'align-center') {
      $callout = '<div class="callout callout-align-center '. $extra_class .'"><div class="callout-content">'. $callout_heading . $callout_subheading . $callout_content .'</div><div class="callout-buttons">'. $button_code . $button_code_2 .'</div></div>';
    }

    /* Callout Align Right */
    if ($content_alignment === 'align-right') {
      $callout = '<div class="callout callout-align-right '. $extra_class .'"><div class="callout-content">'. $callout_heading . $callout_subheading . $callout_content .'</div><div class="callout-buttons">'. $button_code . $button_code_2 .'</div></div>';
    }

    return $callout;

  }
}
add_shortcode( 'callout', 'nany_callout' );


/**
  Add to visual composer
**/
add_action( 'init', 'nany_callout_vc_map' );
if ( ! function_exists( 'nany_callout_vc_map' ) ) {
  function nany_callout_vc_map() {
    vc_map( array(
        "name" =>"Callout",
        "base" => "callout",
        "description" => "Callout Styles",
        "icon" => "vc-callout",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "textfield",
                "heading" => __( "Heading", 'nany' ),
                "param_name" => "callout_heading",
                'value'=> 'This is a main heading',
                "admin_label" => true,
                "description" => __( "Enter Callout heading", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Sub Heading", 'nany' ),
                "param_name" => "callout_subheading",
                'value'=> '',
                "description" => __( "Enter Callout Sub-heading", 'nany')
            ),

            array(
                "type" => "textarea",
                "heading" => __( "Content", 'nany' ),
                "param_name" => "callout_content",
                'value'=> __( "Modern & Unique Design WordPress Theme. The Unique Style is getting more popular, so show yourself from the best side!", 'nany' ),
                "description" => __( "Enter some callout content here.", 'nany'),
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Content Alignment", 'nany' ),
                "param_name" => "content_alignment",
                "value" => array(
                            "Align Left"=>'align-left',
                            "Align Center"=>'align-center',
                            "Align Right"=>'align-right'
                          ),
                "description" => __( "Select callout content alignment position.", 'nany'),
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

            /* Design Group */
            array(
                "type" => "colorpicker",
                "heading" => __( "Heading Color", 'nany' ),
                "param_name" => "heading_color",
                'value'=>'',
                "description" => __( "Enter this callout heading color.", 'nany'),
                "group" => __( "Design", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Heading Size", 'nany' ),
                "param_name" => "heading_size",
                'value'=>'',
                "description" => __( "Enter heading size in px. (Eg : 22px)", 'nany'),
                "group" => __( "Design", 'nany')
            ),

            array(
                "type" => "colorpicker",
                "heading" => __( "Sub-Heading Color", 'nany' ),
                "param_name" => "subheading_color",
                'value'=>'',
                "description" => __( "Enter this callout sub-heading color.", 'nany'),
                "group" => __( "Design", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Sub Heading Size", 'nany' ),
                "param_name" => "subheading_size",
                'value'=>'',
                "description" => __( "Enter sub-heading size in px. (Eg : 22px)", 'nany'),
                "group" => __( "Design", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Heading Line Height", 'nany' ),
                "param_name" => "heading_line_height",
                'value'=>'',
                "description" => __( "Enter heading line height in px. (Eg : 16px)", 'nany'),
                "group" => __( "Design", 'nany')
            ),

            array(
                "type" => "colorpicker",
                "heading" => __( "Content Color", 'nany' ),
                "param_name" => "content_color",
                'value'=>'',
                "description" => __( "Enter callout content color.", 'nany'),
                "group" => __( "Design", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Content Size", 'nany' ),
                "param_name" => "content_size",
                'value'=>'',
                "description" => __( "Enter content size in px. (Eg : 16px)", 'nany'),
                "group" => __( "Design", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Content Line Height", 'nany' ),
                "param_name" => "content_line_height",
                'value'=>'',
                "description" => __( "Enter content line height in px. (Eg : 16px)", 'nany'),
                "group" => __( "Design", 'nany')
            ),

            /* Button */
            array(
                "type" => "textfield",
                "heading" => __( "Button Text", 'nany' ),
                "param_name" => "button_text",
                'value'=>'My Button',
                "description" => __( "Enter button text", 'nany'),
                 "group" => __( "Button", 'nany')
            ),
            array(
                "type" => "href",
                "heading" => __( "Button Link", 'nany' ),
                "param_name" => "button_link",
                'value'=>'',
                "description" => __( "Enter button link", 'nany'),
                 "group" => __( "Button", 'nany')
            ),
            array(
              "type"=>'checkbox',
              "heading"=>__('Link open in new window?', 'nany'),
              "param_name"=> "open_window",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need to open link in new window, check this.", 'nany'),
               "group" => __( "Button", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Button Style", 'nany' ),
                "param_name" => "button_style",
                "value" => array(
                            "Style One"=>'btn-style-one',
                            "Style Two"=>'btn-style-two',
                            "Style Three"=>'btn-style-three',
                            "Style Four"=>'btn-style-four',
                            "Style Five"=>'btn-style-five'
                          ),
                "description" => __( "Select Button Style", 'nany'),
                 "group" => __( "Button", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Button Size", 'nany' ),
                "param_name" => "button_size",
                "value" => array(
                            "Small"=>'small-btn',
                            "Medium"=>'medium-btn',
                            "Large"=>'large-btn'
                          ),
                "description" => __( "Select Button Size", 'nany'),
                 "group" => __( "Button", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Background color', 'nany'),
              "param_name"=> "bg_color",
              "value"=>"#497bb8",
              "description" => __( "Select background color for button.", 'nany'),
               "group" => __( "Button", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Text color', 'nany'),
              "param_name"=> "text_color",
              "value"=>"#ffffff",
              "description" => __( "Select text color for button.", 'nany'),
               "group" => __( "Button", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Text Transform", 'nany' ),
                "param_name" => "text_transform",
                "value" => array(
                            "Normal"=>'none',
                            "Uppercase"=>'uppercase',
                            "Capitalize"=>'capitalize',
                            "Lowercase"=>'lowercase'
                          ),
                "description" => __( "Select button text transform.", 'nany'),
                 "group" => __( "Button", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Top Space", 'nany' ),
                "param_name" => "btn_top_space",
                'value'=>'',
                "description" => __( "Button Top Space", 'nany'),
                 "group" => __( "Button", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Bottom Space", 'nany' ),
                "param_name" => "btn_bottom_space",
                'value'=>'',
                "description" => __( "Button Bottom Space", 'nany'),
                 "group" => __( "Button", 'nany')
            ),

            /* Button2 */
            array(
                "type" => "textfield",
                "heading" => __( "Button Text", 'nany' ),
                "param_name" => "button_text_2",
                'value'=>'My Button',
                "description" => __( "Enter button text", 'nany'),
                 "group" => __( "Button 2", 'nany')
            ),
            array(
                "type" => "href",
                "heading" => __( "Button Link", 'nany' ),
                "param_name" => "button_link_2",
                'value'=>'',
                "description" => __( "Enter button link", 'nany'),
                 "group" => __( "Button 2", 'nany')
            ),
            array(
              "type"=>'checkbox',
              "heading"=>__('Link open in new window?', 'nany'),
              "param_name"=> "open_window_2",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need to open link in new window, check this.", 'nany'),
               "group" => __( "Button 2", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Button Style", 'nany' ),
                "param_name" => "button_style_2",
                "value" => array(
                            "Style One"=>'btn-style-one',
                            "Style Two"=>'btn-style-two',
                            "Style Three"=>'btn-style-three',
                            "Style Four"=>'btn-style-four',
                            "Style Five"=>'btn-style-five'
                          ),
                "description" => __( "Select Button Style", 'nany'),
                 "group" => __( "Button 2", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Button Size", 'nany' ),
                "param_name" => "button_size_2",
                "value" => array(
                            "Small"=>'small-btn',
                            "Medium"=>'medium-btn',
                            "Large"=>'large-btn'
                          ),
                "description" => __( "Select Button Size", 'nany'),
                 "group" => __( "Button 2", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Background color', 'nany'),
              "param_name"=> "bg_color_2",
              "value"=>"#497bb8",
              "description" => __( "Select background color for button.", 'nany'),
               "group" => __( "Button 2", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Text color', 'nany'),
              "param_name"=> "text_color_2",
              "value"=>"#ffffff",
              "description" => __( "Select text color for button.", 'nany'),
               "group" => __( "Button 2", 'nany')
            ),
            array(
                "type" => "dropdown",
                "heading" => __( "Text Transform", 'nany' ),
                "param_name" => "text_transform_2",
                "value" => array(
                            "Normal"=>'none',
                            "Uppercase"=>'uppercase',
                            "Capitalize"=>'capitalize',
                            "Lowercase"=>'lowercase'
                          ),
                "description" => __( "Select button text transform.", 'nany'),
                 "group" => __( "Button 2", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Top Space", 'nany' ),
                "param_name" => "btn_top_space_2",
                'value'=>'',
                "description" => __( "Button Top Space", 'nany'),
                 "group" => __( "Button 2", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Bottom Space", 'nany' ),
                "param_name" => "btn_bottom_space_2",
                'value'=>'',
                "description" => __( "Button Bottom Space", 'nany'),
                 "group" => __( "Button 2", 'nany')
            ),



          )
    ) );
  }
}


?>