<?php

/* ==========================================================
    Visual Composer - team
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_team')) {
  function nany_team( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'team_image'  => '',
      'team_name'  => '',
      'team_profession'  => '',
      /* Design */
      'name_color'  => '',
      'name_size'  => '',
      'profession_color'  => '',
      'profession_size'  => '',
      'content_color'  => '',
      'content_size'  => '',

      /* Social Media */
      'link_window'  => '',
      'social_facebook'  => '',
      'social_twitter'  => '',
      'social_linkedin'  => '',
      'social_google'  => '',
      'social_dribbble'  => '',
      'social_youtube'  => '',
      'social_vimeo'  => '',
      'social_skype'  => '',
      'social_rss'  => '',
      'social_pinterest'  => '',
      'social_flickr'  => '',
      'social_foursquare'  => '',
      'social_android'  => '',
      'social_bitbucket'  => '',
      'social_css3'  => '',
      'social_dropbox'  => '',
      'social_github'  => '',
      'social_html5'  => '',
      'social_instagram'  => '',
      'social_stack_exchange'  => '',
      'social_stack_overflow'  => '',
      'social_trello'  => '',
      'social_tumblr'  => '',
      /* Button */
      'button_link'   => '',
      'open_window'  => '',

      /* Popup */
      'pop_details' => '',
      'team_content' => '',
      'extra_class'  => ''
    ), $atts));


    $own_id = preg_replace('/[^a-z]/', "-", strtolower($team_name));

    if ( $name_color ) {
      $name_color = 'color:'. $name_color .';';
    }
    if ( $name_size ) {
      $name_size = 'font-size:'. $name_size .';';
    }
    if ( $profession_color ) {
      $profession_color = 'color:'. $profession_color .';';
    }
    if ( $profession_size ) {
      $profession_size = 'font-size:'. $profession_size .';';
    }
    if ( $content_color ) {
      $content_color = 'color:'. $content_color .';';
    }
    if ( $content_size ) {
      $content_size = 'font-size:'. $content_size .';';
    }

    /* Button */
    if ( $open_window ) {
      $open_window = 'target="_blank"';
    }
    if ( $pop_details === 'no' ) {
      $button_code = '<span class="popup-team team-overlay"><a href="'. esc_url($button_link) .'" '. $open_window .'><i class="fa fa-plus"></i></a></span>';
    }
    if ( $pop_details === 'yes' ) {
      $button_code = '<span class="popup-team team-overlay"><a href="#'. $own_id .'" class="popup-with-zoom-anim"><i class="fa fa-plus"></i></a></span>';
    }

    if ( $team_image ) {
      $image_url = wp_get_attachment_url( $team_image );
      $team_image = '<span class="team-image"><img src="'. esc_attr($image_url) .'" alt="'. esc_attr($team_name) .'" />'. $button_code .'</span>';
    } else {
      $team_image = '<span class="team-image"><img src="'. IMAGES .'/dummy/334x334.jpg" alt="'. esc_attr($team_name) .'" />'. $button_code .'</span>';
    }

    /* ==============================================
      Social Media
    =============================================== */
    if ($link_window === 'yes') {
      $link_window = 'target="_blank"';
    }
    if ($social_facebook) {
      $social_facebook = '<li><a href="'. esc_url($social_facebook) .'" class="icon-fa-facebook" '. $link_window .'><i class="fa fa-facebook"></i></a></li>';
    }
    if ($social_twitter) {
      $social_twitter = '<li><a href="'. esc_url($social_twitter) .'" class="icon-fa-twitter" '. $link_window .'><i class="fa fa-twitter"></i></a></li>';
    }
    if ($social_linkedin) {
      $social_linkedin = '<li><a href="'. esc_url($social_linkedin) .'" class="icon-fa-linkedin" '. $link_window .'><i class="fa fa-linkedin"></i></a></li>';
    }
    if ($social_google) {
      $social_google = '<li><a href="'. esc_url($social_google) .'" class="icon-fa-google-plus" '. $link_window .'><i class="fa fa-google-plus"></i></a></li>';
    }
    if ($social_dribbble) {
      $social_dribbble = '<li><a href="'. esc_url($social_dribbble) .'" class="icon-fa-dribbble" '. $link_window .'><i class="fa fa-dribbble"></i></a></li>';
    }
    if ($social_youtube) {
      $social_youtube = '<li><a href="'. esc_url($social_youtube) .'" class="icon-fa-youtube" '. $link_window .'><i class="fa fa-youtube"></i></a></li>';
    }
    if ($social_vimeo) {
      $social_vimeo = '<li><a href="'. esc_url($social_vimeo) .'" class="icon-fa-vimeo" '. $link_window .'><i class="fa fa-vimeo-square"></i></a></li>';
    }
    if ($social_skype) {
      $social_skype = '<li><a href="'. esc_url($social_skype) .'" class="icon-fa-skype" '. $link_window .'><i class="fa fa-skype"></i></a></li>';
    }
    if ($social_rss) {
      $social_rss = '<li><a href="'. esc_url($social_rss) .'" class="icon-fa-rss" '. $link_window .'><i class="fa fa-rss"></i></a></li>';
    }
    if ($social_pinterest) {
      $social_pinterest = '<li><a href="'. esc_url($social_pinterest) .'" class="icon-fa-pinterest" '. $link_window .'><i class="fa fa-pinterest"></i></a></li>';
    }
    if ($social_flickr) {
      $social_flickr = '<li><a href="'. esc_url($social_flickr) .'" class="icon-fa-flickr" '. $link_window .'><i class="fa fa-flickr"></i></a></li>';
    }
    if ($social_foursquare) {
      $social_foursquare = '<li><a href="'. esc_url($social_foursquare) .'" class="icon-fa-foursquare" '. $link_window .'><i class="fa fa-foursquare"></i></a></li>';
    }
    if ($social_android) {
      $social_android = '<li><a href="'. esc_url($social_android) .'" class="icon-fa-android" '. $link_window .'><i class="fa fa-android"></i></a></li>';
    }
    if ($social_bitbucket) {
      $social_bitbucket = '<li><a href="'. esc_url($social_bitbucket) .'" class="icon-fa-bitbucket" '. $link_window .'><i class="fa fa-bitbucket"></i></a></li>';
    }
    if ($social_css3) {
      $social_css3 = '<li><a href="'. esc_url($social_css3) .'" class="icon-fa-css3" '. $link_window .'><i class="fa fa-css3"></i></a></li>';
    }
    if ($social_dropbox) {
      $social_dropbox = '<li><a href="'. esc_url($social_dropbox) .'" class="icon-fa-dropbox" '. $link_window .'><i class="fa fa-dropbox"></i></a></li>';
    }
    if ($social_github) {
      $social_github = '<li><a href="'. esc_url($social_github) .'" class="icon-fa-github" '. $link_window .'><i class="fa fa-github"></i></a></li>';
    }
    if ($social_html5) {
      $social_html5 = '<li><a href="'. esc_url($social_html5) .'" class="icon-fa-html5" '. $link_window .'><i class="fa fa-html5"></i></a></li>';
    }
    if ($social_instagram) {
      $social_instagram = '<li><a href="'. esc_url($social_instagram) .'" class="icon-fa-instagram" '. $link_window .'><i class="fa fa-instagram"></i></a></li>';
    }
    if ($social_stack_exchange) {
      $social_stack_exchange = '<li><a href="'. esc_url($social_stack_exchange) .'" class="icon-fa-stack-exchange" '. $link_window .'><i class="fa fa-stack-exchange"></i></a></li>';
    }
    if ($social_stack_overflow) {
      $social_stack_overflow = '<li><a href="'. esc_url($social_stack_overflow) .'" class="icon-fa-stack-overflow" '. $link_window .'><i class="fa fa-stack-overflow"></i></a></li>';
    }
    if ($social_trello) {
      $social_trello = '<li><a href="'. esc_url($social_trello) .'" class="icon-fa-trello" '. $link_window .'><i class="fa fa-trello"></i></a></li>';
    }
    if ($social_tumblr) {
      $social_tumblr = '<li><a href="'. esc_url($social_tumblr) .'" class="icon-fa-tumblr" '. $link_window .'><i class="fa fa-tumblr"></i></a></li>';
    }

    $output = '<div class="team-member '. $extra_class .'">'. $team_image .'<div class="member-info"><h4 class="team-name" style="'. $name_color . $name_size .'">'. $team_name .'</h4><h5 class="team-profession" style="'. $profession_color . $profession_size .'">'. $team_profession .'</h5></div><div id="'. $own_id .'" class="zoom-anim-dialog mfp-hide"><div class="team-popup-image">'. $team_image .'</div><div class="team-popup-content"><h2 style="'. $name_color . $name_size .'">'. $team_name .'</h2><h3 style="'. $profession_color . $profession_size .'">'. $team_profession .'</h3><p style="'. $content_color . $content_size .'">'. $team_content .'</p><ul class="social-media icon-colors">'. $social_facebook . $social_twitter . $social_linkedin . $social_google . $social_dribbble . $social_youtube . $social_vimeo . $social_skype . $social_rss . $social_pinterest . $social_flickr . $social_foursquare . $social_android . $social_bitbucket . $social_css3 . $social_dropbox . $social_github . $social_html5 . $social_instagram . $social_stack_exchange . $social_stack_overflow . $social_trello . $social_tumblr .'</ul></div><div class="clearfix"></div></div></div>';

    return $output;

  }
}
add_shortcode( 'team', 'nany_team' );


/**
  Add to visual composer
**/
add_action( 'init', 'nany_team_vc_map' );
if ( ! function_exists( 'nany_team_vc_map' ) ) {
  function nany_team_vc_map() {
    vc_map( array(
        "name" =>"Team",
        "base" => "team",
        "description" => "Team Member",
        "icon" => "vc-team",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
              "type"=>'attach_image',
              "heading"=>__('Image', 'nany'),
              "param_name"=> "team_image",
              "value"=>"",
              "description" => __( "Upload your team member image. Should above 334x334.", 'nany')
            ),

            array(
              "type"=>'textfield',
              "heading"=>__('Name', 'nany'),
              "param_name"=> "team_name",
              "admin_label"=> true,
              "value"=> "Oliver Stone",
              "description" => __( "Enter your name.", 'nany')
            ),

            array(
              "type"=>'textfield',
              "heading"=>__('Profession', 'nany'),
              "param_name"=> "team_profession",
              "value"=> "Founder",
              "description" => __( "Enter this member profession here.", 'nany')
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

            /* ==============================================
               Design
            =============================================== */
            array(
                "type" => "colorpicker",
                "heading" => __( "Name Color", 'nany' ),
                "param_name" => "name_color",
                'value'=>'',
                "description" => __( "Pick name color", 'nany'),
                "group" => __( "Design", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Name Font Size", 'nany' ),
                "param_name" => "name_size",
                'value'=>'',
                "description" => __( "Enter name font size in px. [Eg : 18px]", 'nany'),
                "group" => __( "Design", 'nany')
            ),
            array(
                "type" => "colorpicker",
                "heading" => __( "Profession Color", 'nany' ),
                "param_name" => "profession_color",
                'value'=>'',
                "description" => __( "Pick profession color", 'nany'),
                "group" => __( "Design", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Profession Font Size", 'nany' ),
                "param_name" => "profession_size",
                'value'=>'',
                "description" => __( "Enter profession font size in px. [Eg : 14px]", 'nany'),
                "group" => __( "Design", 'nany')
            ),
            array(
                "type" => "colorpicker",
                "heading" => __( "Content Color", 'nany' ),
                "param_name" => "content_color",
                'value'=>'',
                "description" => __( "Pick content color", 'nany'),
                "group" => __( "Design", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Content Font Size", 'nany' ),
                "param_name" => "content_size",
                'value'=>'',
                "description" => __( "Enter content font size in px. [Eg : 13px]", 'nany'),
                "group" => __( "Design", 'nany')
            ),

            /* ==============================================
               Social Media Icons
            =============================================== */
            array(
              "type"=>'checkbox',
              "heading"=>__('Links open in new window?', 'nany'),
              "param_name"=> "link_window",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need to open all links in new window check this.", 'nany'),
              "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Facebook", 'nany' ),
                "param_name" => "social_facebook",
                'value'=>'',
                "description" => __( "Enter your facebook profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Twitter", 'nany' ),
                "param_name" => "social_twitter",
                'value'=>'',
                "description" => __( "Enter your twitter profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Linkedin", 'nany' ),
                "param_name" => "social_linkedin",
                'value'=>'',
                "description" => __( "Enter your linkedin profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Google Plus", 'nany' ),
                "param_name" => "social_google",
                'value'=>'',
                "description" => __( "Enter your google profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Dribbble", 'nany' ),
                "param_name" => "social_dribbble",
                'value'=>'',
                "description" => __( "Enter your dribbble profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "YouTube", 'nany' ),
                "param_name" => "social_youtube",
                'value'=>'',
                "description" => __( "Enter your youtube profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Vimeo", 'nany' ),
                "param_name" => "social_vimeo",
                'value'=>'',
                "description" => __( "Enter your vimeo profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Skype", 'nany' ),
                "param_name" => "social_skype",
                'value'=>'',
                "description" => __( "Enter your skype profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Rss", 'nany' ),
                "param_name" => "social_rss",
                'value'=>'',
                "description" => __( "Enter your rss profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Pinterest", 'nany' ),
                "param_name" => "social_pinterest",
                'value'=>'',
                "description" => __( "Enter your pinterest profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Flickr", 'nany' ),
                "param_name" => "social_flickr",
                'value'=>'',
                "description" => __( "Enter your flickr profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Foursquare", 'nany' ),
                "param_name" => "social_foursquare",
                'value'=>'',
                "description" => __( "Enter your foursquare profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Android", 'nany' ),
                "param_name" => "social_android",
                'value'=>'',
                "description" => __( "Enter your android profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Bitbucket", 'nany' ),
                "param_name" => "social_bitbucket",
                'value'=>'',
                "description" => __( "Enter your bitbucket profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "CSS3", 'nany' ),
                "param_name" => "social_css3",
                'value'=>'',
                "description" => __( "Enter your css3 profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Dropbox", 'nany' ),
                "param_name" => "social_dropbox",
                'value'=>'',
                "description" => __( "Enter your dropbox profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Github", 'nany' ),
                "param_name" => "social_github",
                'value'=>'',
                "description" => __( "Enter your github profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "HTML5", 'nany' ),
                "param_name" => "social_html5",
                'value'=>'',
                "description" => __( "Enter your html5 profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Instagram", 'nany' ),
                "param_name" => "social_instagram",
                'value'=>'',
                "description" => __( "Enter your instagram profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Stackexchange", 'nany' ),
                "param_name" => "social_stack_exchange",
                'value'=>'',
                "description" => __( "Enter your stackexchange profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Stack Overflow", 'nany' ),
                "param_name" => "social_stack_overflow",
                'value'=>'',
                "description" => __( "Enter your stack overflow profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Trello", 'nany' ),
                "param_name" => "social_trello",
                'value'=>'',
                "description" => __( "Enter your trello profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Tumblr", 'nany' ),
                "param_name" => "social_tumblr",
                'value'=>'',
                "description" => __( "Enter your tumblr profile url.", 'nany'),
                "group" => __( "Social Media", 'nany')
            ),

            /* ==============================================
               Button
            =============================================== */
            array(
                "type" => "href",
                "heading" => __( "Button Link", 'nany' ),
                "param_name" => "button_link",
                'value'=>'',
                "description" => __( "Enter button link. Note if you need Popup details this will be hide.", 'nany'),
                 "group" => __( "Button", 'nany'),
                'dependency'  => Array(
                                  'element' => "pop_details",
                                  'value'   => array( 'no' ),
                                ),
            ),

            array(
              "type"=>'checkbox',
              "heading"=>__('Link open in new window?', 'nany'),
              "param_name"=> "open_window",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need to open link in new window, check this.", 'nany'),
               "group" => __( "Button", 'nany'),
                'dependency'  => Array(
                                  'element' => "pop_details",
                                  'value'   => array( 'no' ),
                                ),
            ),


            /* ==============================================
               Popup Details
            =============================================== */
            array(
              "type"=>'dropdown',
              "heading"=>__('Need Popup Details?', 'nany'),
              "param_name"=> "pop_details",
              "value" => array(
                            "No"=>'no',
                            "Yes"=>'yes'
                          ),
              "description" => __( "If you need popup details select yes.", 'nany'),
              "group" => __( "Popup", 'nany')
            ),
            array(
                "type" => "textarea",
                "heading" => __( "Content", 'nany' ),
                "param_name" => "team_content",
                'value'=>'',
                "description" => __( "Enter your team member content.", 'nany'),
                "group" => __( "Popup", 'nany'),
                'dependency'  => Array(
                                  'element' => "pop_details",
                                  'value'   => array( 'yes' ),
                                ),
            ),


          )
    ) );
  }
}


?>