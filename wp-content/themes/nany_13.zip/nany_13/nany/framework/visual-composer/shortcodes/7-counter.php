<?php

/* ==========================================================
    Visual Composer - counter
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_counter')) {
  function nany_counter( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'counter_icon'  => '',
      'counter_number'  => '',
      'counter_value_in'  => '',
      'counter_title'  => '',
      'right_border'   => '',
      'icon_color'   => '',
      'number_color'   => '',
      'text_color'   => '',
      'extra_class'  => ''
    ), $atts));


    if ( $right_border === 'yes' ) {
      $right_border = 'right-border';
    }
    if ( $icon_color ) {
      $icon_color = 'color:'. $icon_color .';';
    }
    if ( $number_color ) {
      $number_color = 'color:'. $number_color .';';
    }
    if ( $text_color ) {
      $text_color = 'color:'. $text_color .';';
    }

    $output = '<div class="counter-wrap '. $extra_class .' '. $right_border .'"><div class="counter-icon"><i class="fa '. $counter_icon .'" style="'. $icon_color .'"></i></div><div class="counter"><span class="counter-letters" style="'. $number_color .'">'. $counter_number .'</span><span class="valuein" style="'. $number_color .'"> '. $counter_value_in .'</span><p style="'. $text_color .'">'. $counter_title .'</p></div></div>';

    wp_enqueue_script('counterup-scripts', SCRIPTS . '/jquery.counterup.min.js', array('jquery'), '', true);

    return $output;

  }
}
add_shortcode( 'counter', 'nany_counter' );


/**
  Add to visual composer
**/
add_action( 'init', 'nany_counter_vc_map' );
if ( ! function_exists( 'nany_counter_vc_map' ) ) {
  function nany_counter_vc_map() {
    vc_map( array(
        "name" =>"Counter",
        "base" => "counter",
        "description" => "Counter Styles",
        "icon" => "vc-counter",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
              "type"=>'textfield',
              "heading"=>__('Counter Icon', 'nany'),
              "param_name"=> "counter_icon",
              "value"=>"fa-heart",
              "description" => __( "Select icon from <a href='http://fortawesome.github.io/Font-Awesome/cheatsheet/' target='_blank'>FontAwesome</a> lib. (Eg : fa-heart)", 'nany')
            ),

            array(
              "type"=>'textfield',
              "heading"=>__('Number', 'nany'),
              "param_name"=> "counter_number",
              "value"=> "99",
              "description" => __( "This should only in numerics.", 'nany')
            ),

            array(
              "type"=>'textfield',
              "heading"=>__('Value In', 'nany'),
              "param_name"=> "counter_value_in",
              "value"=> "",
              "description" => __( "Enter your value in. [Eg : %]", 'nany')
            ),

            array(
              "type"=>'textfield',
              "heading"=>__('Title', 'nany'),
              "param_name"=> "counter_title",
              "admin_label" => true,
              "value"=> "Customer Satisfaction",
              "description" => __( "Enter your counter title.", 'nany')
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),


            array(
              "type"=>'checkbox',
              "heading"=>__('Do you need right border?', 'nany'),
              "param_name"=> "right_border",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need right border check this.", 'nany'),
              "group" => __( "Design", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Icon Color', 'nany'),
              "param_name"=> "icon_color",
              "value"=>"",
              "description" => __( "Select icon color for your counter.", 'nany'),
              "group" => __( "Design", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Number Color', 'nany'),
              "param_name"=> "number_color",
              "value"=>"",
              "description" => __( "Select number color for your counter.", 'nany'),
              "group" => __( "Design", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Text Color', 'nany'),
              "param_name"=> "text_color",
              "value"=>"",
              "description" => __( "Select text color for your counter.", 'nany'),
              "group" => __( "Design", 'nany')
            ),

          )
    ) );
  }
}


?>