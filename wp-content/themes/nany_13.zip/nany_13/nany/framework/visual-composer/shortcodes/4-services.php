<?php

/* ==========================================================
    Visual Composer - Services
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_service')) {
  function nany_service( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'service_style'  => '',
      'background_color'  => '',
      'service_icon'  => '',
      'icon_style'  => '',
      'service_heading'  => '',
      'service_content'  => '',
      'list_features'  => '',
      'extra_class'  => '',

      /* Design */
      'content_color'  => '',
      'border_color'  => '',
      'heading_size'  => '',
      'heading_line_height'  => '',
      'icon_line_height'  => '',
      'content_size'  => '',
      'content_line_height'  => '',
      'hide_bottom_shadow'  => '',
      'heading_color'  => '',
      'two_content_color'  => '',

      /* Button */
      'button_code'  => '',
      'button_text'  => '',
      'button_link'  => '',
      'open_window'  => '',
      'button_style'  => '',
      'button_size'  => '',
      'bg_color'  => '',
      'text_color'  => '',
      'text_transform'  => '',
      'btn_top_space'  => '',
      'btn_bottom_space'  => '',

      /* Spacing */
      'outer_top_bottom_space'  => '',
      'outer_right_left_space'  => '',
      'inner_top_bottom_space'  => '',
      'inner_right_left_space'  => ''

    ), $atts));

    if ($content_color) {
      $border_color = 'border-color:'. $content_color .';';
      $content_color = 'color:'. $content_color .';';
    }
    if ($two_content_color) {
      $two_content_color = 'color:'. $two_content_color .';';
    }
    if ($heading_color) {
      $heading_color = 'color:'. $heading_color .';';
    }
    if ($background_color) {
      $background_color = 'background-color:'. $background_color .';';
    }

    /* Design */
    if ($heading_size) {
      $heading_size = 'font-size:'. $heading_size .';';
    }
    if ($heading_line_height) {
      $heading_line_height = 'line-height:'. $heading_line_height .';';
    }
    if ($icon_line_height) {
      $icon_line_height = 'line-height:'. $icon_line_height .';';
    }
    if ($content_size) {
      $content_size = 'font-size:'. $content_size .';';
    }
    if ($content_line_height) {
      $content_line_height = 'line-height:'. $content_line_height .';';
    }
    if ($hide_bottom_shadow === 'yes') {
      $hide_bottom_shadow = ' hide-bottom-shadow';
    }

    /* General */
    if ($service_style === 'style-1') {
      if ($service_icon) {
        $service_icon = '<span class="service-icon '. $icon_style .'" style="'. $border_color . $icon_line_height .'"><i class="fa '. $service_icon .'"></i></span>';
      }
    } else {
      if ($service_icon) {
        $service_icon = '<div class="service-icon-outer"><span class="service-icon '. $icon_style . $hide_bottom_shadow .'" style="'. $background_color .'"><i class="fa '. $service_icon .'"></i></span></div>';
      }
    }
    if ($service_heading) {
      $service_heading = '<h2 style="'. $content_color . $heading_size . $heading_line_height . $heading_color .'">'. $service_heading .'</h2>';
    }
    if ($service_content) {
      $service_content = '<p style="'. $content_color . $content_size . $content_line_height . $two_content_color .'">'. $service_content .'</p>';
    }
    if ($list_features) {
      $list_features = '<ul class="service-features-list" style="'. $content_color .'"><li>'.str_replace("\n","</li><li class='small-dotline'></li><li>",trim($list_features,"")).'</li></ul>';
    }

    /* Button */
    if ( $open_window ) {
      $open_window = 'target="_blank"';
    }
    if ( $button_size ) {
      $button_size = $button_size;
    }
    if ( $button_style === 'btn-style-one' ) {
       $bg_color = 'background-color:'. $bg_color .';';
    }
    if ( $button_style === 'btn-style-three' ) {
       $bg_color = 'background-color:'. $bg_color .';';
    }
    if ( $button_style === 'btn-style-five' ) {
       $bg_color = 'background-color:'. $bg_color .';';
    }
    if ( $button_style === 'btn-style-two' ) {
       $bg_color = 'border-color:'. $bg_color .';';
    }
    if ( $button_style === 'btn-style-four' ) {
       $bg_color = 'border-color:'. $bg_color .';';
    }
    if ( $text_color ) {
      $text_color = 'color:'. $text_color .';';
    }
    if ( $text_transform ) {
      $text_transform = 'text-transform:'. $text_transform .';';
    }
    if ( $btn_top_space ) {
      $btn_top_space = 'margin-top:'. $btn_top_space .' !important;';
    }
    if ( $btn_bottom_space ) {
      $btn_bottom_space = 'margin-bottom:'. $btn_bottom_space .' !important;';
    }
    if ( $button_link ) {
      $button_code = '<div class="smooth-scroll-btn service-button"><a href="'. esc_url($button_link) .'" '. $open_window .' class="'. $button_style .' '. $button_size .' '. $extra_class .'" style="'. $bg_color . $text_color . $text_transform . $btn_top_space . $btn_bottom_space .'">'. $button_text .'</a></div>';
    } else {
      $button_code = '';
    }

    /* Spacing */
    if ($outer_top_bottom_space) {
      $outer_top_bottom_space = 'margin-top:'. $outer_top_bottom_space .';margin-bottom:'. $outer_top_bottom_space .';';
    }
    if ($outer_right_left_space) {
      $outer_right_left_space = 'margin-right:'. $outer_right_left_space .';margin-left:'. $outer_right_left_space .';';
    }
    if ($inner_top_bottom_space) {
      $inner_top_bottom_space = 'padding-top:'. $inner_top_bottom_space .';padding-bottom:'. $inner_top_bottom_space .';';
    }
    if ($inner_right_left_space) {
      $inner_right_left_space = 'padding-right:'. $inner_right_left_space .';padding-left:'. $inner_right_left_space .';';
    }

    /* Service Style One */
    if ( $service_style === 'style-1' ) {
      $service = '<div class="av-service service-style-one '. $extra_class .'" style="'. $background_color . $inner_right_left_space . $inner_top_bottom_space . $outer_right_left_space . $outer_top_bottom_space . $content_color .'">'. $service_icon . $service_heading . $service_content . $list_features . $button_code .'</div>';
    }

    /* Service Style Two */
    if ( $service_style === 'style-2' ) {
      $service = '<div class="service-style-two clearfix '. $extra_class .'" style="'. $outer_top_bottom_space . $content_color .'">'. $service_icon . '<div class="service-two-content">'. $service_heading . $service_content .'</div></div>';
    }

    return $service;

  }
}
add_shortcode( 'service', 'nany_service' );


/**
  Add to visual composer
**/
add_action( 'init', 'nany_service_vc_map' );
if ( ! function_exists( 'nany_service_vc_map' ) ) {
  function nany_service_vc_map() {
    vc_map( array(
        "name" =>"Service",
        "base" => "service",
        "description" => "Service Styles",
        "icon" => "vc-services",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "dropdown",
                "heading" => __( "Services Style", 'nany' ),
                "param_name" => "service_style",
                "value" => array(
                            "Style One"=>'style-1',
                            "Style Two"=>'style-2'
                          ),
                "description" => __( "Select Services Style", 'nany')
            ),
            array(
                "type" => "colorpicker",
                "heading" => __( "Background Color", 'nany' ),
                "param_name" => "background_color",
                'value'=> '#fbb02c',
                "description" => __( "Enter this service background color.", 'nany')
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Service Icon", 'nany' ),
                "param_name" => "service_icon",
                'value'=>'fa-heart',
                "description" => __( "Select icon from <a href='http://fortawesome.github.io/Font-Awesome/cheatsheet/' target='_blank'>FontAwesome</a> lib. (Eg : fa-heart)", 'nany'),
            ),

            array(
                "type" => "dropdown",
                "heading" => __( "Icon Style", 'nany' ),
                "param_name" => "icon_style",
                "value" => array(
                            "Rounded"=>'icon-rounded',
                            "Square"=>'icon-square'
                          ),
                "description" => __( "Icon Style for this service.", 'nany'),
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Service Heading", 'nany' ),
                "param_name" => "service_heading",
                'value'=>'My Service',
                "admin_label" => true,
                "description" => __( "Enter Services heading", 'nany')
            ),

            array(
                "type" => "textarea",
                "heading" => __( "Service Content", 'nany' ),
                "param_name" => "service_content",
                'value'=> __( "Modern & Unique Design WordPress Theme. The Unique Style is getting more popular, so show yourself from the best side!", 'nany' ),
                "description" => __( "Enter some service content here.", 'nany'),
            ),

            array(
              "type"=>'textarea',
              "heading"=>__('List of Features', 'nany'),
              "param_name"=> "list_features",
              "value"=> "",
              "description" => __( "New line as a new list feature.", 'nany'),
              'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-1' ),
                                ),
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

            /* Design Group */
            array(
                "type" => "colorpicker",
                "heading" => __( "All Content Color", 'nany' ),
                "param_name" => "content_color",
                'value'=>'',
                "description" => __( "Enter this service content color. Inclding : icon, heading, content, lists.", 'nany'),
                "group" => __( "Design", 'nany'),
                'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-1' ),
                                ),
            ),
            array(
                "type" => "colorpicker",
                "heading" => __( "Heading Color", 'nany' ),
                "param_name" => "heading_color",
                'value'=>'',
                "description" => __( "Enter this service heading color.", 'nany'),
                "group" => __( "Design", 'nany'),
                'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-2' ),
                                ),
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Icon Line Height", 'nany' ),
                "param_name" => "icon_line_height",
                'value'=>'',
                "description" => __( "Enter icon line height in px. (Eg : 22px)", 'nany'),
                "group" => __( "Design", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Heading Size", 'nany' ),
                "param_name" => "heading_size",
                'value'=>'',
                "description" => __( "Enter heading size in px. (Eg : 22px)", 'nany'),
                "group" => __( "Design", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Heading Line Height", 'nany' ),
                "param_name" => "heading_line_height",
                'value'=>'',
                "description" => __( "Enter heading line height in px. (Eg : 22px)", 'nany'),
                "group" => __( "Design", 'nany')
            ),
            array(
                "type" => "colorpicker",
                "heading" => __( "Content Color", 'nany' ),
                "param_name" => "two_content_color",
                'value'=>'',
                "description" => __( "Enter this service content color.", 'nany'),
                "group" => __( "Design", 'nany'),
                'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-2' ),
                                ),
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Content Size", 'nany' ),
                "param_name" => "content_size",
                'value'=>'',
                "description" => __( "Enter content size in px. (Eg : 16px)", 'nany'),
                "group" => __( "Design", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Content Line Height", 'nany' ),
                "param_name" => "content_line_height",
                'value'=>'',
                "description" => __( "Enter content line height in px. (Eg : 16px)", 'nany'),
                "group" => __( "Design", 'nany')
            ),
            array(
              "type"=>'checkbox',
              "heading"=>__('Hide Bottom Shadow', 'nany'),
              "param_name"=> "hide_bottom_shadow",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need to hide icon bottom shadow, check this.", 'nany'),
              'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-2' ),
                                ),
              "group" => __( "Design", 'nany')
            ),

            /* Button */
            array(
                "type" => "notification_info", // This is nany's Own Custom Param.
                "heading" => __( "", 'nany' ),
                "param_name" => "service_two_button",
                'value'=>'',
                "description" => __( "Service Style 2 not having option for button.", 'nany'),
                "group" => __( "Button", 'nany'),
                'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-2' ),
                                ),
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Button Text", 'nany' ),
                "param_name" => "button_text",
                'value'=>'My Button',
                "description" => __( "Enter button text", 'nany'),
                 "group" => __( "Button", 'nany'),
                 'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-1' ),
                                ),
            ),

            array(
                "type" => "href",
                "heading" => __( "Button Link", 'nany' ),
                "param_name" => "button_link",
                'value'=>'',
                "description" => __( "Enter button link", 'nany'),
                 "group" => __( "Button", 'nany'),
                 'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-1' ),
                                ),
            ),

            array(
              "type"=>'checkbox',
              "heading"=>__('Link open in new window?', 'nany'),
              "param_name"=> "open_window",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need to open link in new window, check this.", 'nany'),
               "group" => __( "Button", 'nany'),
                 'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-1' ),
                                ),
            ),

            array(
                "type" => "dropdown",
                "heading" => __( "Button Style", 'nany' ),
                "param_name" => "button_style",
                "value" => array(
                            "Style One"=>'btn-style-one',
                            "Style Two"=>'btn-style-two',
                            "Style Three"=>'btn-style-three',
                            "Style Four"=>'btn-style-four',
                            "Style Five"=>'btn-style-five'
                          ),
                "description" => __( "Select Button Style", 'nany'),
                 "group" => __( "Button", 'nany'),
                 'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-1' ),
                                ),
            ),

            array(
                "type" => "dropdown",
                "heading" => __( "Button Size", 'nany' ),
                "param_name" => "button_size",
                "value" => array(
                            "Small"=>'small-btn',
                            "Medium"=>'medium-btn',
                            "Large"=>'large-btn'
                          ),
                "description" => __( "Select Button Size", 'nany'),
                 "group" => __( "Button", 'nany'),
                 'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-1' ),
                                ),
            ),

            array(
              "type"=>'colorpicker',
              "heading"=>__('Background color', 'nany'),
              "param_name"=> "bg_color",
              "value"=>"#497bb8",
              "description" => __( "Select background color for button.", 'nany'),
               "group" => __( "Button", 'nany'),
                 'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-1' ),
                                ),
            ),

            array(
              "type"=>'colorpicker',
              "heading"=>__('Text color', 'nany'),
              "param_name"=> "text_color",
              "value"=>"#ffffff",
              "description" => __( "Select text color for button.", 'nany'),
               "group" => __( "Button", 'nany'),
                 'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-1' ),
                                ),
            ),

            array(
                "type" => "dropdown",
                "heading" => __( "Text Transform", 'nany' ),
                "param_name" => "text_transform",
                "value" => array(
                            "Normal"=>'none',
                            "Uppercase"=>'uppercase',
                            "Capitalize"=>'capitalize',
                            "Lowercase"=>'lowercase'
                          ),
                "description" => __( "Select button text transform.", 'nany'),
                 "group" => __( "Button", 'nany'),
                 'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-1' ),
                                ),
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Top Space", 'nany' ),
                "param_name" => "btn_top_space",
                'value'=>'',
                "description" => __( "Button Top Space", 'nany'),
                 "group" => __( "Button", 'nany'),
                 'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-1' ),
                                ),
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Bottom Space", 'nany' ),
                "param_name" => "btn_bottom_space",
                'value'=>'',
                "description" => __( "Button Bottom Space", 'nany'),
                 "group" => __( "Button", 'nany'),
                 'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-1' ),
                                ),
            ),

            /* Spacing */
            array(
                "type" => "textfield",
                "heading" => __( "Outer Top & Bottom Space", 'nany' ),
                "param_name" => "outer_top_bottom_space",
                'value'=>'',
                "description" => __( "Service Top & Bottom Space", 'nany'),
                "group" => __( "Spacing", 'nany'),
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Outer Rigth & Left Space", 'nany' ),
                "param_name" => "outer_right_left_space",
                'value'=>'',
                "description" => __( "Service Right & Left Space", 'nany'),
                "group" => __( "Spacing", 'nany'),
                 'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-1' ),
                                ),
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Inner Top & Bottom Space", 'nany' ),
                "param_name" => "inner_top_bottom_space",
                'value'=>'',
                "description" => __( "Service Top & Bottom Space", 'nany'),
                "group" => __( "Spacing", 'nany'),
                 'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-1' ),
                                ),
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Inner Rigth & Left Space", 'nany' ),
                "param_name" => "inner_right_left_space",
                'value'=>'',
                "description" => __( "Service Right & Left Space", 'nany'),
                "group" => __( "Spacing", 'nany'),
                 'dependency'  => Array(
                                  'element' => "service_style",
                                  'value'   => array( 'style-1' ),
                                ),
            ),

          )
    ) );
  }
}


?>