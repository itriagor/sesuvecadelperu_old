<?php

/* ==========================================================
    Visual Composer - alert
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_alert')) {
  function nany_alert( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'alert_text'  => '',
      'alert_type'  => '',
      'alert_type_icon'  => '',
      'rounded_corners'  => '',
      'close_button'   => '',
      'have_close_button'   => '',
      'extra_class'  => ''
    ), $atts));

    if ( $close_button == 'yes' ) {
      $close_button = '<a class="toggle-alert" href="#"><i class="fa fa-times"></i></a>';
      $have_close_button = ' have-close-button';
    }

    if ( $alert_type == 'alert-success' ) {
      $alert_type_icon = '<span class="alert-icon '. $alert_type .'"><i class="fa fa-check-circle"></i></span>';
    }
    if ( $alert_type == 'alert-info' ) {
      $alert_type_icon = '<span class="alert-icon '. $alert_type .'"><i class="fa fa-info-circle"></i></span>';
    }
    if ( $alert_type == 'alert-danger' ) {
      $alert_type_icon = '<span class="alert-icon '. $alert_type .'"><i class="fa fa-times-circle"></i></span>';
    }
    if ( $alert_type == 'alert-warning' ) {
      $alert_type_icon = '<span class="alert-icon '. $alert_type .'"><i class="fa fa-exclamation-triangle"></i></span>';
    }

    $output = '<label class="alert '. $alert_type .' '. $rounded_corners .' '. $extra_class .'">'. $alert_type_icon .'<span class="alert-content'. $have_close_button .'">' . do_shortcode( $alert_text ) . '</span>'. $close_button .'</label>';

    return $output;

  }
}
add_shortcode( 'av_alert', 'nany_alert' );


/**
  Add to visual composer
**/
add_action( 'init', 'nany_alert_vc_map' );
if ( ! function_exists( 'nany_alert_vc_map' ) ) {
  function nany_alert_vc_map() {
    vc_map( array(
        "name" =>"Alert",
        "base" => "av_alert",
        "description" => "Alert Styles",
        "icon" => "vc-alert",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "dropdown",
                "heading" => __( "Alert Type", 'nany' ),
                "param_name" => "alert_type",
                "value" => array(
                            "Success"=>'alert-success',
                            "Danger"=>'alert-danger',
                            "Warning"=>'alert-warning',
                            "Info"=>'alert-info'
                          ),
                "description" => __( "Select alert type.", 'nany')
            ),

            array(
              "type"=>'textarea',
              "heading"=>__('Text', 'nany'),
              "param_name"=> "alert_text",
              "value"=>"I am alert box. Click edit button to change this text.",
              "description" => __( "Enter your alert text.", 'nany'),
               "admin_label" => true,
            ),

            array(
              "type"=>'checkbox',
              "heading"=>__('Need rounded type?', 'nany'),
              "param_name"=> "rounded_corners",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'rounded'
              ),
              "description" => __( "If you need to rounded corner please check this.", 'nany')
            ),

            array(
              "type"=>'checkbox',
              "heading"=>__('Need close button?', 'nany'),
              "param_name"=> "close_button",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need to close button check this.", 'nany')
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),
          )
    ) );
  }
}


?>