<?php

/* ==========================================================
    Visual Composer - Buttons
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_button')) {
  function nany_button( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'button_text'  => 'Button Text',
      'button_link'   => '',
      'smooth_scroll'  => '',
      'open_window'  => '',
      'button_style'  => '',
      'button_size'   => '',
      'bg_color'   => '',
      'text_color'   => '',
      'text_transform'   => '',
      'button_position'   => '',
      'outer_top_space'   => '',
      'outer_bottom_space'   => '',
      'inner_top_bottom_space'  => '',
      'inner_right_left_space'  => '',
      'class'  => '',
      'smooth_scroll_before'  => '',
      'smooth_scroll_after'  => '',
      'button_center'  => ''
    ), $atts));

    if ( $button_link ) {
      $button_link = 'href="'. esc_url($button_link) .'"';
    }
    if ( $open_window === 'yes' ) {
      $open_window = 'target="_blank"';
    }
    if ( $button_size ) {
      $button_size = $button_size;
    }
    if ( $button_style === 'btn-style-one' ) {
       $bg_color = 'background-color:'. $bg_color .';';
    }
    if ( $button_style === 'btn-style-three' ) {
       $bg_color = 'background-color:'. $bg_color .';';
    }
    if ( $button_style === 'btn-style-five' ) {
       $bg_color = 'background-color:'. $bg_color .';';
    }
    if ( $button_style === 'btn-style-two' ) {
       $bg_color = 'border-color:'. $bg_color .';';
    }
    if ( $button_style === 'btn-style-four' ) {
       $bg_color = 'border-color:'. $bg_color .';';
    }
    if ( $text_color ) {
      $text_color = 'color:'. $text_color .';';
    }
    if ( $text_transform ) {
      $text_transform = 'text-transform:'. $text_transform .';';
    }
    if ( $button_position === 'left' || $button_position === 'right' ) {
      $button_position = 'float:'. $button_position .';';
    } else {
      $button_center = 'text-center';
      $button_position = '';
    }
    if ( $outer_top_space ) {
      $outer_top_space = 'margin-top:'. $outer_top_space .';';
    }
    if ( $outer_bottom_space ) {
      $outer_bottom_space = 'margin-bottom:'. $outer_bottom_space .';';
    }
    if ( $inner_top_bottom_space ) {
      $inner_top_bottom_space = 'padding-top:'. $inner_top_bottom_space .';padding-bottom:'. $inner_top_bottom_space .';';
    }
    if ( $inner_right_left_space ) {
      $inner_right_left_space = 'padding-right:'. $inner_right_left_space .';padding-left:'. $inner_right_left_space .';';
    }
    if($smooth_scroll) {
        $smooth_scroll = 'smooth-scroll-btn';
    }

    $output = '<div class="'. $smooth_scroll . ' '. $button_center .'"><a '. $button_link .' '. $open_window .' class="'. $button_style .' '. $button_size .' '. $class .'" style="'. $bg_color . $text_color . $text_transform . $outer_top_space . $outer_bottom_space . $button_position . $inner_right_left_space . $inner_top_bottom_space .'">'. $button_text .'</a></div>';

    return $output;

  }
}
add_shortcode( 'button', 'nany_button' );


/**
  Add to visual composer
**/
add_action( 'init', 'nany_button_vc_map' );
if ( ! function_exists( 'nany_button_vc_map' ) ) {
  function nany_button_vc_map() {
    vc_map( array(
        "name" =>"Button",
        "base" => "button",
        "description" => "Catchy Buttons",
        "icon" => "icon-wpb-ui-button",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
                "type" => "textfield",
                "heading" => __( "Button Text", 'nany' ),
                "param_name" => "button_text",
                'value'=>'My Button',
                "admin_label" => true,
                "description" => __( "Enter button text", 'nany')
            ),

            array(
              "type"=>'checkbox',
              "heading"=>__('Need Smooth Scroll?', 'nany'),
              "param_name"=> "smooth_scroll",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need smooth scroll within this page, check this.", 'nany')
            ),

            array(
                "type" => "href",
                "heading" => __( "Button Link", 'nany' ),
                "param_name" => "button_link",
                'value'=>'',
                "description" => __( "Enter button link, if you check smooth scroll just use section id here. Eg : #contact", 'nany')
            ),

            array(
              "type"=>'checkbox',
              "heading"=>__('Link open in new window?', 'nany'),
              "param_name"=> "open_window",
              'value'     => Array(
                __( 'Yes please.', 'nany' ) => 'yes'
              ),
              "description" => __( "If you need to open link in new window, check this.", 'nany')
            ),

            array(
                "type" => "dropdown",
                "heading" => __( "Button Style", 'nany' ),
                "param_name" => "button_style",
                "value" => array(
                            "Style One"=>'btn-style-one',
                            "Style Two"=>'btn-style-two',
                            "Style Three"=>'btn-style-three',
                            "Style Four"=>'btn-style-four',
                            "Style Five"=>'btn-style-five'
                          ),
                "description" => __( "Select Button Style", 'nany'),
                "group" => __( "Style", 'nany')
            ),

            array(
                "type" => "dropdown",
                "heading" => __( "Button Size", 'nany' ),
                "param_name" => "button_size",
                "value" => array(
                            "Small"=>'small-btn',
                            "Medium"=>'medium-btn',
                            "Large"=>'large-btn'
                          ),
                "description" => __( "Select Button Size", 'nany'),
                "group" => __( "Style", 'nany')
            ),

            array(
              "type"=>'colorpicker',
              "heading"=>__('Background color', 'nany'),
              "param_name"=> "bg_color",
              "value"=>"#497bb8",
              "description" => __( "Select background color for button.", 'nany'),
                "group" => __( "Style", 'nany')
            ),

            array(
              "type"=>'colorpicker',
              "heading"=>__('Text color', 'nany'),
              "param_name"=> "text_color",
              "value"=>"#ffffff",
              "description" => __( "Select text color for button.", 'nany'),
                "group" => __( "Style", 'nany')
            ),

            array(
                "type" => "dropdown",
                "heading" => __( "Text Transform", 'nany' ),
                "param_name" => "text_transform",
                "value" => array(
                            "Normal"=>'none',
                            "Uppercase"=>'uppercase',
                            "Capitalize"=>'capitalize',
                            "Lowercase"=>'lowercase'
                          ),
                "description" => __( "Select button text transform.", 'nany'),
                "group" => __( "Style", 'nany')
            ),

            array(
                "type" => "dropdown",
                "heading" => __( "Button Position", 'nany' ),
                "param_name" => "button_position",
                "value" => array(
                            "Center" =>'center',
                            "Left" =>'left',
                            "Right" =>'right'
                          ),
                "description" => __( "If you need center button use the column settings.", 'nany'),
                "group" => __( "Style", 'nany')
            ),

            /* Spacing */
            array(
                "type" => "textfield",
                "heading" => __( "Inner Top & Bottom Space", 'nany' ),
                "param_name" => "inner_top_bottom_space",
                'value'=>'',
                "description" => __( "Button Inner Top & Bottom Space", 'nany'),
                "group" => __( "Spacing", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Inner Right & Left Space", 'nany' ),
                "param_name" => "inner_right_left_space",
                'value'=>'',
                "description" => __( "Button Inner Right & Left Space", 'nany'),
                "group" => __( "Spacing", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Outer Top Space", 'nany' ),
                "param_name" => "outer_top_space",
                'value'=>'',
                "description" => __( "Button Outer Top Space", 'nany'),
                "group" => __( "Spacing", 'nany')
            ),
            array(
                "type" => "textfield",
                "heading" => __( "Outer Bottom Space", 'nany' ),
                "param_name" => "outer_bottom_space",
                'value'=>'',
                "description" => __( "Button Outer Bottom Space", 'nany'),
                "group" => __( "Spacing", 'nany')
            ),

            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),

          )
    ) );
  }
}


?>