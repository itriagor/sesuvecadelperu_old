<?php

/* ==========================================================
    Visual Composer - Skillbar
=========================================================== */

/**
  Register Shortcode
**/
if ( !function_exists('nany_skillbar')) {
  function nany_skillbar( $atts, $content = NULL ) {

    extract(shortcode_atts(array(
      'skillbar_title'  => '',
      'skillbar_percentage'  => '',
      'skillbar_color'  => '',
      'border_color'  => '',
      'extra_class'  => ''
    ), $atts));

    $own_id = preg_replace('/[^a-z]/', "-", strtolower($skillbar_title));

    if ( $skillbar_color ) {
      $border_color = 'style="border-top-color:'. $skillbar_color .';"';
      $skillbar_color = 'style="background:'. $skillbar_color .';"';
    }

    $output = '<div class="skillbar '. $extra_class .'" data-percent="'. $skillbar_percentage .'%"><div class="skillbar-title"><span>'. $skillbar_title .'</span></div><div class="skillbar-bar" '. $skillbar_color .'><span class="percentage-text '. $own_id .'" '. $skillbar_color .'>'. $skillbar_percentage .'%<small class="skill-arrow" '. $border_color .'></small></span></div></div>';

    return $output;

  }
}
add_shortcode( 'skillbar', 'nany_skillbar' );

/**
  Add to visual composer
**/
add_action( 'init', 'nany_skillbar_vc_map' );
if ( ! function_exists( 'nany_skillbar_vc_map' ) ) {
  function nany_skillbar_vc_map() {
    vc_map( array(
        "name" =>"Skill Bar",
        "base" => "skillbar",
        "description" => "Skillbar Styles",
        "icon" => "vc-skillbar",
        "category" => __( 'Nany', 'nany' ),
        "params" => array(

            array(
              "type"=>'textfield',
              "heading"=>__('Title', 'nany'),
              "param_name"=> "skillbar_title",
              "value"=> "Photoshop",
              "admin_label"=> true,
              "description" => __( "Enter your skillbar title.", 'nany')
            ),
            array(
              "type"=>'textfield',
              "heading"=>__('Percentage', 'nany'),
              "param_name"=> "skillbar_percentage",
              "value"=> "85",
              "description" => __( "Enter your skillbar percentage. [Eg : 80]", 'nany')
            ),
            array(
              "type"=>'colorpicker',
              "heading"=>__('Bar Color', 'nany'),
              "param_name"=> "skillbar_color",
              "value"=>"",
              "description" => __( "Select bar color for your skillbar.", 'nany'),

            ),

            array(
                "type" => "textfield",
                "heading" => __( "Extra class name", 'nany' ),
                "param_name" => "extra_class",
                'value'=>'',
                "description" => __( "Custom styled class name", 'nany')
            ),
          )
    ) );
  }
}


?>