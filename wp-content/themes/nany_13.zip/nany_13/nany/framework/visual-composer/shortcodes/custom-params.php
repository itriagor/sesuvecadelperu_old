<?php

// Success
function custom_notification_success($settings, $value) {
   $dependency = vc_generate_dependencies_attributes($settings);
   return '<div class="notification_success">'. $settings['description'] . $dependency . '</div>'; // New button element
}
add_shortcode_param('notification_success', 'custom_notification_success');

// Info
function custom_notification_info($settings, $value) {
   $dependency = vc_generate_dependencies_attributes($settings);
   return '<div class="notification_info">'. $settings['description'] .'</div>'; // New button element
}
add_shortcode_param('notification_info', 'custom_notification_info');

// Error
function custom_notification_error($settings, $value) {
   $dependency = vc_generate_dependencies_attributes($settings);
   return '<div class="notification_error">'. $settings['description'] . $dependency . '</div>'; // New button element
}
add_shortcode_param('notification_error', 'custom_notification_error');

// Note
function custom_notification_note($settings, $value) {
   $dependency = vc_generate_dependencies_attributes($settings);
   return '<div class="notification_note">'. $settings['description'] .'</div>'; // New button element
}
add_shortcode_param('notification_note', 'custom_notification_note');

?>