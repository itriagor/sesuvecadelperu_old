<?php
/**
 * widget-get-touch.php
 *
 * Plugin Name: Get in Touch
 * Plugin URI: http://www.themeforest.net/user/defatch
 * Description: A widget that displays get in touch.
 * Version: 1.0
 * Author: Defatch
 * Author URI: http://www.themeforest.net/user/defatch
*/

class Nany_get_in_touch extends WP_Widget {

	/**
	 * Specifies the widget name, description, class name and instatiates it
	 */
	public function __construct() {
		parent::__construct(
			'widget-nany-get-touch',
			__( 'Nany: Get in Touch', 'nany' ),
			array(
				'classname'   => 'widget-nany-get-touch',
				'description' => __( 'A custom widget that displays get in touch.', 'nany' )
			)
		);
	}


	/**
	 * Generates the back-end layout for the widget
	 */
	public function form( $instance ) {
		// Default widget settings
		$defaults = array(
			'title'               => '',
			'address'             => '',
			'phone_num'           => '',
			'email'           	  => '',
			'textarea'   		  => '',
			'map_icon'   		  => '',
			'custom_class'        => ''
		);

		$instance = wp_parse_args( (array) $instance, $defaults );

		// The widget content ?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'nany' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $instance['title'] ); ?>">
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'address' ); ?>"><?php _e( 'Address:', 'nany' ); ?></label>
			<textarea cols="30" rows="3" class="widefat" id="<?php echo $this->get_field_id( 'address' ); ?>" name="<?php echo $this->get_field_name( 'address' ); ?>"><?php echo esc_textarea( $instance['address'] ); ?></textarea>
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'phone_num' ); ?>"><?php _e( 'Phone Number:', 'nany' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'phone_num' ); ?>" name="<?php echo $this->get_field_name( 'phone_num' ); ?>" value="<?php echo esc_attr( $instance['phone_num'] ); ?>">
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'email' ); ?>"><?php _e( 'Email:', 'nany' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'email' ); ?>" name="<?php echo $this->get_field_name( 'email' ); ?>" value="<?php echo esc_attr( $instance['email'] ); ?>">
		</p>

		<p>
			<label for="<?php echo $this->get_field_id( 'textarea' ); ?>"><?php _e( 'Text:', 'nany' ); ?></label>
			<textarea cols="30" rows="3" class="widefat" id="<?php echo $this->get_field_id( 'textarea' ); ?>" name="<?php echo $this->get_field_name( 'textarea' ); ?>"><?php echo esc_textarea( $instance['textarea'] ); ?></textarea>
		</p>

		<!-- The input (checkbox) -->
		<p>
            <input class="checkbox" type="checkbox" <?php checked($instance['map_icon'], 'on'); ?> id="<?php echo $this->get_field_id('map_icon'); ?>" name="<?php echo $this->get_field_name('map_icon'); ?>" />
            <label for="<?php echo $this->get_field_id('map_icon'); ?>"><?php _e( 'BG Map Icon?', 'nany' ); ?></label>
		</p>

		<!-- Custom Class -->
		<p>
			<label for="<?php echo $this->get_field_id( 'custom_class' ); ?>"><?php _e( 'Custom Class:', 'nany' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'custom_class' ); ?>" name="<?php echo $this->get_field_name( 'custom_class' ); ?>" value="<?php echo esc_attr( $instance['custom_class'] ); ?>">
		</p> <?php
	}


	/**
	 * Processes the widget's values
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		// Update values
		$instance['title']        = strip_tags( stripslashes( $new_instance['title'] ) );
		$instance['address']      = strip_tags( stripslashes( $new_instance['address'] ) );
		$instance['phone_num']    = strip_tags( stripslashes( $new_instance['phone_num'] ) );
		$instance['email']        = strip_tags( stripslashes( $new_instance['email'] ) );
		$instance['textarea']     = strip_tags( stripslashes( $new_instance['textarea'] ) );
		$instance['map_icon']     = strip_tags( stripslashes( $new_instance['map_icon'] ) );
		$instance['custom_class'] = strip_tags( stripslashes( $new_instance['custom_class'] ) );

		return $instance;
	}


	/**
	 * Output the contents of the widget
	 */
	public function widget( $args, $instance ) {
		// Extract the arguments
		extract( $args );

		$title          = apply_filters( 'widget_title', $instance['title'] );
		$address        = $instance['address'];
		$phone_num      = $instance['phone_num'];
		$email          = $instance['email'];
		$textarea       = $instance['textarea'];
		$map_icon       = $instance['map_icon'];
		$custom_class   = $instance['custom_class'];

		if ($address) {
			$address = '<span class="get-touch-address">'. $address .'</span>';
		} else {
			$address = '';
		}

		if ($phone_num) {
			$phone_num = '<span class="get-touch-phone">'. $phone_num .'</span>';
		} else {
			$phone_num = '';
		}

		if ($email) {
			$email = '<span class="get-touch-email"><a href="mailto:'. esc_url($email) .'">'. $email .'</a></span>';
		} else {
			$email = '';
		}

		if ($map_icon) {
			$map_icon = ' get-have-map-icon';
		} else {
			$map_icon = '';
		}

		// Display the markup before the widget (as defined in functions.php)
		echo $before_widget;

		if ( $title ) {
			echo $before_title . $title . $after_title;
		}

		echo '<div class="nany-get-in-touch '. $custom_class . $map_icon .'">';

			echo $address;
			echo $phone_num;
			echo $email;
			echo do_shortcode( $textarea );

		echo '</div>';

		// Display the markup after the widget (as defined in functions.php)
		echo $after_widget;
	}
}

// Register the widget using an annonymous function
add_action( 'widgets_init', create_function( '', 'register_widget( "Nany_get_in_touch" );' ) );
?>