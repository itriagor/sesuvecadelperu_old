<?php
/**
 * widget-large-ads.php
 *
 * Plugin Name: Nany Large Ads
 * Plugin URI: http://www.themeforest.net/user/defatch
 * Description: A widget that displays large ads.
 * Version: 1.0
 * Author: Defatch
 * Author URI: http://www.themeforest.net/user/defatch
*/

class Nany_large_ads extends WP_Widget {

	/**
	 * Specifies the widget name, description, class name and instatiates it
	 */
	public function __construct() {
		parent::__construct(
			'widget-nany-large-ads',
			__( 'Nany: 300x250 Ad', 'nany' ),
			array(
				'classname'   => 'widget-nany-large-ads',
				'description' => __( 'A custom widget that displays large ads.', 'nany' )
			)
		);
	}


	/**
	 * Generates the back-end layout for the widget
	 */
	public function form( $instance ) {
		// Default widget settings
		$defaults = array(
			'title'           => '',
			'large_ads'       => '[small_ads link="#" target="new_window" image="IMAGE URL" alt="IMAGE ALT TEXT" class="custom-class"]',
			'custom_class'    => ''
		);

		$instance = wp_parse_args( (array) $instance, $defaults );

		// The widget content ?>
		<p>
			<label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:', 'nany' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" value="<?php echo esc_attr( $instance['title'] ); ?>">
		</p>

		<!-- large_ads -->
		<p>
			<label for="<?php echo $this->get_field_id( 'large_ads' ); ?>"><?php _e( '300x250 Ad:', 'nany' ); ?></label>
			<textarea cols="30" rows="3" class="widefat" id="<?php echo $this->get_field_id( 'large_ads' ); ?>" name="<?php echo $this->get_field_name( 'large_ads' ); ?>"><?php echo esc_textarea( $instance['large_ads'] ); ?></textarea>
		</p>

		<!-- Custom Class -->
		<p>
			<label for="<?php echo $this->get_field_id( 'custom_class' ); ?>"><?php _e( 'Custom Class:', 'nany' ); ?></label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id( 'custom_class' ); ?>" name="<?php echo $this->get_field_name( 'custom_class' ); ?>" value="<?php echo esc_attr( $instance['custom_class'] ); ?>">
		</p> <?php
	}


	/**
	 * Processes the widget's values
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		// Update values
		$instance['title']        = strip_tags( stripslashes( $new_instance['title'] ) );
		$instance['large_ads']    = strip_tags( stripslashes( $new_instance['large_ads'] ) );
		$instance['custom_class'] = strip_tags( stripslashes( $new_instance['custom_class'] ) );

		return $instance;
	}


	/**
	 * Output the contents of the widget
	 */
	public function widget( $args, $instance ) {
		// Extract the arguments
		extract( $args );

		$title        = apply_filters( 'widget_title', $instance['title'] );
		$large_ads    = apply_filters( 'widget_text', $instance['large_ads']);
		$custom_class = $instance['custom_class'];

		// Display the markup before the widget (as defined in functions.php)
		echo $before_widget;

		if ( $title ) {
			echo $before_title . $title . $after_title;
		}

		echo '<ul class="nany_large_ads '. $custom_class .'">';
			echo $large_ads;
		echo '</ul>';

		// Display the markup after the widget (as defined in functions.php)
		echo $after_widget;
	}
}

// Register the widget using an annonymous function
add_action( 'widgets_init', create_function( '', 'register_widget( "Nany_large_ads" );' ) );
?>