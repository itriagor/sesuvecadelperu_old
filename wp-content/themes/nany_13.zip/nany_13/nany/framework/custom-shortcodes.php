<?php
/* ==============================================
   Custom Simple Shortcodes
=============================================== */
/* 150x150 Ads Shortcode */
function small_ads_shortcode($atts, $content = null) {
   extract(shortcode_atts(array(
      "link" => '#',
      "target" => '_blank',
      "image" => '',
      "alt" => '',
      "class" => ''
   ), $atts));

   if($image) {
      $image = '<img src="'. esc_attr($image) .'" alt="'. esc_attr($alt) .'" />';
   } else {
      $image = '';
   }

   if ($link) {
      $main_shortcode = '<li class="'. $class .'"><a href="'. esc_url($link) .'" target="'. $target .'">'. $image .'</a></li>';
   } else {
      $main_shortcode = '';
   }

   return $main_shortcode;
}
add_shortcode("small_ads", "small_ads_shortcode");

/* Social Icon */
function social_icon($atts, $content = null) {
   extract(shortcode_atts(array(
      "link" => '#',
      "target" => '_blank',
      "icon" => '',
      "class" => ''
   ), $atts));

   if ($link) {
      $link = '<li class="'. $class .'"><a href="'. esc_url($link) .'" target="'. $target .'" class="icon-'. $icon .' icon-classes"><i class="fa '. $icon .'"></i></a>';
   } else {
      $link = '';
   }

   echo '<ul class="social-icon-shortcode">';

      echo $link;

   echo '</ul>';

}
add_shortcode("social_icon", "social_icon");

/* Smooth Scroll Button */
function smooth_scroll_function($atts, $content = null) {
   extract(shortcode_atts(array(
      "link" => '#',
      "target" => '_self',
      "content" => '',
      "class" => ''
   ), $atts));
   return '<div class="smooth-scroll-btn"><a href="'. esc_url($link) .'" target="'. $target .'" class="'. $class .' btn-style-one">'. $content .'</a></div>';
}
add_shortcode("smooth_scroll", "smooth_scroll_function");

/* Dropcaps */
function dropcaps_function($atts, $content = true) {
   extract(shortcode_atts(array(
      "style" => 'style-one',
      "bg_color" => '',
      "color" => '',
      "size" => '',
      "class" => ''
   ), $atts));

   if ($bg_color) {
      $border_color = $bg_color;
      $bg_color = 'background:'. $bg_color .';';
   }
   if ($size) {
      $size = 'font-size:'. $size .';';
   }
   if ($color) {
      $color = 'color:'. $color .';';
   }

   if ($style === 'style-one') {
      $style = '<span class="dropcap dropcap-style-rounded '. $class .'" style="'. $bg_color . $color . $size .'">'. $content .'</span>';
   } elseif ($style === 'style-two') {
      $style = '<span class="dropcap dropcap-style-flat '. $class .'" style="'. $bg_color . $color . $size .'">'. $content .'</span>';
   } elseif ($style === 'style-three') {
      $bg_color = 'border:2px solid '. $border_color .';';
      $style = '<span class="dropcap '. $class .'" style="'. $bg_color . $color . $size .'">'. $content .'</span>';
   } elseif ($style === 'style-four') {
      $style = '<span class="dropcap '. $class .'" style="'. $color . $size .'">'. $content .'</span>';
   } else {
      $style = '<span class="dropcap dropcap-style-rounded '. $class .'" style="'. $bg_color . $color . $size .'">'. $content .'</span>';
   }

   return $style;

}
add_shortcode("dropcaps", "dropcaps_function");

/* Highlight */
function highlight_function($atts, $content = true) {
   extract(shortcode_atts(array(
      "color" => '',
      "bg_color" => '',
      "size" => '',
      "class" => ''
   ), $atts));

   if ($bg_color) {
      $bg_color = 'background:'. $bg_color .';';
   }
   if ($size) {
      $size = 'font-size:'. $size .';';
   }
   if ($color) {
      $color = 'color:'. $color .';';
   }

   return '<span class="highlight '. $class .'" style="'. $bg_color . $size . $color .'">'. $content .'</span>';

}
add_shortcode("highlight", "highlight_function");

/* Tooltip */
function tooltip_function($atts, $content = true) {
   extract(shortcode_atts(array(
      "tooltip" => '',
      "class" => ''
   ), $atts));

   return '<a href="#" class="'. $class .' nany-tooltip" data-toggle="tooltip" data-placement="top" data-original-title="'. esc_attr($tooltip) .'">'. $content .'</a>';

}
add_shortcode("tooltip", "tooltip_function");

/* FontAwesome Icon */
function font_icon_function($atts, $content = null) {
   extract(shortcode_atts(array(
      "icon" => 'fa-heart',
      "size" => '20px',
      "color" => '#DD3533',
      "align" => 'center',
      "class" => ''
   ), $atts));

   return '<div class="'. $class .'" style="font-size:'. $size .';color:'. $color .';text-align:'. $align .';"><i class="fa '. $icon .'"></i></div>';

}
add_shortcode("icon", "font_icon_function");

/* Join Us */
function join_us_function($atts, $content = null) {
   extract(shortcode_atts(array(
      "color" => '',
      "bg_color" => '',
      "text" => '',
      "link" => '',
      "target" => '_blank',
      "icon" => '',
      "class" => ''
   ), $atts));

   if ($bg_color) {
      $bg_color = 'background:'. $bg_color .';';
   }
   if ($color) {
      $color = 'color:'. $color .';';
   }
   if ($icon) {
      $icon = '<i class="fa '. $icon .'"></i>';
   } else {
      $icon = '<i class="fa fa-plus"></i>';
   }
   if ($link) {
      $link_before = '<a href="'. esc_url($link) .'" target="'. $target .'">';
      $link_after = '</a>';
   } else {
      $link_before = '';
      $link_after = '';
   }

   $icon = '<span class="join-us-icon" style="'. $bg_color .'">'. $icon .'</span>';

   return ''. $link_before .'<div class="join-us '. $class .'" style="'. $color .'">' . $icon .'<h3>'. $text .'</h3></div>'. $link_after .'';

}
add_shortcode("join_us", "join_us_function");

/* Single Image */
function single_image_function($atts, $content = null) {
   extract(shortcode_atts(array(
      "link" => '',
      "target" => '_blank',
      "image_url" => '',
      "alt_text" => '',
      "class" => ''
   ), $atts));

   if($link) {
      return '<div class="'. $class .'"><a href="'. esc_url($link) .'" target="'. $target .'" title="'. esc_attr($alt_text) .'"><img src="'. esc_attr($image_url) .'" alt="'. esc_attr($alt_text) .'"></a></div>';
   } else {
      return '<div class="'. $class .'"><img src="'. esc_attr($image_url) .'" alt="'. esc_attr($alt_text) .'"></div>';
   }

}
add_shortcode("single_image", "single_image_function");

?>