<?php
/**
 * 404.php
 *
 * The template for displaying 404 pages (Not Found).
 */
?>

<?php get_header();

$error_heading = ot_get_option('error_heading');
$error_content = ot_get_option('error_content');
$error_button = ot_get_option('error_button');
$error_all_color = ot_get_option('error_all_color');

if ($error_all_color) {
	$error_all_color = 'style="color:'. $error_all_color .';"';
}

?>

  <div class="col-lg-12 page-not-found">

      <div class="nf-box">
          <h4 <?php echo $error_all_color; ?>><?php if($error_heading) { echo $error_heading; } else { echo __( '404 Page Not Found!', 'nany' ); } ?></h4>
          <p <?php echo $error_all_color; ?>>
            <?php if($error_content) { echo $error_content; } else { echo __( 'The page you\'re looking for not found!', 'nany' ); } ?>
          </p>
          <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="back-home" <?php echo $error_all_color; ?>><?php if($error_button) { echo $error_button; } else { echo __( 'Return to Home Page', 'nany' ); } ?></a>
      </div>

  </div>

<?php get_footer(); ?>