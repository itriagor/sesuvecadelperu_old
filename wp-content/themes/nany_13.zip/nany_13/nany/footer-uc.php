<?php
/**
 * footer-uc.php
 *
 * The template for displaying the footer underconstruction.
 */
?>

    </div> <!-- end row -->
  </div> <!-- end container -->

</div> <!-- Wrapper -->

<?php if(get_post_meta( $post->ID, "uc_date_pick", true )) { ?>
<script>
  jQuery(document).ready(function($){

    $('.uc-counter').dsCountDown({
      endDate: new Date("<?php echo get_post_meta( $post->ID, "uc_date_pick", true ); ?>")
    });

  });
</script>
<?php } ?>

<?php
  // Coundown Script
  wp_enqueue_script('coundown-scripts', SCRIPTS . '/dscountdown.min.js', array('jquery'), '', true);

  wp_footer(); ?>
</body>
</html>