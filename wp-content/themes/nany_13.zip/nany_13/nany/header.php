<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<meta name="keywords" content="<?php echo ot_get_option('nany_meta_keywords'); ?>" />
<meta name="description" content="<?php echo ot_get_option('nany_meta_descriptions'); ?>" />
<?php
  if(!ot_get_option('nany_site_layout')) {
    ?><meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" /><?php
  }
?>
<link rel="alternate" type="application/rss+xml" title="<?php esc_attr(bloginfo('name')); ?> RSS Feed" href="<?php esc_url(bloginfo('rss2_url')); ?>" />


  <?php if (ot_get_option('nany_favicon')){
    echo '<link rel="shortcut icon" href="'. esc_url(ot_get_option('nany_favicon')) .'" />';
  } else {
    echo '<link rel="shortcut icon" href="'. get_template_directory_uri() .'/images/fav.png" />';
  }

  if (ot_get_option('ipad_retina_icon')){
    echo '<link rel="apple-touch-icon" sizes="144x144" href="'. esc_url(ot_get_option('ipad_retina_icon')) .'" >';
  }

  if (ot_get_option('iphone_retina_icon')){
    echo '<link rel="apple-touch-icon" sizes="114x114" href="'. esc_url(ot_get_option('iphone_retina_icon')) .'" >';
  }

  if (ot_get_option('ipad_icon')){
    echo '<link rel="apple-touch-icon" sizes="72x72" href="'. esc_url(ot_get_option('ipad_icon')) .'" >';
  }

  if (ot_get_option('iphone_icon')){
    echo '<link rel="apple-touch-icon" href="'. esc_url(ot_get_option('iphone_icon')) .'" >';
  } ?>

    <title><?php wp_title('', true, 'left'); ?></title>
    <?php echo ot_get_option('analytics_code'); ?>
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

<?php

  $disable_sticky_nav = ot_get_option('disable_sticky_nav');
  if(!$disable_sticky_nav) {
    $disable_sticky_nav = 'sticky-nav';
  } else {
    $disable_sticky_nav = '';
  }

  $theme_option_overlay = ot_get_option('disable_parallax_overlay');;
  $disable_breadcrumbs = ot_get_option('disable_breadcrumbs');;
  $disable_search = ot_get_option('disable_search');;

  /* Page Meta Box */
  if(is_page()) {
    $page_header_type = get_post_meta( $post->ID, "page_header_type", true );
    $page_rev_slider = get_post_meta( $post->ID, "page_rev_slider", true );
    $page_have_slider = 'page_have_slider ';
    $page_background_type = get_post_meta( $post->ID, "page_background_type", true );
    $title_bg_image = get_post_meta( $post->ID, "title_bg_image", true );
    $title_bg_color = get_post_meta( $post->ID, "title_bg_color", true );
    $enble_scroll_on_menu = get_post_meta( $post->ID, "enble_scroll_on_menu", true );
  } else {
    $page_header_type = '';
    $page_rev_slider = '';
    $page_have_slider = '';
    $page_background_type = '';
    $title_bg_image = '';
    $title_bg_color = '';
    $enble_scroll_on_menu = '';
  }

  $title_background = ot_get_option('title_background');

  if ($page_background_type === 'bg_image') {
    if ($title_bg_image) {
      $title_img_url = 'style="background-image: url('. $title_bg_image .');"';
    } elseif($title_background) {
      $title_img_url = 'style="background-image: url('. $title_background .');"';
    }
  } elseif($page_background_type === 'bg_color') {
    if ($title_bg_color) {
      $title_img_url = 'style="background-color: '. $title_bg_color .';"';
    }
  } elseif($title_background) {
    $title_img_url = 'style="background-image: url('. $title_background .');"';
  } else {
    $title_img_url = '';
  }

  if ($page_header_type === 'header_slider') {
    if ($page_rev_slider) {
      $slider_class = 'slider_class';
    }
  } else {
    $slider_class = '';
  }

  if ($enble_scroll_on_menu) {
    $enble_scroll_on_menu = 'class="header-top"';
  } else {
    $enble_scroll_on_menu = '';
  }

?>

  <!--Start Home-->
  <section id="home">

  <!--Start Home-->
  <section id="title-area" class="<?php echo $page_have_slider; echo $slider_class; ?>" <?php echo $title_img_url; ?>>
    <!--Start Header-->
    <div id="fixed-navbar" <?php echo $enble_scroll_on_menu; ?>>
        <nav class="navbar navbar-default navbar-static-top <?php echo $disable_sticky_nav; ?>" role="navigation">
            <div class="container have-search">
                <!-- Brand and toggle get grouped for better mobile display -->
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#main-nav">
                    <span class="sr-only"><?php echo __('Toggle navigation', 'nany'); ?></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    </button>

                    <?php
                    $retina_logo = ot_get_option('retina_logo_upload');
                    $default_logo = ot_get_option('logo_upload');
                      if($default_logo) {
                    ?>

                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" title="<?php echo esc_attr(the_title()); ?>" class="default navbar-logo retina-logo">
                        <img src="<?php echo esc_attr($retina_logo); ?>" alt="<?php esc_attr(bloginfo( 'name' )); ?>" />
                    </a>

                    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" title="<?php echo esc_attr(the_title()); ?>" class="default navbar-logo default-logo">
                      <img src="<?php echo esc_attr($default_logo); ?>" alt="<?php esc_attr(bloginfo( 'name' )); ?>" />
                    </a>

                    <?php } else { ?>
                      <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" title="<?php echo esc_attr(the_title()); ?>" class="default navbar-logo">
                          <img src="<?php echo get_template_directory_uri(); ?>/images/logo.png" alt="<?php esc_attr(bloginfo( 'name' )); ?>" />
                      </a>
                    <?php } ?>

                </div>

                <!-- Collect the nav links, forms, and other content for toggling -->
                <?php
                if(is_page()) {
                  $choose_menu = get_post_meta( $post->ID, "choose_menu", true );
                  if(has_nav_menu($choose_menu)) {
                      wp_nav_menu(array('theme_location'=>$choose_menu,
                          'walker'=>new wp_bootstrap_navwalker(),
                          'container_class'=>'collapse navbar-collapse',
                          'container_id'=>'main-nav',
                          'menu_class'=>'nav navbar-nav  navbar-right',
                          'fallback_cb' => false));
                  } else {
                    if(has_nav_menu('main-menu')) {
                        wp_nav_menu(array('theme_location'=>'main-menu',
                            'walker'=>new wp_bootstrap_navwalker(),
                            'container_class'=>'collapse navbar-collapse',
                            'container_id'=>'main-nav',
                            'menu_class'=>'nav navbar-nav  navbar-right',
                            'fallback_cb' => false));
                    } else {
                      echo "<p class='navbar-right'><small class=\"default-nav-text\">";
                      echo __('Appearance > Menus', 'nany');
                      echo "</small></p>";
                    }
                  }
                } else {

                  if(has_nav_menu('main-menu')) {
                      wp_nav_menu(array('theme_location'=>'main-menu',
                          'walker'=>new wp_bootstrap_navwalker(),
                          'container_class'=>'collapse navbar-collapse',
                          'container_id'=>'main-nav',
                          'menu_class'=>'nav navbar-nav  navbar-right',
                          'fallback_cb' => false));
                  } else {
                      echo "<p class='navbar-right'><small class=\"default-nav-text\">";
                      echo __('Appearance > Menus', 'nany');
                      echo "</small></p>";
                  }

                }
                ?>
                <?php if(!$disable_search) { ?>
                <div class="search-toggle"><i class="fa fa-search"></i></div>
                <?php
                  echo '<div id="header-search" >';
                    get_search_form();
                  echo '</div>';
                }
                ?>
            </div><!-- /.container -->
        </nav>
    </div>
    <!--End Header-->

    <!-- Title Area Starts -->
    <?php if ($page_header_type === 'header_slider') { ?>
      <!-- Load the slider with "nany" alias every time -->
      <?php putRevSlider($page_rev_slider); ?>
    <?php } elseif($page_header_type === 'no_title') {
      if(!$theme_option_overlay) { ?>
      <div class="parallax-overlay"></div>
    <?php } } else { if(!$theme_option_overlay) { ?>
      <div class="parallax-overlay"></div>
      <?php } ?>
      <div class="title-content">
        <div class="row">
          <div class="nany-title">
            <div class="large-dotline"></div>
            <h1 class="page-title uppercase">
              <?php
                nany_title_area();
              ?>
            </h1>
            <div class="large-dotline"></div>
          </div>
          <?php if(!$disable_breadcrumbs) { ?>
          <div class="breadcrumbs-nub"></div>
          <span class="breadcrumbs">
              <?php if ( function_exists( 'breadcrumb_trail' ) ) breadcrumb_trail( array( 'separator' => '' ) ); ?>
          </span>
          <?php } ?>
        </div>
      </div>
      <?php } ?>
    <!-- Title Area End -->

    </section>
  </section>
  <!--End Home-->

  <!-- MAIN CONTENT AREA -->
  <div <?php if(!is_404()) { ?>id="wrapper"<?php } ?>>
  <?php if ( is_page_template( 'template-extra-full-width.php' ) ) { ?>

  <?php } else { ?>
  <div class="container <?php if(!is_404()) { ?>section <?php } else { echo 'page-error'; } ?>">
    <div class="row">
  <?php } ?>