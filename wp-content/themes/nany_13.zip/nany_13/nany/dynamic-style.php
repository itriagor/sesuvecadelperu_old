<?php
/*
* ---------------------------------------------------------------------
* Defatch Dynamic Style
* ---------------------------------------------------------------------
*/

  header("Content-type: text/css;");
  $current_url = dirname(__FILE__);
  $wp_content_pos = strpos($current_url, 'wp-content');
  $wp_content = substr($current_url, 0, $wp_content_pos);
  require_once($wp_content . 'wp-load.php');
?>

<?php /* General Color */ ?>
<?php
  $primary_color = ot_get_option('nany_primary_color'); // Default #497bb8
  $menu_text_color = ot_get_option('nany_menu_text_color');
?>

<?php if($menu_text_color) { ?>
.navbar-default .navbar-nav > li > a, .navbar-nav > ul > li > span.dropdown-toggle a, .navbar-default .navbar-nav > li > a,
.dropdown-menu > li > a {
    color: <?php echo $menu_text_color; ?>;
}
<?php } ?>

<?php if($primary_color) { ?>
/***********************************************
  1. Background Color
***********************************************/
::-moz-selection {
 background: <?php echo $primary_color; ?>;
 color: #fff;
}
::selection {
    background: <?php echo $primary_color; ?>;
    color: #fff;
}

.is-sticky #header-search input.s,
.service-style-one,
.social-media li a,
#testi-slider .owl-controls .owl-page.active span,
#testi-slider .owl-controls .owl-page span:hover,
a.btn-style-one,
.nav-tabs > li.active > a,
.nav-tabs > li.active > a:hover,
.nav-tabs > li.active > a:focus,
.nany-tooltip + .tooltip > .tooltip-inner,
.join-us-icon,
.entry-content .promo-style-1 .promo-heading h3,
.viewnow, .viewnow:hover,
a.btn-style-four.read-more:hover,
.breadcrumbs,
.nany-portfolio li:hover .port-title,
.social-share li a,
.page-numbers li span.current,
.page-numbers li a:hover,
.next.page-numbers,
.prev.page-numbers,
.wp-pagenavi span.current,
.wp-pagenavi a:hover,
.woocommerce-pagination .page-numbers span.current,
.woocommerce-pagination .page-numbers a:hover,
.sidebar ul li:hover.cat-item .badge,
.woocommerce th,
.woocommerce-message:before,
.woocommerce-info:before,
.wc-edit, .wc-edit:hover,
.woocommerce a.button,
.woocommerce button.button,
.woocommerce input.button,
.woocommerce #respond input#submit,
.woocommerce #content input.button,
.woocommerce-page a.button,
.woocommerce-page button.button,
.woocommerce-page input.button,
.woocommerce-page #respond input#submit,
.woocommerce-page #content input.button,
#woo-slider .owl-controls .owl-buttons div,
.img-wrap:hover .product-inner,
.woocommerce a.add_to_cart_button.button,
.woocommerce a.product_type_variable.button,
.woocommerce a.product_type_grouped.button,
#woo-slider .owl-controls .owl-buttons div,
.woocommerce a.add_to_cart_button.button:hover,
.woocommerce a.product_type_variable.button:hover,
.woocommerce a.product_type_grouped.button:hover,
#woo-slider .owl-controls .owl-buttons div:hover,
.woocommerce a.button.alt,
.woocommerce button.button.alt,
.woocommerce input.button.alt,
.woocommerce #respond input#submit.alt,
.woocommerce #content input.button.alt,
.woocommerce-page a.button.alt,
.woocommerce-page button.button.alt,
.woocommerce-page input.button.alt,
.woocommerce-page #respond input#submit.alt,
.woocommerce-page #content input.button.alt,
.woocommerce a.added_to_cart, .woocommerce-page a.added_to_cart,
.woocommerce .link-like .zilla-likes:hover .zilla-likes-count,
.woocommerce-page .link-like .zilla-likes:hover .zilla-likes-count,
.woocommerce .link-like .zilla-likes.active,
.woocommerce-page .link-like .zilla-likes.active,
.quantity .plus, .quantity .minus,
.woocommerce .widget_price_filter .ui-slider .ui-slider-range,
.woocommerce-page .widget_price_filter .ui-slider .ui-slider-range,
.widget-ajax-cart i,
[id^=tab]:checked + label,
a:hover.btn-style-one,
table tfoot, table tfoot a,
button, html input[type="button"], input[type="reset"],
input[type="submit"], input#submit, input.wpcf7-submit,
#yith-wcwl-popup-message {
    background: <?php echo $primary_color; ?>;
}

.woocommerce .widget_layered_nav ul li.chosen a,
.woocommerce-page .widget_layered_nav ul li.chosen a,
.woocommerce .widget_layered_nav_filters ul li a,
.woocommerce-page .widget_layered_nav_filters ul li a {
  background-color: <?php echo $primary_color; ?>;
}


/***********************************************
  2. Text Color
***********************************************/
a,
#main-nav .current,
.nav > ul > li > a:hover, .nav > ul > li > a:focus,
.testi-company,
.panel-default > .panel-heading a,
.comments-reply i,
#footer .nany-recent-widget .recent-date-full,
.sidebar ul li:hover.cat-item,
.sidebar ul li:hover.cat-item:before,
.wpb_accordion .wpb_accordion_wrapper .wpb_accordion_header a,
.woocommerce div.product span.price,
.woocommerce div.product p.price,
.woocommerce #content div.product span.price,
.woocommerce #content div.product p.price,
.woocommerce-page div.product span.price,
.woocommerce-page div.product p.price,
.woocommerce-page #content div.product span.price,
.woocommerce-page #content div.product p.price,
.woocommerce div.product .stock,
.woocommerce #content div.product .stock,
.woocommerce-page div.product .stock,
.woocommerce-page #content div.product .stock,
.woocommerce .img-wrap:hover a.add_to_cart_button.button,
.woocommerce .img-wrap:hover .link-like .zilla-likes:hover .zilla-likes-count,
.woocommerce-page .img-wrap:hover .link-like .zilla-likes:hover .zilla-likes-count,
.woocommerce .img-wrap:hover .link-like .zilla-likes:hover .zilla-likes-count em,
.woocommerce-page .img-wrap:hover .link-like .zilla-likes:hover .zilla-likes-count em,
.woocommerce .img-wrap:hover .link-like li a,
.woocommerce-page .img-wrap:hover .link-like li a,
.yith-wcwl-add-to-wishlist .show a:hover,
.yith-wcwl-add-to-wishlist .show a:hover:before,
.nany-product-details:hover,
.nany-product-details:hover:before,
.woocommerce .cart-collaterals .cart_totals .discount td,
.woocommerce-page .cart-collaterals .cart_totals .discount td,
.woocommerce ul.digital-downloads li a:hover,
.woocommerce-page ul.digital-downloads li a:hover,
.widget-ajax-cart a:hover {
    color: <?php echo $primary_color; ?>;
}

/***********************************************
  3. Border Color
***********************************************/
.timeline-top-line,
.timeline-top-line:before,
.nany-portfolio li:hover .port-title,
.shop-template .product-inner, .woocommerce .product-inner,
.woocommerce-message,
.woocommerce-info,
#yith-wcwl-popup-message,
.woocommerce .link-like .zilla-likes.active,
.woocommerce-page .link-like .zilla-likes.active,
.woocommerce div.product form.cart div.quantity,
.woocommerce-page div.product form.cart div.quantity,
.quantity,
.woocommerce ul.digital-downloads li a:hover,
.woocommerce-page ul.digital-downloads li a:hover,
.woocommerce .widget_layered_nav ul li.chosen a,
.woocommerce-page .widget_layered_nav ul li.chosen a,
.woocommerce .widget_layered_nav_filters ul li a,
.woocommerce-page .widget_layered_nav_filters ul li a,
.woocommerce .widget_price_filter .ui-slider .ui-slider-handle,
.woocommerce-page .widget_price_filter .ui-slider .ui-slider-handle,
a.btn-style-four {
  border-color:<?php echo $primary_color; ?>;
}
.nany-tooltip + .tooltip > .tooltip-arrow {border-top-color:<?php echo $primary_color; ?>;}
.is-sticky #header-search:before {
  border-color: transparent transparent <?php echo $primary_color; ?> transparent;
  border-color:rgba(255,255,255,0)  rgba(255,255,255,0) <?php echo $primary_color; ?> rgba(255,255,255,0);
}
.wpb_tabs .wpb_tabs_nav li.ui-tabs-active.ui-state-active,
.wpb_tabs .wpb_tabs_nav li.ui-tabs-active.ui-state-focus,
.wpb_tabs .wpb_tabs_nav li.ui-tabs-active.ui-state-hover,
.testi-content {border-top-color:<?php echo $primary_color; ?>;}

.wpb_tour .wpb_tabs_nav li.ui-tabs-active {border-left-color:<?php echo $primary_color; ?> !important;}
.port-title {border-bottom-color:<?php echo $primary_color; ?>;}

<?php $hex_primary = hex2rgb($primary_color); ?>
.table-style-four table tr:hover {
  background-color: rgba(<?php echo $hex_primary; ?>, 0.2);
}
.blog-style-1:hover .blog-style-content {
  background: rgba(<?php echo $hex_primary; ?>, 0.8);
}

<?php } ?>


/***********************************************
    Headings - Text Color
***********************************************/
<?php $nany_header_text_color = ot_get_option('nany_header_text_color');
if($nany_header_text_color) { ?>
h1, h2, h3, h4, h5, h6,
.entry-content h1, .entry-content h2,
.entry-content h3, .entry-content h4,
.entry-content h5, .entry-content h6,
.post-title, .author-name h3,
.comment-wrapper h3, .comment-wrapper h3 {color: <?php echo $nany_header_text_color; ?>;}
<?php } ?>

<?php $nany_sidebar_text_color = ot_get_option('nany_sidebar_text_color');
if($nany_sidebar_text_color) { ?>
.widget-title {color: <?php echo $nany_sidebar_text_color; ?>;}
<?php } ?>

<?php $nany_footer_header_color = ot_get_option('nany_footer_header_color');
if($nany_footer_header_color) { ?>
.footer-widget-title, #footer h2 {color: <?php echo $nany_footer_header_color; ?>;}
<?php } ?>

/***********************************************
    Typography
***********************************************/
body {
<?php
  $google_body_font = ot_get_option('google_body_font');
  $body_font_family = $google_body_font['font-family'];
  $body_font_family = str_replace("+", " ", $body_font_family);
  echo 'font-family:'. $body_font_family .', sans-serif !important;';
  echo 'font-weight:'. $google_body_font['font-weight'] .' !important;';
  echo 'letter-spacing:'.$google_body_font['letter-spacing'] .' !important;';
  echo 'text-transform:'. $google_body_font['text-transform'] .' !important;';
  echo 'color:'. $google_body_font['font-color'] .' !important;';
  echo 'font-size:'. $google_body_font['font-size'] .' !important;';
?>
}

input[type='submit']{
  font-family:<?php echo $body_font_family; ?>, sans-serif;
}

<?php if (ot_get_option('google_menu_font')) { ?>
.navbar-default .navbar-nav > li > a, .navbar-nav > ul > li > span.dropdown-toggle a, .navbar-default .navbar-nav > li > a, .dropdown-menu > li > a {
<?php
  $google_menu_font = ot_get_option('google_menu_font');
  $menu_font_family = $google_menu_font['font-family'];
  $menu_font_family = str_replace("+", " ", $menu_font_family);
  echo 'font-family:'. $menu_font_family .', sans-serif !important;';
  echo 'font-weight:'. $google_menu_font['font-weight'] .' !important;';
  echo 'letter-spacing:'. $google_menu_font['letter-spacing'] .' !important;';
  echo 'text-transform:'. $google_menu_font['text-transform'] .' !important;';
  echo 'font-size:'. $google_menu_font['font-size'] .' !important;';
?>
}
<?php } ?>

<?php if (ot_get_option('google_page_font')) { ?>
.page-title {
<?php
  $google_page_font = ot_get_option('google_page_font');
  $page_font_family = $google_page_font['font-family'];
  $page_font_family = str_replace("+", " ", $page_font_family);
  echo 'font-family:'. $page_font_family .', sans-serif !important;';
  echo 'font-weight:'. $google_page_font['font-weight'] .' !important;';
  echo 'letter-spacing:'.$google_page_font['letter-spacing'] .' !important;';
  echo 'text-transform:'. $google_page_font['text-transform'] .' !important;';
  echo 'color:'. $google_page_font['font-color'] .' !important;';
  echo 'font-size:'. $google_page_font['font-size'] .' !important;';
?>
}
<?php } ?>

<?php if (ot_get_option('google_fonts_headings')) { ?>
h1, h2, h3, h4, h5, h6,
.entry-content h1, .entry-content h2,
.entry-content h3, .entry-content h4,
.entry-content h5, .entry-content h6,
.post-title, .author-name h3,
.comment-wrapper h3, .comment-wrapper h3,
.footer-menu ul li a,
.copyright-text {
  <?php
  $google_fonts_headings = ot_get_option('google_fonts_headings');
  $headings_font_family = $google_fonts_headings['font-family'];
  $headings_font_family = str_replace("+", " ", $headings_font_family);
  echo 'font-family:'. $headings_font_family .', sans-serif !important;';
  echo 'font-weight:'. $google_fonts_headings['font-weight'] .' !important;';
  echo 'letter-spacing:'.$google_fonts_headings['letter-spacing'] .' !important;';
  echo 'text-transform:'. $google_fonts_headings['text-transform'] .' !important;';
  echo 'font-size:'. $google_fonts_headings['font-size'] .' !important;';
  ?>
}
<?php } ?>

<?php if (ot_get_option('google_custom_font')) { ?>
.custom-font{
  <?php
  $google_custom_font = ot_get_option('google_custom_font');
  $custom_font_family = $google_custom_font['font-family'];
  $custom_font_family = str_replace("+", " ", $custom_font_family);
  echo 'font-family:'. $custom_font_family .', sans-serif;';
  echo 'font-weight:'. $google_custom_font['font-weight'] .';';
  echo 'letter-spacing:'. $google_custom_font['letter-spacing'] .';';
  echo 'color:'. $google_custom_font['font-color'] .' !important;';
  echo 'text-transform:'. $google_custom_font['text-transform'] .';';
  ?>
}
<?php } ?>

<?php $title_nub = ot_get_option('title_nub');
if($title_nub) { ?>
.breadcrumbs-nub {
  background: url('<?php echo $title_nub; ?>') no-repeat top center;
}
<?php } ?>
<?php $title_nub_bg_color = ot_get_option('title_nub_bg_color');
if($title_nub_bg_color) { ?>
.breadcrumbs {
  background: <?php echo $title_nub_bg_color; ?>;
}
<?php } ?>

<?php $process_tabs = ot_get_option('process_tabs');
foreach($process_tabs as $process_tab) :
$process_title = $process_tab['title'];
$process_color = $process_tab['process_color'];
$own_id = preg_replace('/[^a-z]/', "-", strtolower($process_title)); ?>

/* <?php echo $process_title; ?> */
.proc-tabs li a:hover .tab-icon.<?php echo $own_id; ?> {box-shadow: 0 0 0 5px <?php echo $process_color; ?>;}
.tab-icon.<?php echo $own_id; ?> {background: <?php echo $process_color; ?>;}
.tab-icon.<?php echo $own_id; ?>:before,
.tab-icon.<?php echo $own_id; ?>:after {background: <?php echo $process_color; ?>;}
.activ-process.<?php echo $own_id; ?> {
  -webkit-box-shadow: 0 0 0 5px <?php echo $process_color; ?>;
  -moz-box-shadow: 0 0 0 5px <?php echo $process_color; ?>;
  box-shadow: 0 0 0 5px <?php echo $process_color; ?>;
}
.tab-icon-in.<?php echo $own_id; ?>-in {border-color: <?php echo $process_color; ?>;}
<?php endforeach; ?>

<?php $timeline_section = ot_get_option('timeline_section');
foreach($timeline_section as $timeline_tab) :
$timeline_title = $timeline_tab['title'];
$timeline_color = $timeline_tab['timeline_color'];
$own_id = preg_replace('/[^a-z]/', "-", strtolower($timeline_title)); ?>

/* <?php echo $timeline_title; ?> */
.timeline.<?php echo $own_id; ?> .timeline-year-icon {background: <?php echo $timeline_color; ?>;}
.timeline.<?php echo $own_id; ?>:hover .timeline-year-icon {box-shadow: 0 0 0 7px <?php echo $timeline_color; ?>;}
<?php endforeach; ?>

/* 404 Page */
<?php $error_bg = ot_get_option('error_bg');
if($error_bg) { ?>
.error404 {
  background-image:url('<?php echo $error_bg; ?>');
}
<?php } ?>

/***********************************************
    Custom CSS
***********************************************/
<?php echo ot_get_option('nany_styling'); ?>