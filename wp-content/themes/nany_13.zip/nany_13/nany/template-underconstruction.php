<?php
/*
Template Name: Under Construction
*/
?>

<?php get_header('uc');

$color = get_post_meta( $post->ID, "uc_color", true );

if ($color) {
    $color = 'style="color:'. $color .';"';
} else {
    $color = '';
}

?>

<!-- Content Starts -->
<div class="col-lg-12 section">

    <div class="uc-message col-lg-8 col-md-6 col-sm-12">
        <?php if (get_post_meta( $post->ID, "uc_heading", true )) { ?>
            <h2 <?php echo $color; ?>><?php echo do_shortcode(get_post_meta( $post->ID, "uc_heading", true )); ?></h2>
        <?php } else {
            echo __('<h2 '. $color .'>Under Construction</h2>', 'nany');
        } ?>
        <?php if (get_post_meta( $post->ID, "uc_subheading", true )) { ?>
            <p <?php echo $color; ?>><?php echo do_shortcode(get_post_meta( $post->ID, "uc_subheading", true )); ?></p>
        <?php } else {
            echo __('<p '. $color .'>Page is Currently Under Construction. New Website is Coming Soon.</p>', 'nany');
        } ?>
    </div>

    <?php if (get_post_meta( $post->ID, "uc_date_pick", true )) { ?>
    <div class="col-lg-4 col-md-6 col-sm-12">
        <div class="uc-counter" <?php echo $color; ?>></div>
    </div>
    <?php } ?>

</div>
<!-- Content End -->

<?php get_footer('uc'); ?>