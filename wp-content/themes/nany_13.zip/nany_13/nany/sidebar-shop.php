<?php
/**
 * sidebar-shop.php
 *
 * The shop sidebar.
 */
$layout = ot_get_option('woo_layout');
$sidebar_select = get_post_meta( $post->ID, "sidebar_select", true );

if($layout === 'left_sidebar') { ?>
		<div class="col-lg-4 col-md-4 col-sm-12 sidebar woo-left" role="complementary">
			<?php
				if ($sidebar_select) {
				  dynamic_sidebar($sidebar_select);
				} else {
				  dynamic_sidebar( 'shop-widget' );
				}
			?>
		</div> <!-- end sidebar -->
	<?php
} else { ?>
		<div class="col-lg-4 col-md-4 col-sm-12 sidebar" role="complementary">
			<?php
				if ($sidebar_select) {
				  dynamic_sidebar($sidebar_select);
				} else {
				  dynamic_sidebar( 'shop-widget' );
				}
			?>
		</div> <!-- end sidebar -->
	<?php
}
if ($layout === 'full_width') {
	# Nothing needs to happen
}
